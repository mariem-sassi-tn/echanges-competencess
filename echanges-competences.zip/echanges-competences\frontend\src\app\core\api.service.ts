import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { environment } from '../../environments/environment';
import { Category, DuplicatesResponse, Exchange, MatchingStats, RecommendationsResponse, Skill, SupportMessage, SkillSuggestion, SupportThread, User, UserSkill } from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  constructor(private http: HttpClient) {}

  catalog() {
    return this.http.get<{ categories: Category[]; skills: Skill[] }>(`${environment.apiUrl}/catalog`);
  }

  members(q = '', city = '') {
    let params = new HttpParams();
    if (q) params = params.set('q', q);
    if (city) params = params.set('city', city);
    return this.http.get<{ users: User[]; meta?: { semantic?: string[] } }>(`${environment.apiUrl}/users`, { params });
  }

  recommendations() {
    return this.http.get<RecommendationsResponse>(`${environment.apiUrl}/recommendations`);
  }

  recommendationClick(candidateId: number) {
    return this.http.post(`${environment.apiUrl}/recommendations/events`, { candidateId, type: 'click' });
  }

  member(id: number) {
    return this.http.get<{ user: User }>(`${environment.apiUrl}/users/${id}`);
  }

  updateProfile(payload: Partial<User> & { firstName: string; lastName: string }) {
    return this.http.patch<{ user: User }>(`${environment.apiUrl}/users/me`, payload);
  }

  mySkills() {
    return this.http.get<{ skills: UserSkill[] }>(`${environment.apiUrl}/users/me/skills`);
  }

  skillSuggestions() {
    return this.http.get<{ available: boolean; reason?: string; suggestions: SkillSuggestion[] }>(
      `${environment.apiUrl}/users/me/skill-suggestions`
    );
  }

  addSkill(payload: { skillId: number; type: string; level: string; description?: string }) {
    return this.http.post(`${environment.apiUrl}/users/me/skills`, payload);
  }

  removeSkill(id: number) {
    return this.http.delete(`${environment.apiUrl}/users/me/skills/${id}`);
  }

  exchanges() {
    return this.http.get<{ exchanges: Exchange[] }>(`${environment.apiUrl}/exchanges`);
  }

  exchange(id: number) {
    return this.http.get<{ exchange: Exchange; messages: any[] }>(`${environment.apiUrl}/exchanges/${id}`);
  }

  propose(payload: Record<string, unknown>) {
    return this.http.post(`${environment.apiUrl}/exchanges`, payload);
  }

  updateStatus(id: number, status: string) {
    return this.http.patch(`${environment.apiUrl}/exchanges/${id}/status`, { status });
  }

  sendMessage(id: number, content: string) {
    return this.http.post(`${environment.apiUrl}/exchanges/${id}/messages`, { content });
  }

  transcribeAudio(wav: Blob, lang: string) {
    return this.http.post<{ text: string }>(`${environment.apiUrl}/exchanges/transcribe?lang=${encodeURIComponent(lang)}`, wav, {
      headers: { 'Content-Type': 'audio/wav' }
    });
  }

  exchangeAiChat(id: number, message: string, history: { role: 'user' | 'assistant'; content: string }[]) {
    return this.http.post<{ reply: string }>(`${environment.apiUrl}/exchanges/${id}/ai-chat`, { message, history });
  }

  review(id: number, rating: number, comment: string) {
    return this.http.post(`${environment.apiUrl}/exchanges/${id}/reviews`, { rating, comment });
  }

  adminDashboard() {
    return this.http.get<{ stats: any; recent: any[] }>(`${environment.apiUrl}/admin/dashboard`);
  }

  adminUsers() {
    return this.http.get<{ users: User[] }>(`${environment.apiUrl}/admin/users`);
  }

  patchUser(id: number, payload: Record<string, unknown>) {
    return this.http.patch(`${environment.apiUrl}/admin/users/${id}`, payload);
  }

  matchingStats(days = 30) {
    return this.http.get<MatchingStats>(`${environment.apiUrl}/admin/matching-stats`, {
      params: new HttpParams().set('days', String(days))
    });
  }

  adminExchanges() {
    return this.http.get<{ exchanges: any[] }>(`${environment.apiUrl}/admin/exchanges`);
  }

  createCategory(payload: { name: string; slug?: string; icon?: string }) {
    return this.http.post(`${environment.apiUrl}/admin/categories`, payload);
  }

  createSkill(payload: { name: string }) {
    return this.http.post(`${environment.apiUrl}/admin/skills`, payload);
  }

  deleteSkill(id: number) {
    return this.http.delete(`${environment.apiUrl}/admin/skills/${id}`);
  }

  // Assistant IA du support
  supportAiChat(message: string, history: { role: 'user' | 'assistant'; content: string }[]) {
    return this.http.post<{ reply: string }>(`${environment.apiUrl}/support/ai-chat`, { message, history });
  }

  // Contact administrateur
  supportThread() {
    return this.http.get<{ messages: SupportMessage[] }>(`${environment.apiUrl}/support/me`);
  }

  sendSupportMessage(content: string) {
    return this.http.post(`${environment.apiUrl}/support/me`, { content });
  }

  adminSupportThreads() {
    return this.http.get<{ threads: SupportThread[] }>(`${environment.apiUrl}/support/threads`);
  }

  adminSupportThread(userId: number) {
    return this.http.get<{ messages: SupportMessage[] }>(`${environment.apiUrl}/support/threads/${userId}`);
  }

  adminReplySupport(userId: number, content: string) {
    return this.http.post(`${environment.apiUrl}/support/threads/${userId}`, { content });
  }

  /** Message d'ouverture rédigé par l'IA (ou modèle standard si l'IA est indisponible). */
  draftExchangeMessage(payload: { partnerId: number; offeredUserSkillId: number | null; requestedUserSkillId: number | null }) {
    return this.http.post<{ message: string; ai: boolean }>(`${environment.apiUrl}/exchanges/draft-message`, payload);
  }

  adminSupportDraft(userId: number) {
    return this.http.post<{ summary: string | null; draft: string }>(
      `${environment.apiUrl}/support/threads/${userId}/draft-reply`,
      {}
    );
  }

  catalogDuplicates(threshold: number) {
    return this.http.get<DuplicatesResponse>(`${environment.apiUrl}/admin/catalog-duplicates`, {
      params: new HttpParams().set('threshold', String(threshold))
    });
  }

  mergeSkills(keepId: number, mergeIds: number[]) {
    return this.http.post<{ merged: number; message: string }>(`${environment.apiUrl}/admin/skills/merge`, { keepId, mergeIds });
  }
}
