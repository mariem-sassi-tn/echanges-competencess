import { Routes } from '@angular/router';
import { adminGuard, authGuard, guestGuard, userGuard } from './core/guards';

export const routes: Routes = [
  {
    path: '',
    loadComponent: () => import('./pages/landing/landing.component').then((m) => m.LandingComponent)
  },
  {
    path: 'connexion',
    canActivate: [guestGuard],
    loadComponent: () => import('./pages/login/login.component').then((m) => m.LoginComponent)
  },
  {
    path: 'inscription',
    canActivate: [guestGuard],
    loadComponent: () => import('./pages/register/register.component').then((m) => m.RegisterComponent)
  },
  {
    path: 'espace',
    canActivate: [authGuard, userGuard],
    loadComponent: () => import('./layouts/user-shell.component').then((m) => m.UserShellComponent),
    children: [
      { path: '', loadComponent: () => import('./pages/user/dashboard.component').then((m) => m.UserDashboardComponent) },
      { path: 'profil', loadComponent: () => import('./pages/user/profile.component').then((m) => m.ProfileComponent) },
      { path: 'competences', loadComponent: () => import('./pages/user/skills.component').then((m) => m.SkillsComponent) },
      { path: 'matches', loadComponent: () => import('./pages/user/matches.component').then((m) => m.MatchesComponent) },
      { path: 'membres', loadComponent: () => import('./pages/user/members.component').then((m) => m.MembersComponent) },
      { path: 'membres/:id', loadComponent: () => import('./pages/user/member-detail.component').then((m) => m.MemberDetailComponent) },
      { path: 'echanges', loadComponent: () => import('./pages/user/exchanges.component').then((m) => m.ExchangesComponent) },
      { path: 'echanges/:id', loadComponent: () => import('./pages/user/exchange-detail.component').then((m) => m.ExchangeDetailComponent) },
      { path: 'contact', loadComponent: () => import('./pages/user/contact-admin.component').then((m) => m.ContactAdminComponent) }
    ]
  },
  {
    path: 'admin',
    canActivate: [authGuard, adminGuard],
    loadComponent: () => import('./layouts/admin-shell.component').then((m) => m.AdminShellComponent),
    children: [
      { path: '', loadComponent: () => import('./pages/admin/admin-dashboard.component').then((m) => m.AdminDashboardComponent) },
      { path: 'utilisateurs', loadComponent: () => import('./pages/admin/admin-users.component').then((m) => m.AdminUsersComponent) },
      { path: 'catalogue', loadComponent: () => import('./pages/admin/admin-catalog.component').then((m) => m.AdminCatalogComponent) },
      { path: 'catalogue/doublons', loadComponent: () => import('./pages/admin/admin-duplicates.component').then((m) => m.AdminDuplicatesComponent) },
      { path: 'matching', loadComponent: () => import('./pages/admin/admin-matching.component').then((m) => m.AdminMatchingComponent) },
      { path: 'echanges', loadComponent: () => import('./pages/admin/admin-exchanges.component').then((m) => m.AdminExchangesComponent) },
      { path: 'support', loadComponent: () => import('./pages/admin/admin-support.component').then((m) => m.AdminSupportComponent) }
    ]
  },
  {
    path: '**',
    loadComponent: () => import('./pages/not-found/not-found.component').then((m) => m.NotFoundComponent)
  }
];
