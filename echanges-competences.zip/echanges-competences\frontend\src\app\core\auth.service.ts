import { Injectable, signal, computed } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router } from '@angular/router';
import { tap } from 'rxjs';
import { environment } from '../../environments/environment';
import { User } from './models';

interface AuthResponse {
  token: string;
  user: User;
}

@Injectable({ providedIn: 'root' })
export class AuthService {
  private readonly tokenKey = 'ec_token';
  private readonly userKey = 'ec_user';
  readonly user = signal<User | null>(this.readUser());
  readonly isLoggedIn = computed(() => !!this.user());
  readonly isAdmin = computed(() => this.user()?.role === 'admin');

  constructor(private http: HttpClient, private router: Router) {}

  token(): string | null {
    return localStorage.getItem(this.tokenKey);
  }

  login(email: string, password: string) {
    return this.http.post<AuthResponse>(`${environment.apiUrl}/auth/login`, { email, password }).pipe(
      tap((res) => this.persist(res))
    );
  }

  register(payload: Record<string, string>) {
    return this.http.post<AuthResponse>(`${environment.apiUrl}/auth/register`, payload).pipe(
      tap((res) => this.persist(res))
    );
  }

  me() {
    return this.http.get<{ user: User }>(`${environment.apiUrl}/auth/me`).pipe(
      tap((res) => {
        this.user.set(res.user);
        localStorage.setItem(this.userKey, JSON.stringify(res.user));
      })
    );
  }

  // Demander l'envoi du code de réinitialisation
  sendResetCode(email: string) {
    return this.http.post<{ message: string }>(`${environment.apiUrl}/auth/forgot-password`, { email });
  }

  // Valider le code et changer le mot de passe
  confirmResetPassword(data: { email: string; code: string; newPassword: string }) {
    return this.http.post<{ message: string }>(`${environment.apiUrl}/auth/reset-password`, data);
  }

  logout() {
    localStorage.removeItem(this.tokenKey);
    localStorage.removeItem(this.userKey);
    this.user.set(null);
    this.router.navigate(['/connexion']);
  }

  redirectAfterLogin(user: User) {
    this.router.navigateByUrl(user.role === 'admin' ? '/admin' : '/espace');
  }

  private persist(res: AuthResponse) {
    localStorage.setItem(this.tokenKey, res.token);
    localStorage.setItem(this.userKey, JSON.stringify(res.user));
    this.user.set(res.user);
  }

  private readUser(): User | null {
    try {
      const raw = localStorage.getItem(this.userKey);
      return raw ? JSON.parse(raw) : null;
    } catch {
      return null;
    }
  }
}