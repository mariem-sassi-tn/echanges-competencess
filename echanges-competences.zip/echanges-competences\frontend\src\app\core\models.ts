export interface CvExperience {
  role: string;
  company: string;
  period: string;
  description?: string;
}

export interface CvEducation {
  degree: string;
  school: string;
  period: string;
}

export interface CvData {
  headline?: string;
  summary?: string;
  experiences: CvExperience[];
  educations: CvEducation[];
}

export interface User {
  id: number;
  firstName: string;
  lastName: string;
  email?: string;
  role: 'user' | 'admin';
  bio?: string | null;
  city?: string | null;
  avatarUrl?: string | null;
  cvData?: CvData | null;
  isActive?: boolean;
  rating?: number | null;
  createdAt?: string;
  skills?: UserSkill[];
  reviews?: Review[];
}

export interface UserSkill {
  id: number;
  user_id?: number;
  skill_id?: number;
  type: 'offer' | 'need';
  level: 'beginner' | 'intermediate' | 'expert';
  description?: string | null;
  skillName?: string;
  categoryName?: string;
  categoryId?: number;
}

export interface Category {
  id: number;
  name: string;
  slug: string;
  icon: string;
}

export interface Skill {
  id: number;
  category_id: number;
  name: string;
  categoryName?: string;
}

export interface Exchange {
  id: number;
  status: string;
  message?: string;
  createdAt: string;
  updatedAt?: string;
  requester: { id: number; firstName: string; lastName: string };
  partner: { id: number; firstName: string; lastName: string };
  offeredSkill?: string;
  requestedSkill?: string;
}

export interface ChatMessage {
  id: number;
  content: string;
  createdAt: string;
  sender: { id: number; firstName: string; lastName: string };
}

export interface Review {
  id: number;
  rating: number;
  comment?: string | null;
  created_at?: string;
  first_name?: string;
  last_name?: string;
}

export interface SupportMessage {
  id: number;
  content: string;
  created_at: string;
  sender_id: number;
  senderRole: 'user' | 'admin';
  senderFirstName: string;
  senderLastName: string;
}

export interface SupportThread {
  userId: number;
  firstName: string;
  lastName: string;
  email: string;
  lastMessage: string;
  lastAt: string;
  messageCount: number;
}

export interface RecommendationReason {
  kind: 'they_offer' | 'they_need';
  skill: string;
  matches: string;
  exact: boolean;
}

export interface RecommendationMember {
  firstName: string;
  lastName: string;
  city: string | null;
  avatarUrl: string | null;
}

export interface RecommendationProposal {
  offeredUserSkillId: number | null;
  requestedUserSkillId: number | null;
  offeredSkill: string | null;
  requestedSkill: string | null;
}

export interface Recommendation {
  userId: number;
  score: number;
  reasons: RecommendationReason[];
  /** % de mes besoins couverts par ses offres. */
  forward?: number | null;
  /** % de ses besoins couverts par mes offres. */
  backward?: number | null;
  /** Troc réciproque : chacun apporte à l'autre. */
  mutual?: boolean;
  member?: RecommendationMember | null;
  proposal?: RecommendationProposal;
}

export interface MatchingBucket {
  bucket: 'high' | 'medium' | 'low';
  shown: number;
  clicked: number;
  proposed: number;
  clickRate: number | null;
  proposeRate: number | null;
}

export interface MatchingStats {
  days: number;
  ml: { configured: boolean; up: boolean; model: string | null };
  funnel: {
    shown: number;
    clicked: number;
    proposed: number;
    proposedWithoutReco: number;
    usersServed: number;
    avgScore: number | null;
    clickRate: number | null;
    proposeRate: number | null;
  };
  buckets: MatchingBucket[];
  members: { total: number; withSkills: number };
}

export interface RecommendationsResponse {
  available: boolean;
  model: string | null;
  reason?: 'no_skills';
  recommendations: Recommendation[];
}

export interface SkillSuggestion {
  skillId: number;
  name: string;
  categoryName: string | null;
  score: number;
  evidence: string;
}

export interface DuplicateSkill {
  id: number;
  name: string;
  uses: number;
}

export interface DuplicateCluster {
  score: number;
  skills: DuplicateSkill[];
}

export interface DuplicatesResponse {
  available: boolean;
  threshold: number;
  clusters: DuplicateCluster[];
}
