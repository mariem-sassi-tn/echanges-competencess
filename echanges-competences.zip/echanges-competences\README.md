# Échanges de compétences

Application web d'échange de compétences entre membres, avec recommandation de partenaires par IA (Gemini).

**Stack** : Angular (frontend), Node.js (API), MySQL (base de données), le tout orchestré avec Docker Compose.

## Prérequis

- Docker Desktop installé et démarré

## Lancement

1. Décompresser l'archive et ouvrir un terminal dans le dossier `echanges-competences`.
2. (Optionnel, pour la page « Mes matches ») ouvrir le fichier `.env` et remplacer `METTRE_VOTRE_CLE_ICI` par une clé Gemini (gratuite sur https://aistudio.google.com).
3. Lancer :

```
docker compose up --build -d
```

Le premier build prend 2 à 3 minutes.

4. Ouvrir http://localhost:8080

Pour arrêter : `docker compose down`

## Comptes de test

- **Administrateur** : `admin@echanges.local` (mot de passe défini dans `backend/src/scripts/initDb.js`)
- **Membres de démonstration** : `prenom.nom@demo.echanges.local`, par exemple `rania.jebali@demo.echanges.local`
  - Mot de passe de tous les membres de démonstration : `User1234!`

## Remarques

- Sans clé Gemini, toute l'application fonctionne sauf la page « Mes matches », qui affiche « Matching indisponible pour le moment ».
- La base de données est créée automatiquement au premier lancement, avec des membres de démonstration.
