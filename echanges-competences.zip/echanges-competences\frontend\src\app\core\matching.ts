import { Recommendation, RecommendationReason } from './models';

/** Phrase lisible expliquant pourquoi ce membre est recommandé. */
export function reasonText(r: RecommendationReason): string {
  if (r.kind === 'they_offer') {
    return r.exact ? `Propose ${r.skill}, que vous cherchez` : `Propose ${r.skill} (proche de ${r.matches}, que vous cherchez)`;
  }
  return r.exact ? `Cherche ${r.skill}, que vous proposez` : `Cherche ${r.skill} (proche de ${r.matches}, que vous proposez)`;
}

export function matchName(m: Recommendation): string {
  return m.member ? `${m.member.firstName} ${m.member.lastName}` : `Membre n°${m.userId}`;
}

export function matchInitial(m: Recommendation): string {
  return (m.member?.firstName || '?').charAt(0).toUpperCase();
}

/** Paramètres d'URL qui pré-remplissent le formulaire « Proposer un échange » de la fiche membre. */
export function proposeParams(m: Recommendation): Record<string, string | number> {
  const p = m.proposal;
  const params: Record<string, string | number> = {};
  if (!p) return params;
  if (p.offeredUserSkillId) params['offered'] = p.offeredUserSkillId;
  if (p.requestedUserSkillId) params['requested'] = p.requestedUserSkillId;
  if (p.offeredSkill) params['offeredName'] = p.offeredSkill;
  if (p.requestedSkill) params['requestedName'] = p.requestedSkill;
  return params;
}
