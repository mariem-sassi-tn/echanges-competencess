import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-not-found',
  standalone: true,
  imports: [RouterLink],
  template: `
    <main style="min-height:100vh;display:grid;place-items:center;padding:24px;background:var(--bg-main,#0f172a);color:#e2e8f0;text-align:center">
      <div>
        <p style="font-size:clamp(4rem,12vw,7rem);font-weight:700;margin:0;color:#38bdf8;line-height:1">404</p>
        <h1 style="margin:12px 0 8px;font-size:1.5rem">Page introuvable</h1>
        <p style="color:#94a3b8;margin:0 0 24px">Le lien est peut-être erroné ou la page a été déplacée.</p>
        <a routerLink="/" class="btn btn-primary" style="display:inline-block;padding:12px 24px;border-radius:8px;background:#0284c7;color:#fff;text-decoration:none;font-weight:600">
          Retour à l’accueil
        </a>
      </div>
    </main>
  `
})
export class NotFoundComponent {}
