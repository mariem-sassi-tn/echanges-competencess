import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { Exchange } from '../../core/models';
import { StatusLabelPipe } from '../../core/status-label.pipe';

@Component({
  selector: 'app-exchanges',
  imports: [RouterLink, StatusLabelPipe],
  template: `
    <h1 class="page-title">Mes échanges</h1>
    <p class="page-sub">Suivi des propositions, discussions et clôtures.</p>
    <table class="table">
      <thead>
        <tr><th>Partenaire</th><th>Offre</th><th>Demande</th><th>Statut</th><th></th></tr>
      </thead>
      <tbody>
        @for (e of exchanges; track e.id) {
          <tr>
            <td>{{ partner(e) }}</td>
            <td>{{ e.offeredSkill || '—' }}</td>
            <td>{{ e.requestedSkill || '—' }}</td>
            <td><span class="badge">{{ e.status | statusLabel }}</span></td>
            <td><a class="btn btn-ghost btn-sm" [routerLink]="['/espace/echanges', e.id]">Ouvrir</a></td>
          </tr>
        }
      </tbody>
    </table>
  `
})
export class ExchangesComponent implements OnInit {
  exchanges: Exchange[] = [];

  constructor(private api: ApiService, private auth: AuthService) {}

  ngOnInit() {
    this.api.exchanges().subscribe((r) => (this.exchanges = r.exchanges));
  }

  partner(e: Exchange) {
    const me = this.auth.user()?.id;
    const p = e.requester.id === me ? e.partner : e.requester;
    return `${p.firstName} ${p.lastName}`;
  }
}
