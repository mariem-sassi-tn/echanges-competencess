import { Component } from '@angular/core';
import { ToastService } from './toast.service';

@Component({
  selector: 'app-toast',
  template: `
    @if (toastService.toast(); as t) {
      <div class="toast" [class.toast-error]="t.type === 'error'" [class.toast-success]="t.type === 'success'">
        <span>{{ t.text }}</span>
        <button type="button" (click)="toastService.dismiss()" aria-label="Fermer">✕</button>
      </div>
    }
  `,
  styles: [`
    .toast {
      position: fixed;
      top: 20px;
      right: 20px;
      z-index: 1100;
      display: flex;
      align-items: center;
      gap: 14px;
      max-width: min(400px, calc(100vw - 40px));
      padding: 14px 16px;
      border-radius: 14px;
      box-shadow: var(--shadow);
      font-size: 14px;
      border: 1px solid var(--line);
    }
    .toast-success { background: rgba(126,224,181,.16); color: var(--ok); border-color: rgba(126,224,181,.3); }
    .toast-error { background: rgba(255,123,138,.16); color: var(--danger); border-color: rgba(255,123,138,.3); }
    .toast button {
      background: transparent; border: 0; color: inherit; cursor: pointer;
      font-size: 13px; opacity: .7; line-height: 1;
    }
    .toast button:hover { opacity: 1; }
  `]
})
export class ToastComponent {
  constructor(public toastService: ToastService) {}
}
