import { Component } from '@angular/core';
import { ConfirmService } from './confirm.service';

@Component({
  selector: 'app-confirm-dialog',
  template: `
    @if (confirm.request(); as req) {
      <div class="confirm-backdrop" (click)="confirm.respond(false)">
        <div class="confirm-box" (click)="$event.stopPropagation()">
          <h3>{{ req.title }}</h3>
          <p>{{ req.message }}</p>
          <div class="confirm-actions">
            <button class="btn btn-ghost" type="button" (click)="confirm.respond(false)">{{ req.cancelLabel }}</button>
            <button
              class="btn"
              [class.btn-danger]="req.danger"
              [class.btn-primary]="!req.danger"
              type="button"
              (click)="confirm.respond(true)"
            >{{ req.confirmLabel }}</button>
          </div>
        </div>
      </div>
    }
  `,
  styles: [`
    .confirm-backdrop {
      position: fixed; inset: 0; z-index: 1000;
      background: rgba(10, 6, 24, .6);
      display: grid; place-items: center;
      padding: 20px;
    }
    .confirm-box {
      width: min(420px, 100%);
      background: linear-gradient(180deg, rgba(53, 36, 100, 0.98), rgba(36, 24, 74, 0.98));
      border: 1px solid var(--line);
      border-radius: 20px;
      box-shadow: var(--shadow);
      padding: 22px;
    }
    .confirm-box h3 { margin: 0 0 10px; }
    .confirm-box p { margin: 0 0 18px; color: var(--muted); }
    .confirm-actions { display: flex; justify-content: flex-end; gap: 10px; }
  `]
})
export class ConfirmDialogComponent {
  constructor(public confirm: ConfirmService) {}
}
