import { Component, EventEmitter, Output } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { ToastService } from '../../core/toast.service';

interface ChatLine {
  role: 'user' | 'assistant';
  content: string;
  time: Date;
}

/** Conversation avec l'assistant IA (éphémère, non enregistrée). Affichée dans la bulle flottante. */
@Component({
  selector: 'app-ai-chat',
  imports: [FormsModule, DatePipe, RouterLink],
  template: `
    <header class="chat-header">
      <div class="bot-avatar">✦</div>
      <div>
        <strong>Assistant TalentXchange</strong>
        <div class="online-status"><span></span> En ligne · Réponse automatique</div>
      </div>
    </header>

    <section id="ai-messages" class="chat-messages" aria-live="polite" aria-label="Conversation avec l'assistant">
      @for (line of messages; track $index) {
        <div class="message-row" [class.mine]="line.role === 'user'">
          <div class="bubble">
            <div class="sender">{{ line.role === 'user' ? 'Vous' : 'Assistant IA' }}</div>
            <div class="message-content">{{ line.content }}</div>
            <time>{{ line.time | date:'shortTime' }}</time>
          </div>
        </div>
      }
      @if (loading) {
        <div class="message-row">
          <div class="bubble typing"><span></span><span></span><span></span> L’assistant écrit…</div>
        </div>
      }
    </section>

    <form class="chat-compose" (ngSubmit)="send()">
      <textarea
        [(ngModel)]="draft"
        name="draft"
        rows="2"
        maxlength="2000"
        [disabled]="loading"
        placeholder="Écrivez votre question ici…"
        (keydown.enter)="onEnter($event)"
      ></textarea>
      <button class="btn btn-primary" type="submit" [disabled]="loading || !draft.trim()">
        {{ loading ? 'Envoi…' : 'Envoyer' }} <span aria-hidden="true">➤</span>
      </button>
    </form>
    <p class="chat-note">
      Ne partagez jamais votre mot de passe. Besoin d’une personne ?
      <a routerLink="/espace/contact" (click)="leave.emit()">Contacter l’administration</a>
    </p>
  `,
  styles: [`
    :host { display:flex; flex-direction:column; height:100%; min-height:0; }
    .chat-header { display:flex; align-items:center; gap:12px; padding:14px 16px; border-bottom:1px solid var(--line); }
    .bot-avatar { width:40px; height:40px; display:grid; place-items:center; border-radius:50%; background:rgba(142,224,106,.16); color:var(--accent); font-size:22px; }
    .online-status { color:var(--muted); font-size:12px; margin-top:3px; }
    .online-status span { display:inline-block; width:7px; height:7px; border-radius:50%; background:#65c98b; margin-right:5px; }
    .chat-messages { flex:1; min-height:0; overflow-y:auto; padding:14px; display:flex; flex-direction:column; gap:12px; }
    .message-row { display:flex; justify-content:flex-start; }
    .message-row.mine { justify-content:flex-end; }
    .bubble { max-width:88%; padding:10px 13px; border-radius:15px 15px 15px 4px; background:rgba(255,255,255,.07); overflow-wrap:anywhere; }
    .mine .bubble { background:rgba(142,224,106,.16); border-radius:15px 15px 4px 15px; }
    .sender { font-size:11px; font-weight:700; color:var(--muted); margin-bottom:4px; }
    .message-content { white-space:pre-wrap; line-height:1.5; }
    .bubble time { display:block; text-align:right; color:var(--muted); font-size:10px; margin-top:5px; }
    .chat-compose { display:flex; align-items:flex-end; gap:8px; padding:10px 12px; border-top:1px solid var(--line); }
    .chat-compose textarea { flex:1; min-width:0; resize:none; border:1px solid var(--line); border-radius:12px; padding:10px; color:inherit; background:rgba(255,255,255,.04); font:inherit; }
    .chat-compose button { white-space:nowrap; }
    .chat-compose button:disabled { opacity:.55; cursor:not-allowed; }
    .chat-note { color:var(--muted); font-size:11px; padding:0 14px 12px; margin:0; }
    .chat-note a { color:var(--accent); }
    .typing { color:var(--muted); font-size:13px; }
    .typing span { display:inline-block; width:5px; height:5px; border-radius:50%; background:currentColor; margin-right:3px; animation:pulse 1s infinite alternate; }
    .typing span:nth-child(2) { animation-delay:.2s; } .typing span:nth-child(3) { animation-delay:.4s; }
    @keyframes pulse { from { opacity:.25; transform:translateY(0); } to { opacity:1; transform:translateY(-3px); } }
  `]
})
export class AiChatComponent {
  /** Émis quand le membre quitte la bulle (lien vers la page de contact de l'administration). */
  @Output() leave = new EventEmitter<void>();

  draft = '';
  loading = false;
  messages: ChatLine[] = [{
    role: 'assistant',
    content: 'Bonjour ! 👋 Je suis l’assistant TalentXchange. Je peux vous aider avec votre compte, vos compétences et les échanges. Comment puis-je vous aider ?',
    time: new Date()
  }];

  constructor(private api: ApiService, private toast: ToastService) {}

  onEnter(event: Event) {
    const keyboardEvent = event as KeyboardEvent;
    if (!keyboardEvent.shiftKey) {
      keyboardEvent.preventDefault();
      this.send();
    }
  }

  private scrollToEnd() {
    setTimeout(() => {
      const el = document.getElementById('ai-messages');
      if (el) el.scrollTop = el.scrollHeight;
    }, 0);
  }

  send() {
    const content = this.draft.trim();
    if (!content || this.loading) return;
    this.messages.push({ role: 'user', content, time: new Date() });
    this.draft = '';
    this.loading = true;
    this.scrollToEnd();
    const history = this.messages.slice(0, -1).slice(-10).map(({ role, content: text }) => ({ role, content: text }));
    this.api.supportAiChat(content, history).subscribe({
      next: (result) => {
        this.messages.push({ role: 'assistant', content: result.reply, time: new Date() });
        this.loading = false;
        this.scrollToEnd();
      },
      error: (err) => {
        this.loading = false;
        const msg = err.error?.message || 'Impossible de contacter l’assistant. Réessayez dans un instant.';
        this.messages.push({ role: 'assistant', content: msg, time: new Date() });
        this.toast.error(msg);
        this.scrollToEnd();
      }
    });
  }
}
