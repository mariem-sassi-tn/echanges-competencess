import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../../core/auth.service';
import { ApiService } from '../../core/api.service';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';
import { CvData } from '../../core/models';

interface ExtendedCvData extends CvData {
  keywords?: string[];
}

@Component({
  selector: 'app-profile',
  standalone: true,
  imports: [FormsModule],
  template: `
    <div class="profile-container">
      <!-- En-tête -->
      <header class="page-header no-print">
        <h1>Profil</h1>
        <p>Gérez vos informations personnelles et votre CV.</p>
      </header>

      <!-- Alertes -->
      @if (ok) { 
        <div class="alert alert-success no-print">
          ✅ {{ okMessage }}
        </div> 
      }
      @if (error) { 
        <div class="alert alert-error no-print">
          ⚠️ {{ error }}
        </div> 
      }

      <!-- Grille Principale -->
      <div class="profile-grid no-print">
        
        <!-- Bloc 1 : Infos Personnelles -->
        <section class="card-box">
          <div class="card-title">
            <h2>Informations personnelles</h2>
          </div>

          <div class="avatar-container">
            @if (avatarPreview) {
              <img [src]="avatarPreview" alt="Photo de profil" class="avatar-img">
            } @else {
              <div class="avatar-placeholder">
                {{ (firstName || '?').charAt(0).toUpperCase() }}
              </div>
            }
            <div class="avatar-actions">
              <label class="btn btn-secondary btn-sm">
                📷 Modifier la photo
                <input type="file" accept="image/*" (change)="onAvatarSelected($event)" style="display:none">
              </label>
              @if (avatarPreview) {
                <button class="btn btn-danger-ghost btn-sm" type="button" (click)="removeAvatar()">Supprimer</button>
              }
            </div>
          </div>

          <form (ngSubmit)="save()" class="form-layout">
            <div class="form-row">
              <div class="form-group">
                <label>Prénom</label>
                <input [(ngModel)]="firstName" name="firstName" placeholder="Votre prénom" required>
              </div>
              <div class="form-group">
                <label>Nom</label>
                <input [(ngModel)]="lastName" name="lastName" placeholder="Votre nom" required>
              </div>
            </div>

            <div class="form-group">
              <label>Ville</label>
              <input [(ngModel)]="city" name="city" placeholder="Votre ville">
            </div>

            <div class="form-group">
              <label>Bio</label>
              <textarea [(ngModel)]="bio" name="bio" rows="4" placeholder="Présentez-vous brièvement..."></textarea>
            </div>

            <div class="form-actions">
              <button class="btn btn-primary" type="submit">Enregistrer le profil</button>
            </div>
          </form>
        </section>

        <!-- Bloc 2 : Mon CV -->
        <section class="card-box">
          <div class="card-title">
            <h2>Mon CV</h2>
            <p class="section-desc">
              Renseignez votre parcours pour générer et télécharger votre CV en PDF.
            </p>
          </div>

          <form (ngSubmit)="saveCv()" class="form-layout">
            <div class="form-group">
              <label>Titre du poste</label>
              <input 
                [(ngModel)]="cv.headline" 
                name="headline" 
                placeholder="Nom du poste"
              >
            </div>

            

            

            <!-- Formations -->
            <div class="cv-subsection">
              <div class="subsection-header">
                <h3> Diplôme</h3>
                <button class="btn-link" type="button" (click)="addEducation()">+ Ajouter une formation</button>
              </div>

              @for (edu of cv.educations; track $index) {
                <div class="item-card">
                  <div class="form-row">
                    <div class="form-group">
                      <label>Diplôme</label>
                      <input [(ngModel)]="edu.degree" [name]="'eduDegree'+$index" placeholder="Nom du diplôme">
                    </div>
                    <div class="form-group">
                      <label>Établissement</label>
                      <input [(ngModel)]="edu.school" [name]="'eduSchool'+$index" placeholder="Nom de l'établissement">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Année d'obtention : </label>
                    <input [(ngModel)]="edu.period" [name]="'eduPeriod'+$index" placeholder="Année d'obtention : ">
                  </div>
                  <button class="btn btn-danger-ghost btn-sm" type="button" (click)="removeEducation($index)">Supprimer</button>
                </div>
              }
            </div>
            <!-- Expériences -->
            <div class="cv-subsection">
              <div class="subsection-header">
                <h3>Expériences</h3>
                <button class="btn-link" type="button" (click)="addExperience()">+ Ajouter une expérience</button>
              </div>

              @for (exp of cv.experiences; track $index) {
                <div class="item-card">
                  <div class="form-row">
                    <div class="form-group">
                      <label>Poste</label>
                      <input [(ngModel)]="exp.role" [name]="'expRole'+$index" placeholder="Intitulé du poste">
                    </div>
                    <div class="form-group">
                      <label>Entreprise</label>
                      <input [(ngModel)]="exp.company" [name]="'expCompany'+$index" placeholder="Nom de l'entreprise">
                    </div>
                  </div>
                  <div class="form-group">
                    <label>Période</label>
                    <input [(ngModel)]="exp.period" [name]="'expPeriod'+$index" placeholder="les années">
                  </div>
                  <div class="form-group">
                    <label>Description</label>
                    <textarea [(ngModel)]="exp.description" [name]="'expDesc'+$index" rows="2" placeholder="Missions et réalisations..."></textarea>
                  </div>  
                  <button class="btn btn-danger-ghost btn-sm" type="button" (click)="removeExperience($index)">Supprimer</button>
                </div>
              }
            </div>

            <div class="form-actions row-actions">
              <button class="btn btn-primary" type="submit">Enregistrer le CV</button>
              <button class="btn btn-secondary" type="button" (click)="print()">🖨 Imprimer / PDF</button>
            </div>
          </form>
        </section>

      </div>

      <!-- Aperçu du CV -->
      <article class="card-box cv-preview-box" id="cv-preview">
        <header class="preview-header">
          @if (avatarPreview) {
            <img [src]="avatarPreview" alt="Photo" class="preview-avatar">
          }
          <div>
            <h2 class="preview-name">{{ firstName }} {{ lastName }}</h2>
            <p class="preview-headline">{{ cv.headline || 'Titre du poste non renseigné' }}</p>
            @if (city) { <p class="preview-city">📍 {{ city }}</p> }
          </div>
        </header>

        @if (cv.summary) {
          <div class="preview-section">
            <p class="preview-summary">{{ cv.summary }}</p>
          </div>
        }

        @if (keywords.length || offeredSkills.length) {
          <div class="preview-section">
            <h3 class="preview-subtitle">Mots-clés & Compétences</h3>
            <div class="skills-tags">
              @for (kw of keywords; track kw) {
                <span class="skill-tag">{{ kw }}</span>
              }
              @for (skill of offeredSkills; track skill) {
                @if (!keywords.includes(skill)) {
                  <span class="skill-tag">{{ skill }}</span>
                }
              }
            </div>
          </div>
        }

        @if (cv.experiences.length) {
          <div class="preview-section">
            <h3 class="preview-subtitle">Expériences professionnelles</h3>
            @for (exp of cv.experiences; track $index) {
              <div class="preview-item">
                <div class="preview-item-header">
                  <strong>{{ exp.role || 'Poste' }}</strong> chez <span>{{ exp.company }}</span>
                  <span class="preview-period">{{ exp.period }}</span>
                </div>
                @if (exp.description) { <p class="preview-desc">{{ exp.description }}</p> }
              </div>
            }
          </div>
        }

        @if (cv.educations.length) {
          <div class="preview-section">
            <h3 class="preview-subtitle">Formations</h3>
            @for (edu of cv.educations; track $index) {
              <div class="preview-item">
                <div class="preview-item-header">
                  <strong>{{ edu.degree || 'Diplôme' }}</strong> — <span>{{ edu.school }}</span>
                  <span class="preview-period">{{ edu.period }}</span>
                </div>
              </div>
            }
          </div>
        }

        @if (!cv.experiences.length && !cv.educations.length && !cv.summary && !keywords.length) {
          <p class="text-muted">Complétez les informations pour générer l'aperçu de votre CV.</p>
        }
      </article>

    </div>
  `,
  styles: [`
    .profile-container {
      max-width: 1140px;
      margin: 0 auto;
      padding: 24px;
      color: #f1f5f9;
      font-family: system-ui, -apple-system, sans-serif;
    }

    .page-header h1 {
      font-size: 2rem;
      font-weight: 700;
      margin: 0 0 6px 0;
      color: #ffffff;
    }

    .page-header p {
      color: #94a3b8;
      font-size: 0.95rem;
      margin: 0 0 24px 0;
    }

    /* Alertes */
    .alert {
      padding: 12px 16px;
      border-radius: 10px;
      margin-bottom: 20px;
      font-size: 0.9rem;
      font-weight: 500;
    }
    .alert-success {
      background: rgba(34, 197, 94, 0.15);
      border: 1px solid rgba(34, 197, 94, 0.4);
      color: #4ade80;
    }
    .alert-error {
      background: rgba(239, 68, 68, 0.15);
      border: 1px solid rgba(239, 68, 68, 0.4);
      color: #fca5a5;
    }

    /* Grille principale */
    .profile-grid {
      display: grid;
      grid-template-columns: 1fr 1.15fr;
      gap: 24px;
      align-items: start;
    }

    @media (max-width: 920px) {
      .profile-grid {
        grid-template-columns: 1fr;
      }
    }

    /* Cartes */
    .card-box {
      background: rgba(30, 27, 75, 0.45);
      backdrop-filter: blur(12px);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 16px;
      padding: 24px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
    }

    .card-title h2 {
      font-size: 1.25rem;
      font-weight: 600;
      margin: 0 0 4px 0;
      color: #ffffff;
    }

    .section-desc {
      font-size: 0.85rem;
      color: #94a3b8;
      margin: 0 0 18px 0;
      line-height: 1.4;
    }

    /* Avatar */
    .avatar-container {
      display: flex;
      align-items: center;
      gap: 16px;
      margin: 18px 0 22px 0;
      padding-bottom: 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
    }

    .avatar-img {
      width: 68px;
      height: 68px;
      border-radius: 50%;
      object-fit: cover;
      border: 2px solid #22c55e;
    }

    .avatar-placeholder {
      width: 68px;
      height: 68px;
      border-radius: 50%;
      background: #22c55e;
      color: #052e16;
      font-size: 1.7rem;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
    }

    .avatar-actions {
      display: flex;
      flex-direction: column;
      gap: 8px;
    }

    /* Formulaires & Input */
    .form-layout {
      display: flex;
      flex-direction: column;
      gap: 16px;
    }

    .form-row {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 12px;
    }

    .form-group {
      display: flex;
      flex-direction: column;
      gap: 6px;
    }

    .form-group label {
      font-size: 0.85rem;
      font-weight: 600;
      color: #cbd5e1;
    }

    input, textarea {
      width: 100%;
      padding: 10px 12px;
      border-radius: 8px;
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.12);
      color: #ffffff;
      font-size: 0.875rem;
      outline: none;
      box-sizing: border-box;
      transition: border-color 0.2s ease;
    }

    input::placeholder, textarea::placeholder {
      color: #64748b;
      opacity: 0.85;
    }

    input:focus, textarea:focus {
      border-color: #22c55e;
    }

    /* Styles Mots-Clés / Chips */
    .keyword-input-wrapper {
      display: flex;
      gap: 8px;
    }

    .keywords-list {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-top: 8px;
    }

    .keyword-chip {
      background: rgba(56, 189, 248, 0.15);
      color: #38bdf8;
      border: 1px solid rgba(56, 189, 248, 0.3);
      padding: 4px 10px;
      border-radius: 16px;
      font-size: 0.8rem;
      display: inline-flex;
      align-items: center;
      gap: 6px;
    }

    .keyword-chip button {
      background: none;
      border: none;
      color: #38bdf8;
      font-size: 1rem;
      cursor: pointer;
      line-height: 1;
      padding: 0;
    }

    /* Elements dynamiques CV */
    .cv-subsection {
      display: flex;
      flex-direction: column;
      gap: 12px;
      margin-top: 8px;
    }

    .subsection-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .subsection-header h3 {
      font-size: 0.95rem;
      margin: 0;
      color: #e2e8f0;
    }

    .item-card {
      background: rgba(15, 23, 42, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.06);
      border-radius: 10px;
      padding: 14px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    /* Boutons */
    .btn {
      font-weight: 600;
      font-size: 0.875rem;
      padding: 10px 18px;
      border-radius: 8px;
      cursor: pointer;
      border: none;
      transition: all 0.2s ease;
    }

    .btn-primary {
      background: #22c55e;
      color: #052e16;
    }
    .btn-primary:hover {
      background: #16a34a;
    }

    .btn-secondary {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid rgba(255, 255, 255, 0.15);
      color: #f1f5f9;
    }
    .btn-secondary:hover {
      background: rgba(255, 255, 255, 0.15);
    }

    .btn-danger-ghost {
      background: transparent;
      color: #fca5a5;
      border: 1px solid rgba(239, 68, 68, 0.3);
      padding: 6px 12px;
    }
    .btn-danger-ghost:hover {
      background: rgba(239, 68, 68, 0.15);
    }

    .btn-sm {
      font-size: 0.8rem;
      padding: 6px 12px;
    }

    .btn-link {
      background: none;
      border: none;
      color: #4ade80;
      font-size: 0.825rem;
      font-weight: 600;
      cursor: pointer;
      padding: 0;
    }
    .btn-link:hover {
      text-decoration: underline;
    }

    .form-actions {
      margin-top: 8px;
    }
    .row-actions {
      display: flex;
      gap: 10px;
      flex-wrap: wrap;
    }

    /* Aperçu du CV */
    .cv-preview-box {
      margin-top: 28px;
      max-width: 100%;
      background: rgba(15, 23, 42, 0.6);
    }

    .preview-header {
      display: flex;
      align-items: center;
      gap: 18px;
      border-bottom: 1px solid rgba(255, 255, 255, 0.08);
      padding-bottom: 16px;
      margin-bottom: 18px;
    }

    .preview-avatar {
      width: 64px;
      height: 64px;
      border-radius: 50%;
      object-fit: cover;
    }

    .preview-name {
      font-size: 1.4rem;
      margin: 0;
      color: #ffffff;
    }

    .preview-headline {
      margin: 2px 0 0 0;
      color: #38bdf8;
      font-weight: 500;
    }

    .preview-city {
      margin: 4px 0 0 0;
      color: #94a3b8;
      font-size: 0.85rem;
    }

    .preview-section {
      margin-bottom: 18px;
    }

    .preview-subtitle {
      font-size: 1rem;
      color: #f1f5f9;
      border-bottom: 1px solid rgba(255, 255, 255, 0.06);
      padding-bottom: 6px;
      margin: 0 0 10px 0;
    }

    .preview-summary {
      color: #cbd5e1;
      line-height: 1.5;
      font-size: 0.925rem;
    }

    .preview-item {
      margin-bottom: 10px;
    }

    .preview-item-header {
      color: #e2e8f0;
      font-size: 0.9rem;
    }

    .preview-period {
      color: #94a3b8;
      font-size: 0.825rem;
      margin-left: 8px;
    }

    .preview-desc {
      margin: 4px 0 0 0;
      color: #94a3b8;
      font-size: 0.85rem;
    }

    .skills-tags {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
    }

    .skill-tag {
      background: rgba(34, 197, 94, 0.15);
      color: #4ade80;
      border: 1px solid rgba(34, 197, 94, 0.3);
      padding: 4px 10px;
      border-radius: 20px;
      font-size: 0.8rem;
    }

    .text-muted {
      color: #94a3b8;
      font-size: 0.9rem;
    }

    @media print {
      .no-print {
        display: none !important;
      }
      .cv-preview-box {
        background: #ffffff !important;
        color: #000000 !important;
        border: none !important;
        box-shadow: none !important;
      }
      .preview-name, .preview-subtitle {
        color: #000000 !important;
      }
      .preview-headline {
        color: #0284c7 !important;
      }
      .preview-summary, .preview-item-header, .preview-desc, .text-muted {
        color: #333333 !important;
      }
      .skill-tag {
        background: #f1f5f9 !important;
        color: #000000 !important;
        border-color: #ccc !important;
      }
    }
  `]
})
export class ProfileComponent implements OnInit {
  firstName = '';
  lastName = '';
  city = '';
  bio = '';
  ok = false;
  okMessage = '';
  error = '';
  avatarPreview: string | null = null;
  offeredSkills: string[] = [];
  keywords: string[] = [];
  newKeyword = '';

  cv: ExtendedCvData = { headline: '', summary: '', experiences: [], educations: [] };

  constructor(
    private auth: AuthService,
    private api: ApiService,
    private confirm: ConfirmService,
    private toast: ToastService
  ) {}

  ngOnInit() {
    const u = this.auth.user();
    if (!u) return;
    this.firstName = u.firstName;
    this.lastName = u.lastName;
    this.city = u.city || '';
    this.bio = u.bio || '';
    this.avatarPreview = u.avatarUrl || null;
    
    const userCvData = u.cvData as ExtendedCvData | undefined;

    this.cv = {
      headline: userCvData?.headline || '',
      summary: userCvData?.summary || '',
      experiences: userCvData?.experiences ? [...userCvData.experiences] : [],
      educations: userCvData?.educations ? [...userCvData.educations] : []
    };

    if (userCvData?.keywords) {
      this.keywords = [...userCvData.keywords];
    }

    this.api.mySkills().subscribe((r) => {
      this.offeredSkills = r.skills.filter((s) => s.type === 'offer').map((s) => s.skillName || '').filter(Boolean);
    });
  }

  addKeyword() {
    const kw = this.newKeyword.trim();
    if (kw && !this.keywords.includes(kw)) {
      this.keywords.push(kw);
      this.newKeyword = '';
    }
  }

  removeKeyword(index: number) {
    this.keywords.splice(index, 1);
  }

  onAvatarSelected(event: Event) {
    const input = event.target as HTMLInputElement;
    const file = input.files?.[0];
    if (!file) return;
    if (!file.type.startsWith('image/')) {
      this.toast.error('Veuillez sélectionner un fichier image.');
      input.value = '';
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const size = 320;
        const canvas = document.createElement('canvas');
        canvas.width = size;
        canvas.height = size;
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        const scale = Math.max(size / img.width, size / img.height);
        const w = img.width * scale;
        const h = img.height * scale;
        ctx.drawImage(img, (size - w) / 2, (size - h) / 2, w, h);
        this.avatarPreview = canvas.toDataURL('image/jpeg', 0.82);
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
    input.value = '';
  }

  removeAvatar() {
    this.avatarPreview = null;
  }

  addExperience() {
    this.cv.experiences.push({ role: '', company: '', period: '', description: '' });
  }

  removeExperience(index: number) {
    this.cv.experiences.splice(index, 1);
  }

  addEducation() {
    this.cv.educations.push({ degree: '', school: '', period: '' });
  }

  removeEducation(index: number) {
    this.cv.educations.splice(index, 1);
  }

  print() {
    window.print();
  }

  async save() {
    const ok = await this.confirm.ask('Voulez-vous enregistrer les modifications de votre profil ?');
    if (!ok) return;
    this.persist('Profil mis à jour.');
  }

  async saveCv() {
    const ok = await this.confirm.ask('Voulez-vous enregistrer votre CV ?');
    if (!ok) return;
    this.persist('CV enregistré.');
  }

  private persist(successMessage: string) {
    this.ok = false;
    this.error = '';

    const payloadCv = {
      ...this.cv,
      keywords: this.keywords
    };

    this.api
      .updateProfile({
        firstName: this.firstName,
        lastName: this.lastName,
        city: this.city,
        bio: this.bio,
        avatarUrl: this.avatarPreview,
        cvData: payloadCv
      })
      .subscribe({
        next: (res) => {
          this.auth.user.set(res.user);
          localStorage.setItem('ec_user', JSON.stringify(res.user));
          this.ok = true;
          this.okMessage = successMessage;
          this.toast.success(successMessage);
        },
        error: (err) => {
          this.error = err.error?.message || 'Erreur';
          this.toast.error(this.error);
        }
      });
  }
}