import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { MatchingBucket, MatchingStats } from '../../core/models';

@Component({
  selector: 'app-admin-matching',
  template: `
    <h1 class="page-title">Matching IA</h1>
    <p class="page-sub">Le moteur de recommandation aide-t-il vraiment les membres à s’échanger des compétences ?</p>

    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:18px">
      @for (d of periods; track d) {
        <button type="button" class="btn btn-sm" [class.btn-primary]="d === days" [class.btn-ghost]="d !== days" (click)="load(d)">{{ d }} jours</button>
      }
      @if (stats) {
        @if (stats.ml.up) {
          <span class="badge">● Service IA actif · {{ stats.ml.model }}</span>
        } @else if (stats.ml.configured) {
          <span class="badge danger">● Service IA injoignable</span>
        } @else {
          <span class="badge warn">● Service IA non configuré (ML_SERVICE_URL vide)</span>
        }
      }
    </div>

    @if (error) {
      <div class="alert">Impossible de charger les statistiques.</div>
    }

    @if (stats) {
      <div class="grid grid-4">
        <article class="card">
          <div style="color:var(--muted)">Recommandations vues</div>
          <h2>{{ stats.funnel.shown }}</h2>
          <div style="color:var(--muted);font-size:13px">{{ stats.funnel.usersServed }} membre(s) servi(s)</div>
        </article>
        <article class="card">
          <div style="color:var(--muted)">Profils ouverts</div>
          <h2>{{ stats.funnel.clicked }}</h2>
          <div style="color:var(--muted);font-size:13px">Taux : {{ pct(stats.funnel.clickRate) }}</div>
        </article>
        <article class="card">
          <div style="color:var(--muted)">Échanges proposés</div>
          <h2>{{ stats.funnel.proposed }}</h2>
          <div style="color:var(--muted);font-size:13px">Taux : {{ pct(stats.funnel.proposeRate) }}</div>
        </article>
        <article class="card">
          <div style="color:var(--muted)">Score moyen affiché</div>
          <h2>{{ stats.funnel.avgScore ?? '—' }}</h2>
          <div style="color:var(--muted);font-size:13px">{{ stats.funnel.proposedWithoutReco }} proposition(s) hors recommandation</div>
        </article>
      </div>

      <h3 style="margin-top:28px">Le score prédit-il le comportement ?</h3>
      <p style="color:var(--muted);margin-top:-10px">Si le modèle est bon, les taux montent avec le score. Chiffres en paires membre / candidat uniques.</p>
      <table class="table">
        <thead><tr><th>Tranche de score</th><th>Vues</th><th>Profils ouverts</th><th>Échanges proposés</th></tr></thead>
        <tbody>
          @for (b of stats.buckets; track b.bucket) {
            <tr>
              <td>{{ bucketLabel(b) }}</td>
              <td>{{ b.shown }}</td>
              <td>{{ b.clicked }} <span style="color:var(--muted)">({{ pct(b.clickRate) }})</span></td>
              <td>{{ b.proposed }} <span style="color:var(--muted)">({{ pct(b.proposeRate) }})</span></td>
            </tr>
          }
        </tbody>
      </table>

      <h3 style="margin-top:28px">Qualité des données</h3>
      <p style="color:var(--muted);margin-top:-10px">
        {{ stats.members.withSkills }} membre(s) sur {{ stats.members.total }} ont renseigné des compétences
        ({{ coverage }}). Sans compétences, le moteur ne peut rien recommander.
      </p>
    }
  `
})
export class AdminMatchingComponent implements OnInit {
  readonly periods = [7, 30, 90];
  days = 30;
  stats: MatchingStats | null = null;
  error = false;

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.load(this.days);
  }

  load(days: number) {
    this.days = days;
    this.error = false;
    this.api.matchingStats(days).subscribe({
      next: (s) => (this.stats = s),
      error: () => (this.error = true)
    });
  }

  pct(v: number | null): string {
    return v === null ? '—' : `${v} %`;
  }

  bucketLabel(b: MatchingBucket): string {
    if (b.bucket === 'high') return 'Fort (70 % et plus)';
    if (b.bucket === 'medium') return 'Moyen (40 à 69 %)';
    return 'Faible (moins de 40 %)';
  }

  get coverage(): string {
    const m = this.stats?.members;
    return m && m.total > 0 ? `${Math.round((m.withSkills / m.total) * 100)} %` : '—';
  }
}
