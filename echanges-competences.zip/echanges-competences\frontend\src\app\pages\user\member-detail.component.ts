import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { User, UserSkill, CvData } from '../../core/models';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';

@Component({
  selector: 'app-member-detail',
  standalone: true,
  imports: [FormsModule],
  template: `
    @if (member) {
      <div style="display:flex;align-items:center;gap:16px;margin-bottom:6px">
        @if (member.avatarUrl) {
          <img [src]="member.avatarUrl" alt="" style="width:60px;height:60px;border-radius:50%;object-fit:cover;border:1px solid var(--line)">
        } @else {
          <div style="width:60px;height:60px;border-radius:50%;background:var(--accent);display:grid;place-items:center;font-weight:700;font-size:22px;color:#0a0618">
            {{ member.firstName.charAt(0) }}
          </div>
        }
        <h1 class="page-title" style="margin:0">{{ member.firstName }} {{ member.lastName }}</h1>
      </div>
      <p class="page-sub">{{ member.city }} @if (member.rating) { · ★ {{ member.rating }} }</p>
      <p>{{ member.bio }}</p>

      <div class="grid grid-2">
        <article class="card">
          <h3>Compétences</h3>
          @for (s of member.skills; track s.id) {
            <p><span class="badge">{{ s.type === 'offer' ? 'Offre' : 'Besoin' }}</span> {{ s.skillName }} · {{ s.level }}</p>
          }
        </article>

        <form class="card" (ngSubmit)="propose()">
          <h3>Proposer un échange</h3>
          @if (ok) { <div class="success">Proposition envoyée.</div> }
          @if (error) { <div class="alert">{{ error }}</div> }
          <div class="field">
            <label>J’offre</label>
            <select [(ngModel)]="offeredUserSkillId" name="offeredUserSkillId">
              <option [ngValue]="0">Choisir</option>
              @for (s of myOffers; track s.id) {
                <option [ngValue]="s.id">{{ s.skillName }}</option>
              }
            </select>
          </div>
          <div class="field">
            <label>Je demande</label>
            <select [(ngModel)]="requestedUserSkillId" name="requestedUserSkillId">
              <option [ngValue]="0">Choisir</option>
              @for (s of partnerOffers; track s.id) {
                <option [ngValue]="s.id">{{ s.skillName }}</option>
              }
            </select>
          </div>
          <div class="field">
            <label style="display:flex;justify-content:space-between;align-items:center;gap:8px">
              Message
              <button type="button" class="btn btn-ghost btn-sm" [disabled]="drafting" (click)="draftMessage()">
                {{ drafting ? 'Rédaction…' : '✨ Rédiger avec l’IA' }}
              </button>
            </label>
            <textarea [(ngModel)]="message" name="message"></textarea>
          </div>
          <button class="btn btn-primary" type="submit">Envoyer la proposition</button>
        </form>
      </div>

      <!-- Section CV Harmonisée avec le Thème Talentia -->
      @if (cv) {
        <article class="card" style="margin-top: 24px; padding: 24px;">
          
          <!-- En-tête -->
          <div style="border-bottom: 1px solid var(--line); padding-bottom: 16px; margin-bottom: 24px; display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 12px;">
            <div>
              <span style="text-transform: uppercase; letter-spacing: 1.2px; font-size: 0.75rem; color: #a78bfa; font-weight: 700;">PROFIL ET PARCOURS</span>
              <h2 style="margin: 4px 0 0 0; font-size: 1.4rem; font-weight: 700; color: #ffffff;">Portfolio Professionnel</h2>
            </div>

            @if (cv.headline) {
              <div style="background: rgba(167, 139, 250, 0.12); border: 1px solid rgba(167, 139, 250, 0.3); color: #c084fc; padding: 6px 16px; border-radius: 20px; font-size: 0.9rem; font-weight: 600;">
                Poste : <strong style="color: #ffffff;">{{ cv.headline }}</strong>
              </div>
            }
          </div>

          <!-- Résumé -->
          @if (cv.summary) {
            <div style="background: rgba(255, 255, 255, 0.02); border: 1px solid var(--line); padding: 14px 18px; border-radius: 8px; margin-bottom: 24px;">
              <span style="font-size: 0.8rem; text-transform: uppercase; color: #a78bfa; font-weight: 700; display: block; margin-bottom: 4px;">Présentation générale :</span>
              <p style="margin: 0; color: #e2e8f0; line-height: 1.5; font-size: 0.92rem;">{{ cv.summary }}</p>
            </div>
          }

          <div class="grid grid-2" style="gap: 24px; align-items: start;">
            
            <!-- Bloc Expériences -->
            @if (cv.experiences && cv.experiences.length > 0) {
              <div>
                <h3 style="margin: 0 0 14px 0; font-size: 1.05rem; color: #ffffff; border-bottom: 2px solid var(--accent); padding-bottom: 6px;">
                  💼 Expériences Professionnelles
                </h3>
                
                <div style="display: flex; flex-direction: column; gap: 14px;">
                  @for (exp of cv.experiences; track $index) {
                    <div style="background: rgba(0, 0, 0, 0.2); border: 1px solid var(--line); padding: 14px; border-radius: 8px;">
                      
                      <div style="margin-bottom: 6px;">
                        <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;">Poste : </span>
                        <strong style="color: #ffffff; font-size: 0.95rem;">{{ exp.role || 'Non spécifié' }}</strong>
                      </div>

                      @if (exp.company) {
                        <div style="margin-bottom: 6px;">
                          <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;">Entreprise : </span>
                          <span style="color: var(--accent); font-weight: 600;">{{ exp.company }}</span>
                        </div>
                      }

                      @if (exp.period) {
                        <div style="margin-bottom: 6px;">
                          <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;">Période : </span>
                          <span style="color: var(--accent); font-weight: 600; background: rgba(163, 230, 53, 0.12); padding: 2px 8px; border-radius: 4px; font-size: 0.85rem;">{{ exp.period }}</span>
                        </div>
                      }

                      @if (exp.description) {
                        <div style="margin-top: 8px; border-top: 1px dashed var(--line); padding-top: 6px;">
                          <span style="color: #94a3b8; font-size: 0.82rem; font-weight: 600; display: block; margin-bottom: 2px;">Missions & Réalisations :</span>
                          <p style="margin: 0; color: #cbd5e1; font-size: 0.88rem; line-height: 1.4; white-space: pre-line;">{{ exp.description }}</p>
                        </div>
                      }
                    </div>
                  }
                </div>
              </div>
            }

            <!-- Bloc Formations -->
            @if (cv.educations && cv.educations.length > 0) {
              <div>
                <h3 style="margin: 0 0 14px 0; font-size: 1.05rem; color: #ffffff; border-bottom: 2px solid #a78bfa; padding-bottom: 6px;">
                  🎓 Formations & Diplômes
                </h3>

                <div style="display: flex; flex-direction: column; gap: 14px;">
                  @for (edu of cv.educations; track $index) {
                    <div style="background: rgba(0, 0, 0, 0.2); border: 1px solid var(--line); padding: 14px; border-radius: 8px;">
                      
                      <div style="margin-bottom: 6px;">
                        <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;">Diplôme / Formation : </span>
                        <strong style="color: #ffffff; font-size: 0.95rem;">{{ edu.degree || 'Non spécifié' }}</strong>
                      </div>

                      @if (edu.school) {
                        <div style="margin-bottom: 6px;">
                          <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;">Établissement : </span>
                          <span style="color: #e2e8f0; font-weight: 500;">{{ edu.school }}</span>
                        </div>
                      }

                      @if (edu.period) {
                        <div>
                          <span style="color: #94a3b8; font-size: 0.85rem; font-weight: 600;">Année d'obtention : </span>
                          <span style="color: #a78bfa; font-weight: 600; background: rgba(167, 139, 250, 0.12); padding: 2px 8px; border-radius: 4px; font-size: 0.85rem;">{{ edu.period }}</span>
                        </div>
                      }
                    </div>
                  }
                </div>
              </div>
            }

          </div>
        </article>
      }
    }
  `
})
export class MemberDetailComponent implements OnInit {
  member: User | null = null;
  cv: CvData | null = null;
  myOffers: UserSkill[] = [];
  partnerOffers: UserSkill[] = [];
  offeredUserSkillId = 0;
  requestedUserSkillId = 0;
  message = '';
  drafting = false;
  ok = false;
  error = '';

  constructor(
    private route: ActivatedRoute,
    private api: ApiService,
    private auth: AuthService,
    private router: Router,
    private confirm: ConfirmService,
    private toast: ToastService
  ) {}

  ngOnInit() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    if (id === this.auth.user()?.id) {
      this.router.navigateByUrl('/espace/profil');
      return;
    }

    // Arrivée depuis « Mes matches » : l'échange suggéré par l'IA est pré-rempli (modifiable).
    const qp = this.route.snapshot.queryParamMap;
    const offered = Number(qp.get('offered'));
    const requested = Number(qp.get('requested'));
    if (offered > 0) this.offeredUserSkillId = offered;
    if (requested > 0) this.requestedUserSkillId = requested;
    const offeredName = qp.get('offeredName');
    const requestedName = qp.get('requestedName');
    if (requestedName && offeredName) {
      this.message = `Bonjour ! Je cherche ${requestedName} et je peux vous apprendre ${offeredName}. On échange ?`;
    } else if (requestedName) {
      this.message = `Bonjour ! Je cherche ${requestedName}, seriez-vous disponible pour m’aider ?`;
    }

    this.api.member(id).subscribe((r) => {
      this.member = r.user;
      this.partnerOffers = (r.user.skills || []).filter((s) => s.type === 'offer');

      // Parsing du CV
      const rawCv = (r.user as any).cvData || (r.user as any).cv_data;
      if (rawCv) {
        try {
          this.cv = typeof rawCv === 'string' ? JSON.parse(rawCv) : rawCv;
        } catch (e) {
          console.error('Erreur parsing CV:', e);
          this.cv = null;
        }
      }
    });

    this.api.mySkills().subscribe((r) => (this.myOffers = r.skills.filter((s) => s.type === 'offer')));
  }

  draftMessage() {
    if (!this.member || this.drafting) return;
    this.drafting = true;
    this.api
      .draftExchangeMessage({
        partnerId: this.member.id,
        offeredUserSkillId: this.offeredUserSkillId || null,
        requestedUserSkillId: this.requestedUserSkillId || null
      })
      .subscribe({
        next: (r) => {
          this.message = r.message;
          this.drafting = false;
          if (!r.ai) this.toast.success('Message prérempli (l’IA est indisponible, modèle standard utilisé). Relisez-le avant l’envoi.');
        },
        error: (err) => {
          this.drafting = false;
          this.toast.error(err.error?.message || 'Impossible de rédiger le message.');
        }
      });
  }

  async propose() {
    if (!this.member) return;
    const ok = await this.confirm.ask(
      `Voulez-vous envoyer une proposition d'échange à ${this.member.firstName} ${this.member.lastName} ?`,
      { title: "Invitation d'échange" }
    );
    if (!ok) return;
    this.ok = false;
    this.error = '';
    this.api.propose({
      partnerId: this.member.id,
      offeredUserSkillId: this.offeredUserSkillId || null,
      requestedUserSkillId: this.requestedUserSkillId || null,
      message: this.message
    }).subscribe({
      next: () => {
        this.ok = true;
        this.toast.success('Proposition envoyée avec succès.');
        this.router.navigateByUrl('/espace/echanges');
      },
      error: (err) => {
        this.error = err.error?.message || 'Impossible d’envoyer';
        this.toast.error(this.error);
      }
    });
  }
}