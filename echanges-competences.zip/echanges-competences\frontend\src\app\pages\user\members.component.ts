import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Recommendation, RecommendationReason, User } from '../../core/models';

@Component({
  selector: 'app-members',
  imports: [FormsModule, RouterLink],
  template: `
    <h1 class="page-title">Communauté</h1>
    <p class="page-sub">Trouvez quelqu’un avec qui échanger une compétence.</p>
    <form class="card" style="margin-bottom:18px;display:flex;gap:12px;flex-wrap:wrap" (ngSubmit)="search()">
      <input [(ngModel)]="q" name="q" placeholder="Nom, compétence… (ex. dessiner, anglais)" style="flex:1;min-width:180px;background:#1c133c;border:1px solid rgba(255,255,255,.08);color:#fff;border-radius:12px;padding:11px 12px">
      <input [(ngModel)]="city" name="city" placeholder="Ville" style="width:180px;background:#1c133c;border:1px solid rgba(255,255,255,.08);color:#fff;border-radius:12px;padding:11px 12px">
      @if (recoAvailable) {
        <select [(ngModel)]="sortBy" name="sortBy" (ngModelChange)="apply()" aria-label="Trier par" style="background:#1c133c;border:1px solid rgba(255,255,255,.08);color:#fff;border-radius:12px;padding:11px 12px">
          <option value="compat">Meilleure compatibilité</option>
          <option value="recent">Plus récents</option>
        </select>
      }
      <button class="btn btn-primary" type="submit">Filtrer</button>
    </form>
    @if (semantic.length) {
      <p class="page-sub">Recherche élargie par l’IA aux compétences proches : {{ semantic.join(', ') }}.</p>
    }
    @if (noSkills) {
      <p class="page-sub">Ajoutez vos compétences (offres et besoins) pour voir votre compatibilité avec chaque membre.</p>
    }
    <div class="grid grid-3">
      @for (m of view; track m.id) {
        <article class="card">
          <div style="display:flex;align-items:center;gap:12px;margin-bottom:8px">
            @if (m.avatarUrl) {
              <img [src]="m.avatarUrl" alt="" style="width:44px;height:44px;border-radius:50%;object-fit:cover;border:1px solid var(--line)">
            } @else {
              <div style="width:44px;height:44px;border-radius:50%;background:var(--accent);display:grid;place-items:center;font-weight:700;color:#0a0618">
                {{ m.firstName.charAt(0) }}
              </div>
            }
            <h3 style="margin:0;flex:1">{{ m.firstName }} {{ m.lastName }}</h3>
            @if (recoOf(m.id); as r) {
              <span class="badge" [class.warn]="r.score < 40" [title]="'Compatibilité calculée par l’IA : ' + r.score + ' %'" style="font-weight:700;white-space:nowrap">
                {{ r.score }} % compatible
              </span>
            }
          </div>
          <p style="color:var(--muted)">{{ m.city || 'Ville non renseignée' }} @if (m.rating) { · ★ {{ m.rating }} }</p>
          @if (recoOf(m.id); as r) {
            @if (r.reasons.length) {
              <p style="font-size:13px;color:var(--accent);margin:0 0 8px">{{ reasonText(r.reasons[0]) }}</p>
            }
          }
          <p>{{ m.bio }}</p>
          <div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:12px">
            @for (s of m.skills; track s.id) {
              <span class="badge">{{ s.type === 'offer' ? 'Offre' : 'Besoin' }} · {{ s.skillName }}</span>
            }
          </div>
          <a class="btn btn-primary btn-sm" [routerLink]="['/espace/membres', m.id]" (click)="track(m.id)">Voir le profil</a>
        </article>
      }
    </div>
  `
})
export class MembersComponent implements OnInit {
  members: User[] = [];
  view: User[] = [];
  q = '';
  city = '';
  sortBy: 'compat' | 'recent' = 'compat';

  private recos = new Map<number, Recommendation>();
  recoAvailable = false;
  noSkills = false;
  semantic: string[] = [];

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.search();
    // La recommandation est un bonus : en cas d'échec, la liste s'affiche simplement sans badge.
    this.api.recommendations().subscribe({
      next: (r) => {
        this.recos = new Map(r.recommendations.map((x) => [x.userId, x]));
        this.recoAvailable = r.available && r.recommendations.length > 0;
        this.noSkills = r.reason === 'no_skills';
        this.apply();
      },
      error: () => {}
    });
  }

  search() {
    this.api.members(this.q, this.city).subscribe((r) => {
      this.members = r.users;
      this.semantic = r.meta?.semantic ?? [];
      this.apply();
    });
  }

  apply() {
    if (this.recoAvailable && this.sortBy === 'compat') {
      // Tri stable : à score égal (ou sans score), l'ordre d'origine (plus récents d'abord) est conservé.
      this.view = [...this.members].sort((a, b) => (this.recos.get(b.id)?.score ?? -1) - (this.recos.get(a.id)?.score ?? -1));
    } else {
      this.view = this.members;
    }
  }

  recoOf(id: number): Recommendation | undefined {
    return this.recos.get(id);
  }

  reasonText(r: RecommendationReason): string {
    if (r.kind === 'they_offer') {
      return r.exact ? `Propose ${r.skill}, que vous cherchez` : `Propose ${r.skill} (proche de ${r.matches}, que vous cherchez)`;
    }
    return r.exact ? `Cherche ${r.skill}, que vous proposez` : `Cherche ${r.skill} (proche de ${r.matches}, que vous proposez)`;
  }

  track(id: number) {
    if (!this.recos.has(id)) return;
    this.api.recommendationClick(id).subscribe({ error: () => {} });
  }
}
