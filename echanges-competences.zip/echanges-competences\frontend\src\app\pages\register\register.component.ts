import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-register',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div style="min-height:100vh;display:grid;place-items:center;padding:24px">
      <div class="card" style="width:min(520px,100%)">
        <div class="brand"><span></span> Inscription</div>
        <h2>Rejoindre la plateforme</h2>

        @if (generalError) { 
          <div class="alert" style="background: rgba(239, 68, 68, 0.15); border: 1px solid rgba(239, 68, 68, 0.4); color: #fca5a5; padding: 10px 14px; border-radius: 8px; margin-bottom: 16px; font-size: 0.9rem;">
            ⚠️ {{ generalError }}
          </div> 
        }

        <form (ngSubmit)="submit()">
          <div class="grid grid-2">
            <div class="field">
              <label>Prénom</label>
              <input [(ngModel)]="firstName" name="firstName" required [style.border-color]="fieldErrors['firstName'] ? '#ef4444' : ''">
              @if (fieldErrors['firstName']) { <span class="field-error">{{ fieldErrors['firstName'] }}</span> }
            </div>
            <div class="field">
              <label>Nom</label>
              <input [(ngModel)]="lastName" name="lastName" required [style.border-color]="fieldErrors['lastName'] ? '#ef4444' : ''">
              @if (fieldErrors['lastName']) { <span class="field-error">{{ fieldErrors['lastName'] }}</span> }
            </div>
          </div>

          <div class="field">
            <label>Email</label>
            <input [(ngModel)]="email" name="email" type="email" required [style.border-color]="fieldErrors['email'] ? '#ef4444' : ''">
            @if (fieldErrors['email']) { <span class="field-error">{{ fieldErrors['email'] }}</span> }
          </div>

          <div class="field">
            <label>Ville</label>
            <input [(ngModel)]="city" name="city" [style.border-color]="fieldErrors['city'] ? '#ef4444' : ''">
            @if (fieldErrors['city']) { <span class="field-error">{{ fieldErrors['city'] }}</span> }
          </div>

          <div class="field">
            <label>Mot de passe</label>
            <input [(ngModel)]="password" name="password" type="password" required minlength="8" [style.border-color]="fieldErrors['password'] ? '#ef4444' : ''">
            @if (fieldErrors['password']) { <span class="field-error">{{ fieldErrors['password'] }}</span> }
          </div>

          <div class="field">
            <label>Confirmer le mot de passe</label>
            <input [(ngModel)]="confirmPassword" name="confirmPassword" type="password" required minlength="8" [style.border-color]="fieldErrors['confirmPassword'] ? '#ef4444' : ''">
            @if (fieldErrors['confirmPassword']) { <span class="field-error">{{ fieldErrors['confirmPassword'] }}</span> }
          </div>

          <div class="field">
            <label>Bio</label>
            <textarea [(ngModel)]="bio" name="bio" [style.border-color]="fieldErrors['bio'] ? '#ef4444' : ''"></textarea>
            @if (fieldErrors['bio']) { <span class="field-error">{{ fieldErrors['bio'] }}</span> }
          </div>

          <button class="btn btn-primary" type="submit" [disabled]="loading">Créer mon compte</button>
        </form>
        <p style="margin-top:16px;color:var(--muted)">Déjà inscrit ? <a routerLink="/connexion">Connexion</a></p>
      </div>
    </div>
  `,
  styles: [`
    .field-error {
      color: #f87171;
      font-size: 0.8rem;
      margin-top: 4px;
      display: block;
      font-weight: 500;
    }
  `]
})
export class RegisterComponent {
  firstName = '';
  lastName = '';
  email = '';
  city = '';
  password = '';
  confirmPassword = '';
  bio = '';

  generalError = '';
  fieldErrors: Record<string, string> = {};
  loading = false;

  constructor(private auth: AuthService) {}

  submit() {
    this.generalError = '';
    this.fieldErrors = {};

    // Validation locale Email
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(this.email)) {
      this.fieldErrors['email'] = 'Adresse email invalide (Ex: exemple@gmail.com)';
    }

    // Validation locale Mots de passe
    if (this.password !== this.confirmPassword) {
      this.fieldErrors['confirmPassword'] = 'Les deux mots de passe ne correspondent pas.';
    }

    if (Object.keys(this.fieldErrors).length > 0) {
      return;
    }

    this.loading = true;

    this.auth.register({
      firstName: this.firstName,
      lastName: this.lastName,
      email: this.email,
      city: this.city,
      password: this.password,
      bio: this.bio
    }).subscribe({
      next: (res) => this.auth.redirectAfterLogin(res.user),
      error: (err) => {
        this.loading = false;
        const resErr = err.error;

        // Extraire les erreurs backend par champ
        if (resErr?.errors) {
          if (Array.isArray(resErr.errors)) {
            resErr.errors.forEach((e: any) => {
              const field = e.path || e.param || e.field;
              if (field) this.fieldErrors[field] = e.msg || e.message;
            });
          } else if (typeof resErr.errors === 'object') {
            Object.keys(resErr.errors).forEach(key => {
              const val = resErr.errors[key];
              this.fieldErrors[key] = Array.isArray(val) ? val[0] : val;
            });
          }
        } else {
          this.generalError = resErr?.message || 'Erreur lors de l\'inscription.';
        }
      }
    });
  }
}