import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { matchInitial, matchName, reasonText } from '../../core/matching';
import { Exchange, Recommendation, UserSkill } from '../../core/models';

@Component({
  selector: 'app-user-dashboard',
  imports: [RouterLink],
  template: `
    <h1 class="page-title">Bonjour {{ auth.user()?.firstName }}</h1>
    <p class="page-sub">Votre espace d’échange de compétences, sans paiement.</p>
    <div class="grid grid-3">
      <article class="card">
        <div style="color:var(--muted)">Compétences</div>
        <h2>{{ skills.length }}</h2>
        <a routerLink="/espace/competences">Gérer</a>
      </article>
      <article class="card">
        <div style="color:var(--muted)">Échanges</div>
        <h2>{{ exchanges.length }}</h2>
        <a routerLink="/espace/echanges">Voir le suivi</a>
      </article>
      <article class="card">
        <div style="color:var(--muted)">En attente</div>
        <h2>{{ pending }}</h2>
        <a routerLink="/espace/membres">Proposer un échange</a>
      </article>
    </div>

    <div style="display:flex;align-items:center;justify-content:space-between;margin-top:28px;gap:12px;flex-wrap:wrap">
      <h3 style="margin:0">✨ Vos meilleurs matches</h3>
      <a routerLink="/espace/matches">Voir tous mes matches</a>
    </div>
    @if (topMatches.length) {
      <div class="grid grid-3" style="margin-top:14px">
        @for (m of topMatches; track m.userId) {
          <article class="card">
            <div style="display:flex;align-items:center;gap:10px;margin-bottom:8px">
              <div style="width:38px;height:38px;border-radius:50%;background:var(--accent);display:grid;place-items:center;font-weight:700;color:#0a0618">{{ initial(m) }}</div>
              <strong style="flex:1">{{ name(m) }}</strong>
              <span class="badge" style="font-weight:700">{{ m.score }} %</span>
            </div>
            @if (m.reasons.length) {
              <p style="font-size:13px;color:var(--accent);margin:0 0 10px">{{ reasonText(m.reasons[0]) }}</p>
            }
            <a class="btn btn-primary btn-sm" [routerLink]="['/espace/membres', m.userId]">Voir le profil</a>
          </article>
        }
      </div>
    } @else if (matchesNoSkills) {
      <p class="page-sub" style="margin-top:10px">Ajoutez vos <a routerLink="/espace/competences">compétences</a> pour découvrir vos meilleurs partenaires d’échange.</p>
    } @else if (matchesLoaded) {
      <p class="page-sub" style="margin-top:10px">Pas encore de match : complétez vos compétences ou revenez bientôt.</p>
    }
  `
})
export class UserDashboardComponent implements OnInit {
  skills: UserSkill[] = [];
  exchanges: Exchange[] = [];
  pending = 0;
  topMatches: Recommendation[] = [];
  matchesLoaded = false;
  matchesNoSkills = false;

  readonly reasonText = reasonText;
  readonly name = matchName;
  readonly initial = matchInitial;

  constructor(public auth: AuthService, private api: ApiService) {}

  ngOnInit() {
    this.api.mySkills().subscribe((r) => (this.skills = r.skills));
    this.api.exchanges().subscribe((r) => {
      this.exchanges = r.exchanges;
      this.pending = r.exchanges.filter((e) => e.status === 'pending').length;
    });
    // Les matches sont un bonus : en cas d'échec, le tableau de bord s'affiche sans cette section.
    this.api.recommendations().subscribe({
      next: (r) => {
        this.topMatches = r.recommendations.slice(0, 3);
        this.matchesNoSkills = r.reason === 'no_skills';
        this.matchesLoaded = r.available;
      },
      error: () => {}
    });
  }
}
