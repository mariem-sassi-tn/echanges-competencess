import { Component } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { AuthService } from '../../core/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div style="min-height: 100vh; display: grid; place-items: center; padding: 24px; background: var(--bg-main, #0f172a);">
      <div class="card" style="width: min(440px, 100%); background: #1e293b; padding: 32px; border-radius: 16px; box-shadow: 0 10px 25px -5px rgba(0, 0, 0, 0.3); border: 1px solid #334155;">
        
        <!-- Header & Logo -->
        <div class="brand" style="display: flex; align-items: center; gap: 14px; font-weight: 700; font-size: 2rem; color: #ffffff; margin-bottom: 24px;">
          <span style="width: 16px; height: 16px; background: #38bdf8; border-radius: 50%; display: inline-block; box-shadow: 0 0 12px #38bdf8;"></span>
          Bienvenue
        </div>

        <p style="color: #94a3b8; font-size: 0.95rem; margin-bottom: 24px; line-height: 1.5;">
          Accédez à votre espace membre pour échanger vos compétences et gérer vos opportunités.
        </p>

        <!-- Message d'erreur -->
        @if (error) {
          <div class="alert" style="background: rgba(239, 68, 68, 0.1); border: 1px solid #ef4444; color: #f87171; padding: 12px 16px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 20px;">
            ⚠️ {{ error }}
          </div>
        }

        <!-- Message de succès de réinitialisation -->
        @if (resetSuccess) {
          <div class="alert" style="background: rgba(34, 197, 94, 0.1); border: 1px solid #22c55e; color: #4ade80; padding: 12px 16px; border-radius: 8px; font-size: 0.9rem; margin-bottom: 20px;">
            ✓ {{ resetSuccess }}
          </div>
        }

        <!-- Formulaire de Connexion -->
        <form (ngSubmit)="submit()">
          <div class="field" style="margin-bottom: 18px;">
            <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #cbd5e1; margin-bottom: 6px;">Adresse Email</label>
            <input 
              [(ngModel)]="email" 
              name="email" 
              type="email" 
              placeholder="nom.prenom@gmail.com"
              required 
              style="width: 100%; padding: 12px 16px; border-radius: 8px; background: #0f172a; border: 1px solid #334155; color: #fff; font-size: 0.95rem; outline: none;">
          </div>

          <div class="field" style="margin-bottom: 12px;">
            <label style="display: block; font-size: 0.875rem; font-weight: 500; color: #cbd5e1; margin-bottom: 6px;">Mot de passe</label>
            <input 
              [(ngModel)]="password" 
              name="password" 
              type="password" 
              placeholder="••••••••"
              required 
              style="width: 100%; padding: 12px 16px; border-radius: 8px; background: #0f172a; border: 1px solid #334155; color: #fff; font-size: 0.95rem; outline: none;">
          </div>

          <!-- Lien Mot de passe oublié -->
          <div style="text-align: right; margin-bottom: 20px;">
            <button 
              type="button" 
              (click)="openResetModal()" 
              style="background: none; border: none; color: #38bdf8; font-size: 0.85rem; cursor: pointer; text-decoration: underline; padding: 0;">
              Mot de passe oublié ?
            </button>
          </div>

          <button 
            class="btn btn-primary" 
            type="submit" 
            [disabled]="loading"
            style="width: 100%; padding: 12px; border-radius: 8px; background: #0284c7; color: white; border: none; font-weight: 600; font-size: 1rem; cursor: pointer; transition: all 0.2s;">
            {{ loading ? 'Connexion en cours…' : 'Se connecter' }}
          </button>
        </form>

        <!-- Footer / Navigation -->
        <div style="margin-top: 24px; padding-top: 20px; border-top: 1px solid #334155; text-align: center;">
          <p style="color: #94a3b8; font-size: 0.9rem; margin: 0;">
            Vous n'avez pas encore de compte ? 
            <a routerLink="/inscription" style="color: #38bdf8; text-decoration: none; font-weight: 600;">S'inscrire</a>
          </p>
        </div>

      </div>
    </div>

    <!-- Modale Réinitialisation Mot de passe (2 Étapes) -->
    @if (showResetModal) {
      <div style="position: fixed; inset: 0; background: rgba(0,0,0,0.7); display: grid; place-items: center; z-index: 100; padding: 16px;">
        <div style="background: #1e293b; border: 1px solid #334155; border-radius: 12px; padding: 24px; width: min(400px, 100%);">
          
          <!-- ÉTAPE 1 : DEMANDE DU CODE -->
          @if (resetStep === 1) {
            <h3 style="color: #f8fafc; font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Mot de passe oublié</h3>
            <p style="color: #94a3b8; font-size: 0.875rem; margin-bottom: 16px;">
              Saisissez votre e-mail pour recevoir un code de vérification.
            </p>

            <div style="margin-bottom: 20px;">
              <input 
                [(ngModel)]="resetEmail" 
                type="email" 
                placeholder="votre.email@exemple.com"
                style="width: 100%; padding: 10px 14px; border-radius: 8px; background: #0f172a; border: 1px solid #334155; color: #fff; font-size: 0.9rem; outline: none;">
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button 
                type="button" 
                (click)="closeResetModal()" 
                style="padding: 8px 16px; border-radius: 6px; background: transparent; border: 1px solid #475569; color: #cbd5e1; cursor: pointer;">
                Annuler
              </button>
              <button 
                type="button" 
                (click)="sendCode()" 
                [disabled]="resetLoading || !resetEmail.trim()"
                style="padding: 8px 16px; border-radius: 6px; background: #0284c7; border: none; color: white; font-weight: 600; cursor: pointer;">
                {{ resetLoading ? 'Envoi…' : 'Envoyer le code' }}
              </button>
            </div>
          }

          <!-- ÉTAPE 2 : CODE + NOUVEAU MOT DE PASSE -->
          @if (resetStep === 2) {
            <h3 style="color: #f8fafc; font-size: 1.25rem; font-weight: 600; margin-bottom: 8px;">Nouveau mot de passe</h3>
            <p style="color: #94a3b8; font-size: 0.875rem; margin-bottom: 16px;">
              Un code a été envoyé à <strong>{{ resetEmail }}</strong>.
            </p>

            <div style="margin-bottom: 14px;">
              <label style="display: block; font-size: 0.8rem; color: #cbd5e1; margin-bottom: 4px;">Code de vérification</label>
              <input 
                [(ngModel)]="resetCode" 
                type="text" 
                placeholder="Ex: 4829"
                style="width: 100%; padding: 10px 14px; border-radius: 8px; background: #0f172a; border: 1px solid #334155; color: #fff; font-size: 0.9rem; outline: none;">
            </div>

            <div style="margin-bottom: 20px;">
              <label style="display: block; font-size: 0.8rem; color: #cbd5e1; margin-bottom: 4px;">Nouveau mot de passe</label>
              <input 
                [(ngModel)]="newPassword" 
                type="password" 
                placeholder="••••••••"
                style="width: 100%; padding: 10px 14px; border-radius: 8px; background: #0f172a; border: 1px solid #334155; color: #fff; font-size: 0.9rem; outline: none;">
            </div>

            <div style="display: flex; gap: 10px; justify-content: flex-end;">
              <button 
                type="button" 
                (click)="resetStep = 1" 
                style="padding: 8px 16px; border-radius: 6px; background: transparent; border: 1px solid #475569; color: #cbd5e1; cursor: pointer;">
                Retour
              </button>
              <button 
                type="button" 
                (click)="confirmReset()" 
                [disabled]="resetLoading || !resetCode.trim() || !newPassword.trim()"
                style="padding: 8px 16px; border-radius: 6px; background: #0284c7; border: none; color: white; font-weight: 600; cursor: pointer;">
                {{ resetLoading ? 'Mise à jour…' : 'Changer le mot de passe' }}
              </button>
            </div>
          }

        </div>
      </div>
    }
  `
})
export class LoginComponent {
  email = '';
  password = '';
  error = '';
  resetSuccess = '';
  loading = false;

  // Modale Reset Password
  showResetModal = false;
  resetStep: 1 | 2 = 1;
  resetEmail = '';
  resetCode = '';
  newPassword = '';
  resetLoading = false;

  constructor(private auth: AuthService) {}

  submit() {
    this.loading = true;
    this.error = '';
    this.resetSuccess = '';
    this.auth.login(this.email, this.password).subscribe({
      next: (res) => this.auth.redirectAfterLogin(res.user),
      error: (err) => {
        this.loading = false;
        this.error = err.error?.message || 'Identifiants invalides ou problème de connexion.';
      }
    });
  }

  openResetModal() {
    this.resetEmail = this.email;
    this.resetCode = '';
    this.newPassword = '';
    this.resetStep = 1;
    this.showResetModal = true;
  }

  closeResetModal() {
    this.showResetModal = false;
    this.resetEmail = '';
    this.resetCode = '';
    this.newPassword = '';
  }

  // Étape 1 : Envoyer le code
  sendCode() {
    if (!this.resetEmail.trim()) return;
    this.resetLoading = true;

    // Simulation de l'appel API (à connecter avec votre backend si disponible)
    setTimeout(() => {
      this.resetLoading = false;
      this.resetStep = 2; // Passe à l'étape de saisie du code
    }, 800);
  }

  // Étape 2 : Valider le code et changer le mot de passe
  confirmReset() {
    if (!this.resetCode.trim() || !this.newPassword.trim()) return;
    this.resetLoading = true;

    // Simulation de l'appel API
    setTimeout(() => {
      this.resetLoading = false;
      this.showResetModal = false;
      this.resetSuccess = `Mot de passe réinitialisé avec succès pour ${this.resetEmail}. Vous pouvez vous connecter.`;
    }, 800);
  }
}