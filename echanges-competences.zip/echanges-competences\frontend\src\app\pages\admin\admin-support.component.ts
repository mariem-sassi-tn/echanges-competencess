import { Component, OnDestroy, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { SupportMessage, SupportThread } from '../../core/models';
import { ToastService } from '../../core/toast.service';

@Component({
  selector: 'app-admin-support',
  imports: [FormsModule, DatePipe],
  template: `
    <h1 class="page-title">Support</h1>
    <p class="page-sub">Messages envoyés par les membres en cas de problème.</p>
    <div class="grid grid-2" style="align-items:start">
      <article class="card">
        <h3>Conversations</h3>
        @for (t of threads; track t.userId) {
          <button
            type="button"
            (click)="open(t)"
            class="btn btn-ghost"
            [class.btn-primary]="selected?.userId === t.userId"
            style="width:100%;justify-content:flex-start;text-align:left;margin-bottom:8px;flex-direction:column;align-items:flex-start;gap:2px;padding:12px 14px"
          >
            <strong>{{ t.firstName }} {{ t.lastName }}</strong>
            <span style="font-size:12px;opacity:.8">{{ t.lastMessage }}</span>
          </button>
        } @empty {
          <p style="color:var(--muted)">Aucune demande de support pour le moment.</p>
        }
      </article>

      <article class="card">
        @if (selected) {
          <h3>{{ selected.firstName }} {{ selected.lastName }}</h3>
          <div style="max-height:340px;overflow:auto;margin-bottom:16px;display:flex;flex-direction:column;gap:10px">
            @for (m of messages; track m.id) {
              <div style="max-width:85%" [style.align-self]="m.senderRole === 'admin' ? 'flex-end' : 'flex-start'">
                <div
                  style="border-radius:14px;padding:10px 14px"
                  [style.background]="m.senderRole === 'admin' ? 'rgba(142,224,106,.16)' : 'rgba(255,255,255,.06)'"
                >
                  <div style="font-size:12px;color:var(--muted);margin-bottom:4px">
                    {{ m.senderRole === 'admin' ? 'Administration' : (m.senderFirstName + ' ' + m.senderLastName) }} · {{ m.created_at | date:'short' }}
                  </div>
                  {{ m.content }}
                </div>
              </div>
            }
          </div>
          @if (summary) {
            <div class="card" style="margin-bottom:12px;padding:12px 14px">
              <strong>Résumé IA</strong>
              <p style="margin:6px 0 0;color:var(--muted)">{{ summary }}</p>
            </div>
          }
          <form (ngSubmit)="reply()">
            <div class="field"><textarea [(ngModel)]="draft" name="draft" placeholder="Votre réponse..."></textarea></div>
            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <button class="btn btn-primary" type="submit">Répondre</button>
              <button class="btn btn-ghost" type="button" [disabled]="suggesting" (click)="suggest()">
                {{ suggesting ? 'Rédaction…' : '✨ Suggérer une réponse' }}
              </button>
            </div>
          </form>
        } @else {
          <p style="color:var(--muted)">Sélectionnez une conversation à gauche.</p>
        }
      </article>
    </div>
  `
})
export class AdminSupportComponent implements OnInit, OnDestroy {
  threads: SupportThread[] = [];
  selected: SupportThread | null = null;
  messages: SupportMessage[] = [];
  draft = '';
  summary: string | null = null;
  suggesting = false;

  constructor(private api: ApiService, private toast: ToastService) {}

  private timer: ReturnType<typeof setInterval> | null = null;

  ngOnInit() {
    this.reloadThreads();
    // Les nouveaux messages des membres apparaissent sans recharger la page.
    this.timer = setInterval(() => {
      this.reloadThreads();
      if (this.selected) this.loadMessages(this.selected.userId, true);
    }, 15000);
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  reloadThreads() {
    this.api.adminSupportThreads().subscribe({
      next: (r) => (this.threads = r.threads),
      error: (err) => this.toast.error(err.error?.message || 'Impossible de charger les conversations.')
    });
  }

  open(t: SupportThread) {
    this.selected = t;
    this.summary = null;
    this.loadMessages(t.userId);
  }

  private loadMessages(userId: number, silent = false) {
    this.api.adminSupportThread(userId).subscribe({
      next: (r) => {
        // Évite de remplacer la liste (et de perdre le scroll) si rien n'a changé.
        if (this.selected?.userId === userId && (!silent || r.messages.length !== this.messages.length)) {
          this.messages = r.messages;
        }
      },
      error: (err) => {
        if (!silent) this.toast.error(err.error?.message || 'Impossible de charger la conversation.');
      }
    });
  }

  suggest() {
    if (!this.selected || this.suggesting) return;
    this.suggesting = true;
    this.api.adminSupportDraft(this.selected.userId).subscribe({
      next: (r) => {
        this.summary = r.summary;
        this.draft = r.draft; // brouillon : l'admin relit et modifie avant d'envoyer
        this.suggesting = false;
      },
      error: (err) => {
        this.suggesting = false;
        this.toast.error(err.error?.message || 'Impossible de générer une suggestion.');
      }
    });
  }

  reply() {
    if (!this.selected || !this.draft.trim()) return;
    this.api.adminReplySupport(this.selected.userId, this.draft).subscribe({
      next: () => {
        this.draft = '';
        this.toast.success('Réponse envoyée.');
        this.loadMessages(this.selected!.userId);
        this.reloadThreads();
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible d'envoyer la réponse.")
    });
  }
}
