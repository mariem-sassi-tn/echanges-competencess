import { Pipe, PipeTransform } from '@angular/core';

export const EXCHANGE_STATUS_LABELS: Record<string, string> = {
  pending: 'En attente',
  accepted: 'Acceptée',
  rejected: 'Refusée',
  in_progress: 'En cours',
  completed: 'Terminée',
  cancelled: 'Annulée'
};

export function exchangeStatusLabel(status: string): string {
  return EXCHANGE_STATUS_LABELS[status] || status;
}

/**
 * Affiche le statut d'un échange en français : {{ exchange.status | statusLabel }}
 */
@Pipe({ name: 'statusLabel', standalone: true })
export class StatusLabelPipe implements PipeTransform {
  transform(value: string | null | undefined): string {
    if (!value) return '—';
    return exchangeStatusLabel(value);
  }
}
