import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';

interface SkillChoice {
  id: number;
  name: string;
  uses: number;
  merge: boolean;
}

interface ClusterView {
  score: number;
  keepId: number;
  skills: SkillChoice[];
}

@Component({
  selector: 'app-admin-duplicates',
  imports: [RouterLink],
  template: `
    <a routerLink="/admin/catalogue" style="font-size:14px">← Retour au catalogue</a>
    <h1 class="page-title" style="margin-top:8px">Doublons du catalogue</h1>
    <p class="page-sub">
      L’IA compare le sens des compétences (« Anglais », « English », « Langue anglaise »…). Ce sont des suggestions :
      vérifiez chaque groupe, choisissez la compétence à garder, puis fusionnez. Les membres et leurs échanges passent
      automatiquement sur la compétence conservée.
    </p>

    <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center;margin-bottom:18px">
      <span style="color:var(--muted)">Sensibilité :</span>
      @for (p of presets; track p.value) {
        <button type="button" class="btn btn-sm" [class.btn-primary]="p.value === threshold" [class.btn-ghost]="p.value !== threshold" (click)="load(p.value)">
          {{ p.label }}
        </button>
      }
    </div>

    @if (loading) {
      <p class="page-sub">Analyse du catalogue…</p>
    } @else if (!available) {
      <article class="card">
        <h3>Détection indisponible</h3>
        <p style="color:var(--muted)">Le service d’IA ne répond pas (ml-service arrêté ou non configuré).</p>
      </article>
    } @else if (!clusters.length) {
      <article class="card">
        <h3>Aucun doublon détecté 🎉</h3>
        <p style="color:var(--muted)">Essayez une sensibilité plus large pour voir des cas moins évidents.</p>
      </article>
    } @else {
      <p class="page-sub">{{ clusters.length }} groupe(s) à vérifier.</p>
      <div class="grid grid-2">
        @for (c of clusters; track $index; let ci = $index) {
          <article class="card">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">
              <strong>Proximité {{ percent(c.score) }}</strong>
              @if (c.score >= 1) {
                <span class="badge">Même nom</span>
              }
            </div>
            @for (s of c.skills; track s.id) {
              <div style="display:flex;align-items:center;gap:10px;padding:8px 0;border-top:1px solid var(--line)">
                <label style="display:flex;align-items:center;gap:6px;cursor:pointer;flex:1">
                  <input type="radio" [name]="'keep-' + ci" [checked]="c.keepId === s.id" (change)="c.keepId = s.id" />
                  <span><strong>{{ s.name }}</strong> <span style="color:var(--muted);font-size:13px">· {{ s.uses }} membre(s)</span></span>
                </label>
                @if (c.keepId !== s.id) {
                  <label style="display:flex;align-items:center;gap:6px;font-size:13px;color:var(--muted);cursor:pointer">
                    <input type="checkbox" [checked]="s.merge" (change)="s.merge = !s.merge" />
                    fusionner
                  </label>
                } @else {
                  <span class="badge">à garder</span>
                }
              </div>
            }
            <button type="button" class="btn btn-primary btn-sm" style="margin-top:12px" [disabled]="busy || !mergeIds(c).length" (click)="merge(c)">
              Fusionner {{ mergeIds(c).length }} compétence(s) dans « {{ keepName(c) }} »
            </button>
          </article>
        }
      </div>
    }
  `
})
export class AdminDuplicatesComponent implements OnInit {
  readonly presets = [
    { label: 'Strict', value: 0.9 },
    { label: 'Équilibré', value: 0.8 },
    { label: 'Large', value: 0.7 }
  ];
  threshold = 0.8;
  loading = true;
  available = false;
  busy = false;
  clusters: ClusterView[] = [];

  constructor(private api: ApiService, private toast: ToastService, private confirm: ConfirmService) {}

  ngOnInit() {
    this.load(this.threshold);
  }

  load(threshold: number) {
    this.threshold = threshold;
    this.loading = true;
    this.api.catalogDuplicates(threshold).subscribe({
      next: (r) => {
        this.available = r.available;
        // Le backend trie par usage décroissant : le premier est la valeur par défaut à conserver.
        this.clusters = r.clusters
          .filter((c) => c.skills.length >= 2)
          .map((c) => ({
            score: c.score,
            keepId: c.skills[0].id,
            skills: c.skills.map((s) => ({ ...s, merge: true }))
          }));
        this.loading = false;
      },
      error: () => {
        this.available = false;
        this.loading = false;
      }
    });
  }

  percent(score: number): string {
    return `${Math.round(score * 100)} %`;
  }

  mergeIds(c: ClusterView): number[] {
    return c.skills.filter((s) => s.merge && s.id !== c.keepId).map((s) => s.id);
  }

  keepName(c: ClusterView): string {
    return c.skills.find((s) => s.id === c.keepId)?.name ?? '';
  }

  async merge(c: ClusterView) {
    const ids = this.mergeIds(c);
    if (!ids.length) return;
    const ok = await this.confirm.ask(
      `Fusionner ${ids.length} compétence(s) dans « ${this.keepName(c)} » ? Les membres concernés et leurs échanges seront rattachés à celle-ci, et les autres seront supprimées du catalogue. Action irréversible.`,
      { title: 'Fusion de compétences', confirmLabel: 'Fusionner', danger: true }
    );
    if (!ok) return;
    this.busy = true;
    this.api.mergeSkills(c.keepId, ids).subscribe({
      next: (r) => {
        this.busy = false;
        this.toast.success(r.message);
        this.load(this.threshold);
      },
      error: (err) => {
        this.busy = false;
        this.toast.error(err.error?.message || 'Fusion impossible.');
      }
    });
  }
}
