"""Tests de la logique de scoring avec un embedder factice (aucun modèle téléchargé).

Lancer :  python3 -m unittest discover -s tests -v
"""
import os
import sys
import unittest

import numpy as np

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from app.scoring import Profile, Recommender, Skill  # noqa: E402

# Axes : 0 = design, 1 = langues, 2 = dev, 3 = musique
VECTORS = {
    "Figma": [1, 0, 0, 0],
    "figma": [1, 0, 0, 0],
    "UI Design": [0.8, 0, 0, 0.0],  # même direction que Figma → cosinus 1.0
    "Photoshop": [0.75, 0, 0.66, 0],  # cosinus ~0.75 avec Figma
    "Anglais": [0, 1, 0, 0],
    "English": [0, 0.9, 0, 0],
    "Angular": [0, 0, 1, 0],
    "Piano": [0, 0, 0, 1],
    "je veux apprendre à dessiner": [0.9, 0, 0, 0.1],
    "xyz": [0, 0, 1, 0],
    "Je crée des maquettes pour des applications": [0.9, 0, 0, 0.1],
    "Je joue du Piano depuis dix ans": [0, 0, 0, 0.95],
    "Passionné de cuisine": [0, 0, 0.05, 0],
    "Langue anglaise": [0, 0.95, 0.05, 0],
}


class FakeEmbedder:
    def embed(self, texts):
        return np.array([VECTORS[t] for t in texts], dtype=float)


def sk(name, _cat=None, sid=None):
    return Skill(name=name, skill_id=sid)


class ScoringTest(unittest.TestCase):
    def setUp(self):
        self.rec = Recommender(FakeEmbedder(), sim_low=0.3, sim_high=0.8)
        # Sara cherche Figma, offre Anglais
        self.sara = Profile(3, "Tunis", offers=[sk("Anglais", "Langues", 1)], needs=[sk("Figma", "Design", 5)])

    def test_match_reciproque_exact_est_au_maximum(self):
        yassine = Profile(2, "Sfax", offers=[sk("Figma", "Design", 5)], needs=[sk("Anglais", "Langues", 1)])
        r = self.rec.score(self.sara, yassine)
        self.assertEqual(r["score"], 100)
        self.assertEqual({x["kind"] for x in r["reasons"]}, {"they_offer", "they_need"})

    def test_meme_ville_ajoute_un_bonus_plafonne(self):
        partial = Profile(9, "Tunis", offers=[sk("Piano", "Musique")], needs=[sk("Anglais", "Langues", 1)])
        elsewhere = Profile(9, "Sfax", offers=[sk("Piano", "Musique")], needs=[sk("Anglais", "Langues", 1)])
        self.assertGreater(self.rec.score(self.sara, partial)["score"], self.rec.score(self.sara, elsewhere)["score"])

    def test_competence_proche_donne_un_score_partiel(self):
        # « UI Design » (cosinus 1.0 avec Figma, ids différents) → similarité sémantique, pas exacte
        other = Profile(4, None, offers=[sk("UI Design", "Design", 4)], needs=[sk("Anglais", "Langues", 1)])
        r = self.rec.score(self.sara, other)
        self.assertGreater(r["score"], 80)

    def test_meme_competence_ecrite_differemment_sans_id(self):
        other = Profile(4, None, offers=[sk("figma", "Design")], needs=[sk("Anglais", "Langues")])
        self.assertEqual(self.rec.score(self.sara, other)["score"], 100)

    def test_sans_rapport_donne_zero(self):
        other = Profile(5, None, offers=[sk("Piano", "Musique", 10)], needs=[sk("Angular", "Dev", 7)])
        self.assertEqual(self.rec.score(self.sara, other)["score"], 0)

    def test_unilateral_est_penalise(self):
        # Il offre Figma, mais ne cherche rien : utile pour Sara, sans réciprocité → 80
        other = Profile(6, None, offers=[sk("Figma", "Design", 5)], needs=[])
        self.assertEqual(self.rec.score(self.sara, other)["score"], 80)

    def test_besoin_de_lautre_sans_offre_correspondante(self):
        # Il offre Figma, mais cherche du Piano que Sara n'a pas : 0.6*1 + 0.4*0 = 60
        other = Profile(7, None, offers=[sk("Figma", "Design", 5)], needs=[sk("Piano", "Musique", 10)])
        self.assertEqual(self.rec.score(self.sara, other)["score"], 60)

    def test_utilisateur_sans_competences(self):
        empty = Profile(8)
        other = Profile(2, None, offers=[sk("Figma", "Design", 5)], needs=[sk("Anglais", "Langues", 1)])
        self.assertEqual(self.rec.score(empty, other)["score"], 0)

    def test_rank_trie_et_exclut_soi_meme(self):
        a = Profile(2, None, offers=[sk("Figma", "Design", 5)], needs=[sk("Anglais", "Langues", 1)])
        b = Profile(5, None, offers=[sk("Piano", "Musique", 10)], needs=[])
        ranked = self.rec.rank(self.sara, [b, self.sara, a])
        self.assertEqual([r["id"] for r in ranked], [2, 5])
        self.assertGreaterEqual(ranked[0]["score"], ranked[1]["score"])

    def test_plusieurs_besoins_ponderation(self):
        user = Profile(1, None, offers=[], needs=[sk("Figma", "Design", 5), sk("Piano", "Musique", 10), sk("Angular", "Dev", 7)])
        other = Profile(2, None, offers=[sk("Figma", "Design", 5)], needs=[])
        # forward = 0.7*1 + 0.3*(1/3) = 0.8 ; unilatéral → 0.8*0.8 = 0.64
        self.assertEqual(self.rec.score(user, other)["score"], 64)


class LevelAndRatingTest(unittest.TestCase):
    def setUp(self):
        self.rec = Recommender(FakeEmbedder(), sim_low=0.3, sim_high=0.8)
        # Sara cherche Figma et n'offre rien → score purement « unilatéral » (facile à comparer)
        self.sara = Profile(3, None, offers=[], needs=[Skill("Figma", 5)])

    def other(self, level=None, rating=None):
        return Profile(2, None, rating=rating, offers=[Skill("Figma", 5, level=level)], needs=[])

    def test_expert_vaut_plus_que_debutant(self):
        expert = self.rec.score(self.sara, self.other("expert"))["score"]
        mid = self.rec.score(self.sara, self.other("intermediate"))["score"]
        beginner = self.rec.score(self.sara, self.other("beginner"))["score"]
        self.assertGreater(expert, mid)
        self.assertGreater(mid, beginner)
        self.assertGreater(beginner, 0)

    def test_niveau_inconnu_ne_penalise_pas(self):
        self.assertEqual(
            self.rec.score(self.sara, self.other(None))["score"],
            self.rec.score(self.sara, self.other("expert"))["score"],
        )

    def test_niveau_ne_change_pas_le_flag_exact(self):
        reasons = self.rec.score(self.sara, self.other("beginner"))["reasons"]
        self.assertTrue(reasons[0]["exact"])

    def test_bonne_note_augmente_mauvaise_note_diminue(self):
        # Offre « débutant » pour garder de la marge sous le plafond de 100
        good = self.rec.score(self.sara, self.other("beginner", rating=5.0))["score"]
        none = self.rec.score(self.sara, self.other("beginner", rating=None))["score"]
        bad = self.rec.score(self.sara, self.other("beginner", rating=1.0))["score"]
        self.assertGreater(good, none)
        self.assertGreater(none, bad)

    def test_note_ne_cree_pas_de_score_sans_correspondance(self):
        nothing = Profile(9, None, rating=5.0, offers=[Skill("Piano")], needs=[])
        self.assertEqual(self.rec.score(self.sara, nothing)["score"], 0)

    def test_note_hors_bornes_est_ecretee(self):
        a = self.rec.score(self.sara, self.other("beginner", rating=9.0))["score"]
        b = self.rec.score(self.sara, self.other("beginner", rating=5.0))["score"]
        self.assertEqual(a, b)


class DuplicatesTest(unittest.TestCase):
    def setUp(self):
        self.rec = Recommender(FakeEmbedder(), sim_low=0.3, sim_high=0.8)

    def names(self, clusters):
        return [sorted(s["name"] for s in c["skills"]) for c in clusters]

    def test_regroupe_les_synonymes(self):
        skills = [sk("Anglais", sid=1), sk("English", sid=2), sk("Langue anglaise", sid=3), sk("Piano", sid=4)]
        clusters = self.rec.find_duplicates(skills, min_cosine=0.9)
        self.assertEqual(self.names(clusters), [["Anglais", "English", "Langue anglaise"]])

    def test_nom_identique_malgre_casse_et_ids_differents(self):
        clusters = self.rec.find_duplicates([sk("Figma", sid=1), sk("figma", sid=2), sk("Piano", sid=3)], min_cosine=0.99)
        self.assertEqual(len(clusters), 1)
        self.assertEqual(clusters[0]["score"], 1.0)

    def test_seuil_plus_haut_donne_moins_de_groupes(self):
        # cosinus Figma / Photoshop ≈ 0,75
        skills = [sk("Figma", sid=1), sk("Photoshop", sid=2)]
        self.assertEqual(len(self.rec.find_duplicates(skills, min_cosine=0.7)), 1)
        self.assertEqual(len(self.rec.find_duplicates(skills, min_cosine=0.8)), 0)

    def test_sans_rapport_ou_trop_peu_de_competences(self):
        self.assertEqual(self.rec.find_duplicates([sk("Piano", sid=1), sk("Angular", sid=2)], min_cosine=0.8), [])
        self.assertEqual(self.rec.find_duplicates([sk("Piano", sid=1)]), [])
        self.assertEqual(self.rec.find_duplicates([]), [])


if __name__ == "__main__":
    unittest.main()


class SearchTest(unittest.TestCase):
    def setUp(self):
        self.rec = Recommender(FakeEmbedder(), sim_low=0.3, sim_high=0.8)
        self.catalog = [sk("Figma", sid=5), sk("UI Design", sid=6), sk("Anglais", sid=1), sk("Piano", sid=9)]

    def test_trouve_par_le_sens_sans_mot_commun(self):
        res = self.rec.search_skills("je veux apprendre à dessiner", self.catalog, min_score=0.5)
        self.assertEqual({r["name"] for r in res}, {"Figma", "UI Design"})

    def test_correspondance_textuelle_vaut_un(self):
        res = self.rec.search_skills("figma", self.catalog, min_score=0.5)
        self.assertEqual(res[0]["name"], "Figma")
        self.assertEqual(res[0]["score"], 1.0)

    def test_requete_sans_rapport_ne_renvoie_rien(self):
        self.assertEqual(self.rec.search_skills("xyz", self.catalog, min_score=0.5), [])

    def test_requete_vide_ou_catalogue_vide(self):
        self.assertEqual(self.rec.search_skills("  ", self.catalog), [])
        self.assertEqual(self.rec.search_skills("Figma", []), [])

    def test_top_k(self):
        res = self.rec.search_skills("je veux apprendre à dessiner", self.catalog, top_k=1, min_score=0.5)
        self.assertEqual(len(res), 1)


class SuggestTest(unittest.TestCase):
    def setUp(self):
        self.rec = Recommender(FakeEmbedder(), sim_low=0.3, sim_high=0.8)
        self.catalog = [sk("Figma", sid=5), sk("UI Design", sid=6), sk("Anglais", sid=1), sk("Piano", sid=9)]
        self.texts = ["Je crée des maquettes pour des applications", "Je joue du Piano depuis dix ans"]

    def test_suggere_par_le_sens_et_par_le_nom(self):
        res = self.rec.suggest_skills(self.texts, self.catalog, min_score=0.6)
        names = {r["name"] for r in res}
        self.assertEqual(names, {"Figma", "UI Design", "Piano"})
        piano = next(r for r in res if r["name"] == "Piano")
        self.assertEqual(piano["score"], 1.0)  # « Piano » est écrit dans le texte
        self.assertIn("Piano", piano["evidence"])

    def test_exclut_les_competences_deja_possedees(self):
        res = self.rec.suggest_skills(self.texts, self.catalog, exclude_ids={9, 5}, min_score=0.6)
        self.assertEqual({r["name"] for r in res}, {"UI Design"})

    def test_texte_sans_rapport_ou_vide(self):
        self.assertEqual(self.rec.suggest_skills(["Passionné de cuisine"], self.catalog, min_score=0.6), [])
        self.assertEqual(self.rec.suggest_skills(["", "  "], self.catalog), [])

    def test_mot_court_ne_matche_pas_au_milieu_d_un_mot(self):
        # La compétence « Go » ne doit pas ressortir de « Je suis gourmand » (frontière de mot).
        VECTORS["Go"] = [0, 0, 0, 0]
        VECTORS["Je suis gourmand"] = [0, 1, 0, 0]
        res = self.rec.suggest_skills(["Je suis gourmand"], [sk("Go", sid=3)], min_score=0.6)
        self.assertEqual(res, [])
