"""Calcul de compatibilité entre deux membres (logique pure, sans FastAPI).

Principe : un échange de compétences est une relation RÉCIPROQUE.
  - forward  : l'autre membre propose-t-il ce que JE cherche ?
  - backward : ai-je à offrir ce que L'AUTRE cherche ?
La similarité entre deux compétences vient d'un modèle d'embeddings multilingue
(« Figma » ≈ « UI Design », « English » ≈ « Anglais »), et vaut 1.0 si c'est
exactement la même compétence.
"""
from __future__ import annotations

import os
import re
import unicodedata
from dataclasses import dataclass, field
from typing import Protocol

import numpy as np


class Embedder(Protocol):
    def embed(self, texts: list[str]) -> np.ndarray:  # une ligne par texte
        ...


@dataclass(frozen=True)
class Skill:
    name: str
    skill_id: int | None = None
    # beginner | intermediate | expert (None = inconnu). Ne compte que pour une OFFRE.
    level: str | None = None

    @property
    def text(self) -> str:
        # Nom seul : la catégorie en base n'est pas assez fiable pour enrichir l'embedding.
        return self.name

    @property
    def norm_name(self) -> str:
        return _norm(self.name)


@dataclass
class Profile:
    id: int
    city: str | None = None
    rating: float | None = None  # note moyenne des avis (1-5), None = pas encore noté
    offers: list[Skill] = field(default_factory=list)
    needs: list[Skill] = field(default_factory=list)


def _norm(value: str | None) -> str:
    if not value:
        return ""
    stripped = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode()
    return " ".join(stripped.lower().split())


# Quelqu'un qui débute ne peut pas enseigner aussi bien qu'un expert : une offre « débutant »
# couvre un besoin un peu moins bien. Niveau inconnu = pas de pénalité.
LEVEL_WEIGHTS = {"beginner": 0.75, "intermediate": 0.9, "expert": 1.0}


def _level_weight(skill: Skill) -> float:
    return LEVEL_WEIGHTS.get(skill.level or "", 1.0)


def _env_float(name: str, default: float) -> float:
    try:
        return float(os.getenv(name, default))
    except ValueError:
        return default


class Recommender:
    def __init__(
        self,
        embedder: Embedder,
        sim_low: float | None = None,
        sim_high: float | None = None,
        w_forward: float = 0.6,
        w_backward: float = 0.4,
        one_sided_factor: float = 0.8,
        same_city_bonus: float = 0.05,
        reason_threshold: float = 0.5,
        rating_bonus: float = 0.04,
    ):
        self.embedder = embedder
        # Le cosinus brut d'un modèle d'embeddings n'est pas un « pourcentage » :
        # deux compétences sans rapport tournent autour de 0.1-0.2, deux compétences
        # proches autour de 0.6-0.8. On étire cette plage sur [0, 1].
        self.sim_low = _env_float("SIM_LOW", 0.30) if sim_low is None else sim_low
        self.sim_high = _env_float("SIM_HIGH", 0.80) if sim_high is None else sim_high
        self.w_forward = w_forward
        self.w_backward = w_backward
        self.one_sided_factor = one_sided_factor
        self.same_city_bonus = same_city_bonus
        self.reason_threshold = reason_threshold
        # Bonus (ou malus) maximal lié à la note moyenne : ±rating_bonus autour de 3/5.
        self.rating_bonus = rating_bonus

    # ---- similarité -------------------------------------------------------
    def _similarity_matrix(self, left: list[Skill], right: list[Skill]) -> np.ndarray:
        if not left or not right:
            return np.zeros((len(left), len(right)))
        texts = list({s.text for s in left + right})
        vectors = np.asarray(self.embedder.embed(texts), dtype=float)
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        vectors = vectors / np.clip(norms, 1e-9, None)
        index = {t: i for i, t in enumerate(texts)}
        a = np.stack([vectors[index[s.text]] for s in left])
        b = np.stack([vectors[index[s.text]] for s in right])
        cos = a @ b.T
        span = max(self.sim_high - self.sim_low, 1e-6)
        sim = np.clip((cos - self.sim_low) / span, 0.0, 1.0)
        for i, l in enumerate(left):
            for j, r in enumerate(right):
                same_id = l.skill_id is not None and l.skill_id == r.skill_id
                if same_id or (l.norm_name and l.norm_name == r.norm_name):
                    sim[i, j] = 1.0
        return sim

    @staticmethod
    def _aggregate(best_per_need: np.ndarray) -> float:
        # Satisfaire UN besoin à fond compte beaucoup ; satisfaire tous les besoins compte un peu plus.
        return float(0.7 * best_per_need.max() + 0.3 * best_per_need.mean())

    def _coverage(self, needs: list[Skill], offers: list[Skill]):
        """Dans quelle mesure `offers` couvre `needs`. Retourne (score|None, appariements).

        Chaque appariement est (besoin, offre, similarité pondérée, exact).
        La similarité est pondérée par le niveau de l'offre ; `exact` ignore cette pondération.
        """
        if not needs:
            return None, []
        if not offers:
            return 0.0, []
        raw = self._similarity_matrix(needs, offers)
        weights = np.array([_level_weight(o) for o in offers], dtype=float)
        sim = raw * weights[np.newaxis, :]
        best_idx = sim.argmax(axis=1)
        rows = np.arange(len(needs))
        best = sim[rows, best_idx]
        exact = raw[rows, best_idx] >= 0.999
        pairs = [
            (needs[i], offers[int(best_idx[i])], float(best[i]), bool(exact[i]))
            for i in range(len(needs))
            if best[i] >= self.reason_threshold
        ]
        pairs.sort(key=lambda p: p[2], reverse=True)
        return self._aggregate(best), pairs

    # ---- recherche / suggestion sémantique ---------------------------------
    def _text_scores(self, queries: list[str], skills: list[Skill]) -> np.ndarray:
        """Matrice (requêtes × compétences) de scores 0-1 : embeddings étirés + correspondance textuelle directe."""
        texts = list({*queries, *(s.text for s in skills)})
        vectors = np.asarray(self.embedder.embed(texts), dtype=float)
        vectors = vectors / np.clip(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-9, None)
        index = {t: i for i, t in enumerate(texts)}
        q = np.stack([vectors[index[t]] for t in queries])
        k = np.stack([vectors[index[s.text]] for s in skills])
        span = max(self.sim_high - self.sim_low, 1e-6)
        scores = np.clip((q @ k.T - self.sim_low) / span, 0.0, 1.0)
        for i, query in enumerate(queries):
            q_norm = _norm(query)
            for j, skill in enumerate(skills):
                n = skill.norm_name
                if not n or not q_norm:
                    continue
                if n == q_norm or (len(q_norm) >= 3 and n.startswith(q_norm)) or (
                    len(n) >= 2 and re.search(rf"(?<!\w){re.escape(n)}(?!\w)", q_norm)
                ):
                    scores[i, j] = 1.0
        return scores

    def search_skills(self, query: str, skills: list[Skill], top_k: int = 5, min_score: float | None = None) -> list[dict]:
        """Compétences du catalogue les plus proches du texte `query` (même échelle 0-1 que le scoring).

        « je veux apprendre à dessiner » → Illustration, Design… même sans mot en commun.
        """
        if not _norm(query) or not skills:
            return []
        threshold = _env_float("SEARCH_MIN_SCORE", 0.5) if min_score is None else min_score
        row = self._text_scores([query.strip()], skills)[0]
        results = [
            {"skillId": s.skill_id, "name": s.name, "score": round(float(sc), 3)}
            for s, sc in zip(skills, row)
            if sc >= threshold
        ]
        results.sort(key=lambda r: (-r["score"], r["name"]))
        return results[:top_k]

    def suggest_skills(
        self,
        texts: list[str],
        skills: list[Skill],
        exclude_ids: set[int] | None = None,
        top_k: int = 8,
        min_score: float | None = None,
    ) -> list[dict]:
        """Compétences du catalogue évoquées dans des extraits de profil (bio, CV).

        Chaque extrait est comparé au catalogue ; on garde, par compétence, le meilleur extrait (« evidence »).
        """
        texts = [t.strip() for t in texts if _norm(t)]
        exclude_ids = exclude_ids or set()
        candidates = [s for s in skills if s.skill_id not in exclude_ids]
        if not texts or not candidates:
            return []
        threshold = _env_float("SUGGEST_MIN_SCORE", 0.6) if min_score is None else min_score
        matrix = self._text_scores(texts, candidates)
        results = []
        for j, skill in enumerate(candidates):
            i = int(matrix[:, j].argmax())
            score = float(matrix[i, j])
            if score >= threshold:
                results.append({"skillId": skill.skill_id, "name": skill.name, "score": round(score, 3), "evidence": texts[i][:160]})
        results.sort(key=lambda r: (-r["score"], r["name"]))
        return results[:top_k]

    # ---- doublons du catalogue ---------------------------------------------
    def find_duplicates(self, skills: list[Skill], min_cosine: float | None = None) -> list[dict]:
        """Groupes de compétences qui semblent désigner la même chose (« Anglais », « English »…).

        Deux compétences sont liées si leur nom est identique (casse / accents ignorés) ou si le cosinus de
        leurs embeddings atteint `min_cosine`. Les liens sont regroupés (A~B et B~C → un seul groupe).
        Chaque groupe porte le meilleur score trouvé (1.0 = nom identique). Ce sont des SUGGESTIONS : un humain valide.
        """
        n = len(skills)
        if n < 2:
            return []
        threshold = _env_float("DUP_MIN_COSINE", 0.80) if min_cosine is None else min_cosine

        parent = list(range(n))

        def find(i: int) -> int:
            while parent[i] != i:
                parent[i] = parent[parent[i]]
                i = parent[i]
            return i

        best: dict[tuple[int, int], float] = {}  # (i, j) i<j -> score

        by_name: dict[str, list[int]] = {}
        for i, sk in enumerate(skills):
            if sk.norm_name:
                by_name.setdefault(sk.norm_name, []).append(i)
        for idxs in by_name.values():
            for a in range(len(idxs)):
                for b in range(a + 1, len(idxs)):
                    best[(idxs[a], idxs[b])] = 1.0

        texts = list({s.text for s in skills})
        vectors = np.asarray(self.embedder.embed(texts), dtype=float)
        vectors = vectors / np.clip(np.linalg.norm(vectors, axis=1, keepdims=True), 1e-9, None)
        index = {t: i for i, t in enumerate(texts)}
        mat = np.stack([vectors[index[s.text]] for s in skills])
        cos = mat @ mat.T
        iu, ju = np.triu_indices(n, k=1)
        hits = np.nonzero(cos[iu, ju] >= threshold)[0]
        for h in hits:
            key = (int(iu[h]), int(ju[h]))
            best[key] = max(best.get(key, 0.0), float(cos[key]))

        for (i, j) in best:
            ri, rj = find(i), find(j)
            if ri != rj:
                parent[ri] = rj

        groups: dict[int, list[int]] = {}
        for i in range(n):
            groups.setdefault(find(i), []).append(i)
        clusters = []
        for members in groups.values():
            if len(members) < 2:
                continue
            member_set = set(members)
            score = max(sc for (i, j), sc in best.items() if i in member_set and j in member_set)
            clusters.append(
                {
                    "score": round(min(score, 1.0), 3),
                    "skills": [{"skillId": skills[i].skill_id, "name": skills[i].name} for i in members],
                }
            )
        clusters.sort(key=lambda c: (-c["score"], c["skills"][0]["name"]))
        return clusters

    # ---- API publique -----------------------------------------------------
    def score(self, user: Profile, other: Profile) -> dict:
        forward, fwd_pairs = self._coverage(user.needs, other.offers)
        backward, bwd_pairs = self._coverage(other.needs, user.offers)

        if forward is None and backward is None:
            raw = 0.0
        elif forward is None:
            raw = backward * self.one_sided_factor
        elif backward is None:
            raw = forward * self.one_sided_factor
        else:
            raw = self.w_forward * forward + self.w_backward * backward

        if raw > 0 and user.city and _norm(user.city) == _norm(other.city):
            raw = min(1.0, raw + self.same_city_bonus)

        # Réputation : un membre bien noté est un partenaire plus sûr (±4 points max, jamais décisif).
        if raw > 0 and other.rating is not None:
            delta = self.rating_bonus * (min(max(other.rating, 1.0), 5.0) - 3.0) / 2.0
            raw = min(1.0, max(0.0, raw + delta))

        reasons = [
            {"kind": "they_offer", "skill": o.name, "matches": n.name, "exact": ex}
            for n, o, _s, ex in fwd_pairs[:2]
        ] + [
            {"kind": "they_need", "skill": n.name, "matches": o.name, "exact": ex}
            for n, o, _s, ex in bwd_pairs[:1]
        ]
        return {
            "id": other.id,
            "score": int(round(raw * 100)),
            "forward": None if forward is None else round(forward, 3),
            "backward": None if backward is None else round(backward, 3),
            "reasons": reasons,
        }

    def rank(self, user: Profile, candidates: list[Profile]) -> list[dict]:
        results = [self.score(user, c) for c in candidates if c.id != user.id]
        results.sort(key=lambda r: (-r["score"], r["id"]))
        return results
