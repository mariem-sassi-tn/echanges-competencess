import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';
import { StatusLabelPipe } from '../../core/status-label.pipe';

@Component({
  selector: 'app-admin-exchanges',
  imports: [StatusLabelPipe],
  template: `
    <h1 class="page-title">Modération des échanges</h1>
    <table class="table">
      <thead><tr><th>#</th><th>Demandeur</th><th>Partenaire</th><th>Statut</th><th></th></tr></thead>
      <tbody>
        @for (e of exchanges; track e.id) {
          <tr>
            <td>{{ e.id }}</td>
            <td>{{ e.rfirst }} {{ e.rlast }}</td>
            <td>{{ e.pfirst }} {{ e.plast }}</td>
            <td><span class="badge">{{ e.status | statusLabel }}</span></td>
            <td>
              @if (e.status === 'pending') {
                <button class="btn btn-primary btn-sm" (click)="set(e, 'accepted')">Valider</button>
                <button class="btn btn-danger btn-sm" (click)="set(e, 'cancelled')">Clôturer</button>
              }
            </td>
          </tr>
        }
      </tbody>
    </table>
  `
})
export class AdminExchangesComponent implements OnInit {
  exchanges: any[] = [];

  constructor(private api: ApiService, private confirm: ConfirmService, private toast: ToastService) {}

  ngOnInit() { this.reload(); }

  reload() {
    this.api.adminExchanges().subscribe((r) => (this.exchanges = r.exchanges));
  }

  async set(e: any, status: string) {
    const question = status === 'accepted'
      ? `Voulez-vous valider l'échange #${e.id} ?`
      : `Voulez-vous clôturer l'échange #${e.id} ?`;
    const ok = await this.confirm.ask(question, { danger: status === 'cancelled' });
    if (!ok) return;
    this.api.updateStatus(e.id, status).subscribe({
      next: () => {
        this.toast.success('Statut mis à jour.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible de mettre à jour l'échange.")
    });
  }
}
