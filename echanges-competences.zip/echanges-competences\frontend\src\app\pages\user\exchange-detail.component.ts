import { Component, NgZone, OnDestroy, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { AuthService } from '../../core/auth.service';
import { ChatMessage, Exchange } from '../../core/models';
import { StatusLabelPipe, exchangeStatusLabel } from '../../core/status-label.pipe';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';

const MESSAGING_STATUSES = ['accepted', 'in_progress', 'completed'];

@Component({
  selector: 'app-exchange-detail',
  imports: [FormsModule, DatePipe, StatusLabelPipe],
  template: `
    @if (exchange) {
      <h1 class="page-title">Échange #{{ exchange.id }}</h1>
      <p class="page-sub">{{ exchange.offeredSkill }} ⇄ {{ exchange.requestedSkill }} · <span class="badge">{{ exchange.status | statusLabel }}</span></p>
      <div class="grid grid-2">
        <article class="card">
          <h3>Actions</h3>
          @if (canAccept) {
            <button class="btn btn-primary btn-sm" (click)="setStatus('accepted')">Accepter</button>
            <button class="btn btn-danger btn-sm" (click)="setStatus('rejected')">Refuser</button>
          }
          @if (exchange.status === 'accepted') {
            <button class="btn btn-primary btn-sm" (click)="setStatus('in_progress')">Démarrer</button>
          }
          @if (exchange.status === 'in_progress') {
            <button class="btn btn-primary btn-sm" (click)="setStatus('completed')">Marquer terminé</button>
          }
          @if (canCancel) {
            <button class="btn btn-ghost btn-sm" (click)="setStatus('cancelled')">Annuler</button>
          }
          @if (exchange.status === 'completed') {
            <form (ngSubmit)="sendReview()" style="margin-top:16px">
              <div class="field"><label>Note (1-5)</label><input type="number" min="1" max="5" [(ngModel)]="rating" name="rating"></div>
              <div class="field"><label>Commentaire</label><textarea [(ngModel)]="comment" name="comment"></textarea></div>
              <button class="btn btn-primary" type="submit">Laisser un avis</button>
            </form>
          }
        </article>
        <article class="card">
          <h3>Messages</h3>
          @if (exchange.message) {
            <div style="border:1px solid var(--line);border-radius:12px;padding:12px 14px;margin-bottom:12px;background:rgba(167,139,250,0.08)">
              <span style="font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#a78bfa;font-weight:700">Message d'invitation</span>
              <p style="margin:6px 0 0"><strong>{{ exchange.requester.firstName }}</strong> · <span style="color:var(--muted);font-size:12px">{{ exchange.createdAt | date:'short' }}</span><br><span style="white-space:pre-line">{{ exchange.message }}</span></p>
            </div>
          }
          <div style="max-height:320px;overflow:auto;margin-bottom:12px">
            @for (m of messages; track m.id) {
              <p><strong>{{ m.sender.firstName }}</strong> · <span style="color:var(--muted);font-size:12px">{{ m.createdAt | date:'short' }}</span><br>{{ m.content }}</p>
            } @empty {
              @if (!exchange.message) {
                <p style="color:var(--muted)">Aucun message pour l'instant.</p>
              }
            }
          </div>
          @if (canMessage) {
            <form (ngSubmit)="send()">
              <div class="field"><textarea [(ngModel)]="draft" name="draft" placeholder="Votre message"></textarea></div>
              <button class="btn btn-primary" type="submit">Envoyer</button>
            </form>
          } @else {
            <p class="alert" style="margin:0">
              La messagerie est réservée aux échanges dont l'invitation a été acceptée.
            </p>
          }
        </article>
      </div>

      @if (isParty) {
        <article class="card coach" style="margin-top:24px">
          <header class="coach-head">
            <div class="coach-avatar">✦</div>
            <div class="coach-titles">
              <h3>Coach IA de l'échange</h3>
              <span class="coach-status"><i class="dot"></i>En ligne · prêt à vous aider à préparer cet échange</span>
            </div>
          </header>

          <div id="coach-messages" class="coach-feed" aria-live="polite">
            @for (line of coach; track $index) {
              <div class="msg" [class.msg-user]="line.role === 'user'">
                @if (line.role !== 'user') {
                  <div class="msg-avatar">✦</div>
                }
                <div class="bubble">
                  <div class="bubble-who">{{ line.role === 'user' ? 'Vous' : 'Coach IA' }}</div>
                  <div class="bubble-text" dir="auto">{{ line.content }}</div>
                </div>
              </div>
            }
            @if (coachLoading) {
              <div class="msg">
                <div class="msg-avatar">✦</div>
                <div class="bubble typing" aria-label="Le coach écrit"><span></span><span></span><span></span></div>
              </div>
            }
          </div>

          @if (coach.length <= 1) {
            <div class="chips">
              @for (s of suggestions; track s) {
                <button type="button" class="chip" (click)="askCoach(s)" [disabled]="coachLoading">{{ s }}</button>
              }
            </div>
          }

          @if (voiceSupported) {
            <div class="voice-bar">
              <label class="voice-lang">
                <span>🌐 Langue de la voix</span>
                <select [(ngModel)]="voiceLang" name="voiceLang" [disabled]="listening">
                  <option value="fr-FR">Français</option>
                  <option value="ar-TN">العربية (تونس)</option>
                  <option value="ar-SA">العربية</option>
                  <option value="en-US">English</option>
                </select>
              </label>
              <label class="switch">
                <input type="checkbox" [(ngModel)]="speakReplies" name="speakReplies" (ngModelChange)="onSpeakToggle()">
                <span class="slider"></span>
                <span class="switch-label">Lire les réponses à voix haute</span>
              </label>
            </div>
          }

          <form class="composer" [class.is-listening]="listening" (ngSubmit)="askCoach()">
            <textarea [(ngModel)]="coachDraft" name="coachDraft" rows="1" maxlength="1000" [disabled]="coachLoading" dir="auto"
                      [placeholder]="listening ? 'Je vous écoute… parlez maintenant' : 'Posez votre question au coach…'"
                      (keydown.enter)="onCoachEnter($event)"></textarea>
            @if (voiceSupported) {
              <button class="icon-btn mic" [class.rec]="listening" type="button" (click)="toggleMic()" [disabled]="coachLoading || transcribing"
                      [attr.aria-label]="listening ? 'Arrêter le micro' : 'Parler au coach'" [attr.title]="listening ? 'Arrêter' : 'Parler au coach'">
                @if (listening) {
                  <span class="stop-sq"></span>
                } @else {
                  <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><rect x="9" y="3" width="6" height="12" rx="3"></rect><path d="M5 11a7 7 0 0 0 14 0"></path><path d="M12 18v3"></path></svg>
                }
              </button>
            }
            <button class="icon-btn send" type="submit" [disabled]="coachLoading || !coachDraft.trim()" aria-label="Envoyer" title="Envoyer">
              <svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M22 2 11 13"></path><path d="M22 2 15 22l-4-9-9-4 20-7z"></path></svg>
            </button>
          </form>

          @if (voiceStatus) {
            <div class="voice-status" role="status">
              @if (listening) {
                <span class="wave"><i></i><i></i><i></i><i></i></span>
              }
              <span>{{ voiceStatus }}</span>
            </div>
          }
          @if (voiceSupported === false) {
            <p class="coach-note">La commande vocale n'est pas disponible dans ce navigateur (essayez Chrome ou Edge).</p>
          }
          <p class="coach-note">🔒 Les conversations avec le coach ne sont pas enregistrées. Ne partagez jamais de mot de passe.</p>
        </article>
      }
    }
  `,
  styles: [`
    .coach-head{display:flex;align-items:center;gap:14px;margin-bottom:16px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.08)}
    .coach-avatar{width:46px;height:46px;flex:none;display:grid;place-items:center;border-radius:14px;font-size:22px;color:#120c2b;background:linear-gradient(135deg,var(--accent,#8ee06a),#a78bfa);box-shadow:0 6px 18px rgba(142,224,106,.22)}
    .coach-titles h3{margin:0 0 3px;font-size:18px}
    .coach-status{display:flex;align-items:center;gap:7px;font-size:12.5px;color:var(--muted,#a9a3c9)}
    .dot{width:8px;height:8px;border-radius:50%;background:#65c98b;animation:pulse 2s infinite}
    @keyframes pulse{0%{box-shadow:0 0 0 0 rgba(101,201,139,.55)}70%{box-shadow:0 0 0 7px rgba(101,201,139,0)}100%{box-shadow:0 0 0 0 rgba(101,201,139,0)}}

    .coach-feed{max-height:380px;overflow-y:auto;display:flex;flex-direction:column;gap:14px;padding:4px 8px 4px 2px;margin-bottom:14px;scrollbar-width:thin;scrollbar-color:rgba(255,255,255,.22) transparent}
    .msg{display:flex;align-items:flex-end;gap:8px;max-width:88%;animation:rise .25s ease-out}
    .msg-user{align-self:flex-end;flex-direction:row-reverse}
    @keyframes rise{from{opacity:0;transform:translateY(6px)}to{opacity:1;transform:none}}
    .msg-avatar{width:28px;height:28px;flex:none;display:grid;place-items:center;border-radius:9px;font-size:14px;color:#120c2b;background:linear-gradient(135deg,var(--accent,#8ee06a),#a78bfa)}
    .bubble{padding:10px 14px;border-radius:16px 16px 16px 4px;background:rgba(255,255,255,.07);border:1px solid rgba(255,255,255,.07);line-height:1.6;overflow-wrap:anywhere;min-width:0}
    .msg-user .bubble{border-radius:16px 16px 4px 16px;background:linear-gradient(135deg,rgba(142,224,106,.24),rgba(142,224,106,.12));border-color:rgba(142,224,106,.28)}
    .bubble-who{font-size:11px;font-weight:700;letter-spacing:.04em;text-transform:uppercase;color:var(--muted,#a9a3c9);margin-bottom:3px}
    .bubble-text{white-space:pre-wrap}
    .typing{display:flex;gap:5px;padding:15px 16px}
    .typing span{width:7px;height:7px;border-radius:50%;background:#a78bfa;animation:blink 1.2s infinite ease-in-out}
    .typing span:nth-child(2){animation-delay:.15s}
    .typing span:nth-child(3){animation-delay:.3s}
    @keyframes blink{0%,80%,100%{opacity:.25;transform:scale(.8)}40%{opacity:1;transform:scale(1)}}

    .chips{display:flex;flex-wrap:wrap;gap:8px;margin-bottom:14px}
    .chip{cursor:pointer;font:inherit;font-size:13.5px;font-weight:600;color:inherit;padding:8px 14px;border-radius:999px;background:rgba(167,139,250,.1);border:1px solid rgba(167,139,250,.35);transition:background .15s,transform .15s}
    .chip:hover:not(:disabled){background:rgba(167,139,250,.22);transform:translateY(-1px)}
    .chip:disabled{opacity:.5;cursor:default}

    .voice-bar{display:flex;flex-wrap:wrap;align-items:center;justify-content:space-between;gap:10px 18px;margin-bottom:10px;font-size:13px;color:var(--muted,#a9a3c9)}
    .voice-lang{display:flex;align-items:center;gap:8px}
    .voice-lang select{width:auto;font:inherit;font-size:13px;color:inherit;background:rgba(255,255,255,.08);border:1px solid rgba(255,255,255,.16);border-radius:10px;padding:6px 10px}
    .voice-lang select option{background:#1d1640;color:#fff}
    .switch{display:flex;align-items:center;gap:9px;cursor:pointer;user-select:none}
    .switch input{position:absolute;opacity:0;width:0;height:0}
    .slider{position:relative;width:38px;height:22px;flex:none;border-radius:999px;background:rgba(255,255,255,.18);transition:background .2s}
    .slider::after{content:"";position:absolute;top:3px;left:3px;width:16px;height:16px;border-radius:50%;background:#fff;transition:transform .2s}
    .switch input:checked + .slider{background:var(--accent,#8ee06a)}
    .switch input:checked + .slider::after{transform:translateX(16px);background:#120c2b}
    .switch input:focus-visible + .slider{outline:2px solid #a78bfa;outline-offset:2px}

    .composer{display:flex;align-items:flex-end;gap:8px;padding:6px;border-radius:20px;background:rgba(10,6,28,.55);border:1px solid rgba(255,255,255,.12);transition:border-color .2s,box-shadow .2s}
    .composer:focus-within{border-color:#a78bfa;box-shadow:0 0 0 3px rgba(167,139,250,.18)}
    .composer.is-listening{border-color:#ef4444;box-shadow:0 0 0 3px rgba(239,68,68,.16)}
    .composer textarea{flex:1;min-width:0;min-height:44px;max-height:120px;resize:none;margin:0;padding:11px 12px;border:0;outline:0;box-shadow:none;background:transparent;color:inherit;font:inherit;line-height:1.4}
    .composer textarea::placeholder{color:var(--muted,#a9a3c9)}
    .icon-btn{width:44px;height:44px;flex:none;display:grid;place-items:center;border-radius:50%;border:1px solid transparent;cursor:pointer;transition:transform .15s,opacity .15s,background .15s}
    .icon-btn:hover:not(:disabled){transform:scale(1.06)}
    .icon-btn:disabled{opacity:.4;cursor:default}
    .mic{color:inherit;background:rgba(255,255,255,.08);border-color:rgba(255,255,255,.16)}
    .mic.rec{color:#fff;background:#ef4444;border-color:#ef4444;animation:ring 1.4s infinite}
    @keyframes ring{0%{box-shadow:0 0 0 0 rgba(239,68,68,.55)}70%{box-shadow:0 0 0 10px rgba(239,68,68,0)}100%{box-shadow:0 0 0 0 rgba(239,68,68,0)}}
    .stop-sq{width:14px;height:14px;border-radius:3px;background:#fff}
    .send{color:#120c2b;background:linear-gradient(135deg,var(--accent,#8ee06a),#b6f08f)}

    .voice-status{display:flex;align-items:center;gap:10px;margin:10px 4px 0;font-size:13px;color:#c4b5fd}
    .wave{display:inline-flex;align-items:center;gap:3px;height:16px}
    .wave i{width:3px;height:100%;border-radius:2px;background:#ef4444;animation:bar 1s infinite ease-in-out}
    .wave i:nth-child(2){animation-delay:.12s}
    .wave i:nth-child(3){animation-delay:.24s}
    .wave i:nth-child(4){animation-delay:.36s}
    @keyframes bar{0%,100%{transform:scaleY(.3)}50%{transform:scaleY(1)}}
    .coach-note{margin:10px 4px 0;font-size:11.5px;color:var(--muted,#a9a3c9)}

    @media (max-width:560px){
      .msg{max-width:96%}
      .voice-bar{flex-direction:column;align-items:flex-start}
    }
    @media (prefers-reduced-motion:reduce){
      .coach *{animation:none !important;transition:none !important}
    }
  `]
})
export class ExchangeDetailComponent implements OnInit, OnDestroy {
  exchange: Exchange | null = null;
  messages: ChatMessage[] = [];
  draft = '';
  rating = 5;
  comment = '';
  canAccept = false;
  canCancel = false;
  canMessage = false;
  isParty = false;

  // Coach IA (conversation éphémère, non enregistrée)
  coach: { role: 'user' | 'assistant'; content: string }[] = [];
  coachDraft = '';
  coachLoading = false;
  suggestions = [
    'Comment organiser nos séances ?',
    'Donne-moi des idées pour briser la glace',
    'Propose un plan pour la 1re séance'
  ];
  private typingTimer: ReturnType<typeof setInterval> | null = null;

  // Voix : le micro est enregistré par le navigateur, puis transcrit par le serveur (Gemini).
  voiceSupported = typeof navigator.mediaDevices?.getUserMedia === 'function' && 'MediaRecorder' in window;
  voiceLang = 'fr-FR';
  listening = false;
  transcribing = false;
  speakReplies = true;
  voiceStatus = '';
  private recorder: MediaRecorder | null = null;
  private audioChunks: Blob[] = [];
  private meterCtx: any = null;
  private meterTimer: any = null;
  private maxTimer: any = null;
  private heardSpeech = false;
  private maxLevel = 0;

  constructor(
    private zone: NgZone,
    private route: ActivatedRoute,
    private api: ApiService,
    private auth: AuthService,
    private confirm: ConfirmService,
    private toast: ToastService
  ) {}

  ngOnInit() {
    this.reload();
  }

  reload() {
    const id = Number(this.route.snapshot.paramMap.get('id'));
    this.api.exchange(id).subscribe({
      next: (r) => {
        this.exchange = r.exchange;
        this.messages = r.messages;
        this.canAccept = r.exchange.status === 'pending' && r.exchange.partner.id === this.auth.user()?.id;
        this.canMessage = MESSAGING_STATUSES.includes(r.exchange.status);
        const uid = this.auth.user()?.id;
        this.isParty = r.exchange.requester.id === uid || r.exchange.partner.id === uid;
        if (this.isParty && !this.coach.length) {
          const other = r.exchange.requester.id === uid ? r.exchange.partner : r.exchange.requester;
          this.coach = [{
            role: 'assistant',
            content: `Bonjour ! 👋 Je suis le coach de votre échange ${r.exchange.offeredSkill || ''} ⇄ ${r.exchange.requestedSkill || ''} avec ${other.firstName}. Je peux vous aider à préparer vos séances, trouver quoi dire ou organiser votre temps. Que voulez-vous savoir ?`
          }];
        }
        // Règle backend : une demande en attente est annulée par son auteur (le destinataire, lui, refuse).
        this.canCancel =
          r.exchange.status === 'accepted' ||
          r.exchange.status === 'in_progress' ||
          (r.exchange.status === 'pending' && r.exchange.requester.id === this.auth.user()?.id);
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible de charger l'échange.")
    });
  }

  async setStatus(status: string) {
    if (!this.exchange) return;
    const questions: Record<string, string> = {
      accepted: "Voulez-vous accepter cette invitation d'échange ?",
      rejected: 'Voulez-vous refuser cette invitation ?',
      in_progress: 'Voulez-vous démarrer cet échange ?',
      completed: 'Voulez-vous marquer cet échange comme terminé ?',
      cancelled: 'Voulez-vous annuler cet échange ?'
    };
    const danger = status === 'rejected' || status === 'cancelled';
    const ok = await this.confirm.ask(
      questions[status] || `Voulez-vous passer cet échange au statut « ${exchangeStatusLabel(status)} » ?`,
      { danger }
    );
    if (!ok) return;
    this.api.updateStatus(this.exchange.id, status).subscribe({
      next: () => {
        this.toast.success('Statut mis à jour avec succès.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || 'Impossible de mettre à jour le statut.')
    });
  }

  async send() {
    if (!this.exchange || !this.draft.trim()) return;
    if (!this.canMessage) {
      this.toast.error("Vous devez d'abord accepter l'invitation pour échanger des messages.");
      return;
    }
    this.api.sendMessage(this.exchange.id, this.draft).subscribe({
      next: () => {
        this.draft = '';
        this.toast.success('Message envoyé.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible d'envoyer le message.")
    });
  }

  ngOnDestroy() {
    if (this.typingTimer) clearInterval(this.typingTimer);
    this.stopRecording();
    this.stopMeter();
    window.speechSynthesis?.cancel();
  }

  // --- Voix : le membre parle (micro → texte), le coach répond à voix haute (texte → voix) ---
  async toggleMic() {
    if (this.listening) {
      this.stopRecording();
      return;
    }
    if (this.transcribing) return;
    window.speechSynthesis?.cancel(); // on se tait quand le membre veut parler
    // Le contexte audio est créé tout de suite (clic de l'utilisateur) pour ne pas être bloqué par le navigateur.
    const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
    const ctx = new Ctx();
    let stream: MediaStream;
    try {
      stream = await navigator.mediaDevices.getUserMedia({ audio: true });
    } catch (err: any) {
      ctx.close?.();
      const denied = err?.name === 'NotAllowedError' || err?.name === 'SecurityError';
      this.toast.error(
        denied
          ? "Micro refusé : autorisez le micro pour ce site (icône à gauche de l'adresse)."
          : 'Aucun micro détecté sur cet appareil.'
      );
      return;
    }
    await ctx.resume?.();
    this.audioChunks = [];
    this.heardSpeech = false;
    this.maxLevel = 0;
    const rec = new MediaRecorder(stream);
    this.recorder = rec;
    rec.ondataavailable = (e) => {
      if (e.data.size) this.audioChunks.push(e.data);
    };
    rec.onstop = () => {
      this.stopMeter();
      stream.getTracks().forEach((t) => t.stop());
      this.zone.run(() => this.finishRecording());
    };
    this.startMeter(ctx, stream);
    rec.start();
    this.listening = true;
    this.voiceStatus = '🎙️ Je vous écoute : parlez maintenant.';
    this.maxTimer = setTimeout(() => this.stopRecording(), 20000);
  }

  stopRecording() {
    if (this.maxTimer) {
      clearTimeout(this.maxTimer);
      this.maxTimer = null;
    }
    if (this.recorder && this.recorder.state !== 'inactive') this.recorder.stop();
  }

  // Mesure le volume du micro : s'arrête tout seul quand le membre se tait, et aide à diagnostiquer un micro muet.
  private startMeter(ctx: any, stream: MediaStream) {
    this.meterCtx = ctx;
    const analyser = ctx.createAnalyser();
    analyser.fftSize = 1024;
    ctx.createMediaStreamSource(stream).connect(analyser);
    const buf = new Float32Array(analyser.fftSize);
    const startedAt = Date.now();
    let lastVoice = startedAt;
    this.meterTimer = setInterval(() => {
      analyser.getFloatTimeDomainData(buf);
      let sum = 0;
      for (const v of buf) sum += v * v;
      const level = Math.sqrt(sum / buf.length);
      this.maxLevel = Math.max(this.maxLevel, level);
      const now = Date.now();
      if (level > 0.002) {
        lastVoice = now;
        if (!this.heardSpeech) {
          this.heardSpeech = true;
          this.zone.run(() => (this.voiceStatus = '🗣️ Voix détectée… je m’arrête quand vous vous taisez.'));
        }
      } else if (this.heardSpeech && now - lastVoice > 1500) {
        this.stopRecording();
      } else if (!this.heardSpeech && now - startedAt > 8000) {
        this.stopRecording();
      }
    }, 100);
  }

  private stopMeter() {
    if (this.meterTimer) {
      clearInterval(this.meterTimer);
      this.meterTimer = null;
    }
    this.meterCtx?.close?.();
    this.meterCtx = null;
  }

  private async finishRecording() {
    this.listening = false;
    if (this.maxLevel < 0.001) {
      this.voiceStatus =
        "🔇 Le micro est ouvert mais ne reçoit aucun son : vérifiez le micro choisi (icône 🎙️ à gauche de l'adresse) et son volume dans Windows.";
      return;
    }
    this.transcribing = true;
    this.voiceStatus = '✍️ Transcription en cours…';
    try {
      const wav = await this.toWav(new Blob(this.audioChunks, { type: this.recorder?.mimeType || 'audio/webm' }));
      this.api.transcribeAudio(wav, this.voiceLang).subscribe({
        next: (r) => {
          this.transcribing = false;
          if (r.text) {
            this.voiceStatus = '';
            this.coachDraft = r.text;
            this.askCoach(); // envoi automatique, comme une vraie conversation
          } else {
            this.voiceStatus = "❓ Je n'ai rien compris : réessayez en parlant plus fort et plus clairement.";
          }
        },
        error: (err) => {
          this.transcribing = false;
          this.voiceStatus = '';
          this.toast.error(err.error?.message || 'Transcription impossible. Réessayez dans un instant.');
        }
      });
    } catch {
      this.transcribing = false;
      this.voiceStatus = "Impossible de traiter l'enregistrement audio.";
    }
  }

  // Convertit l'enregistrement du navigateur (webm/opus) en WAV 16 kHz mono, lisible par le modèle.
  private async toWav(blob: Blob): Promise<Blob> {
    const Ctx = (window as any).AudioContext || (window as any).webkitAudioContext;
    const ctx = new Ctx();
    const decoded: AudioBuffer = await ctx.decodeAudioData(await blob.arrayBuffer());
    ctx.close?.();
    const rate = 16000;
    const off = new OfflineAudioContext(1, Math.max(1, Math.ceil(decoded.duration * rate)), rate);
    const src = off.createBufferSource();
    src.buffer = decoded;
    src.connect(off.destination);
    src.start();
    const pcm = (await off.startRendering()).getChannelData(0);
    const out = new DataView(new ArrayBuffer(44 + pcm.length * 2));
    const text = (o: number, str: string) => {
      for (let i = 0; i < str.length; i++) out.setUint8(o + i, str.charCodeAt(i));
    };
    text(0, 'RIFF');
    out.setUint32(4, 36 + pcm.length * 2, true);
    text(8, 'WAVE');
    text(12, 'fmt ');
    out.setUint32(16, 16, true);
    out.setUint16(20, 1, true); // PCM
    out.setUint16(22, 1, true); // mono
    out.setUint32(24, rate, true);
    out.setUint32(28, rate * 2, true);
    out.setUint16(32, 2, true);
    out.setUint16(34, 16, true);
    text(36, 'data');
    out.setUint32(40, pcm.length * 2, true);
    for (let i = 0; i < pcm.length; i++) {
      const v = Math.max(-1, Math.min(1, pcm[i]));
      out.setInt16(44 + i * 2, v < 0 ? v * 0x8000 : v * 0x7fff, true);
    }
    return new Blob([out], { type: 'audio/wav' });
  }

  onSpeakToggle() {
    if (!this.speakReplies) window.speechSynthesis?.cancel();
  }

  private speak(text: string) {
    if (!this.speakReplies || !('speechSynthesis' in window) || !text) return;
    window.speechSynthesis.cancel();
    const u = new SpeechSynthesisUtterance(text.replace(/[*_#`]/g, ''));
    // Langue de la lecture = langue de la réponse (arabe si le texte contient de l'arabe).
    u.lang = /[؀-ۿ]/.test(text) ? (this.voiceLang.startsWith('ar') ? this.voiceLang : 'ar-SA') : this.voiceLang.startsWith('ar') ? 'fr-FR' : this.voiceLang;
    u.rate = 1;
    window.speechSynthesis.speak(u);
  }

  onCoachEnter(event: Event) {
    const e = event as KeyboardEvent;
    if (!e.shiftKey) {
      e.preventDefault();
      this.askCoach();
    }
  }

  private scrollCoach() {
    setTimeout(() => {
      const el = document.getElementById('coach-messages');
      if (el) el.scrollTop = el.scrollHeight;
    }, 0);
  }

  askCoach(preset?: string) {
    const text = (preset ?? this.coachDraft).trim();
    if (!this.exchange || !text || this.coachLoading) return;
    // Historique envoyé au serveur : sans le message d'accueil (écrit par l'interface, pas par le modèle).
    const history = this.coach.slice(1).slice(-10);
    this.coach.push({ role: 'user', content: text });
    this.coachDraft = '';
    this.coachLoading = true;
    this.scrollCoach();
    this.api.exchangeAiChat(this.exchange.id, text, history).subscribe({
      next: (r) => {
        this.coachLoading = false;
        const reply = this.cleanReply(r.reply);
        this.typeReply(reply);
        this.speak(reply);
      },
      error: (err) => {
        this.coachLoading = false;
        const msg = err.error?.message || 'Impossible de contacter le coach. Réessayez dans un instant.';
        this.coach.push({ role: 'assistant', content: msg });
        this.toast.error(msg);
        this.scrollCoach();
      }
    });
  }

  // Le modèle renvoie parfois du markdown (**gras**, "* puces", titres #) : on l'affiche en texte propre.
  private cleanReply(text: string): string {
    return text
      .replace(/\*\*(.+?)\*\*/g, '$1')
      .replace(/__(.+?)__/g, '$1')
      .replace(/^\s*[*-]\s+/gm, '• ')
      .replace(/^#{1,6}\s+/gm, '')
      .replace(/`/g, '')
      .trim();
  }

  // Affichage progressif de la réponse, pour donner l'effet d'une conversation en direct.
  private typeReply(full: string) {
    if (this.typingTimer) clearInterval(this.typingTimer);
    const line = { role: 'assistant' as const, content: '' };
    this.coach.push(line);
    let i = 0;
    this.typingTimer = setInterval(() => {
      i = Math.min(full.length, i + 3);
      line.content = full.slice(0, i);
      this.scrollCoach();
      if (i >= full.length && this.typingTimer) {
        clearInterval(this.typingTimer);
        this.typingTimer = null;
      }
    }, 20);
  }

  async sendReview() {
    if (!this.exchange) return;
    const ok = await this.confirm.ask('Voulez-vous envoyer cet avis ? Il ne pourra plus être modifié.');
    if (!ok) return;
    this.api.review(this.exchange.id, this.rating, this.comment).subscribe({
      next: () => {
        this.toast.success('Avis enregistré. Merci !');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible d'enregistrer l'avis.")
    });
  }
}
