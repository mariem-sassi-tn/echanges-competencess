import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ApiService } from '../../core/api.service';
import { Skill, SkillSuggestion, UserSkill } from '../../core/models';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';

@Component({
  selector: 'app-skills',
  imports: [FormsModule],
  template: `
    <h1 class="page-title">Mes compétences</h1>
    <p class="page-sub">Ce que vous offrez, et ce que vous souhaitez apprendre.</p>
    <section class="card" style="margin-bottom:18px">
      <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap">
        <div>
          <h3 style="margin:0">Suggestions de l’IA</h3>
          <p style="color:var(--muted);margin:4px 0 0">Compétences repérées dans votre bio et votre CV.</p>
        </div>
        <button class="btn btn-primary btn-sm" type="button" (click)="suggest()" [disabled]="loadingSuggest">
          {{ loadingSuggest ? 'Analyse…' : 'Analyser mon profil' }}
        </button>
      </div>
      @if (suggestNote) {
        <p style="color:var(--muted);margin:12px 0 0">{{ suggestNote }}</p>
      }
      @for (sg of suggestions; track sg.skillId) {
        <div style="display:flex;justify-content:space-between;align-items:center;gap:12px;margin-top:12px;flex-wrap:wrap">
          <div style="min-width:0">
            <strong>{{ sg.name }}</strong>
            @if (sg.categoryName) { <span style="color:var(--muted)"> · {{ sg.categoryName }}</span> }
            <p style="color:var(--muted);margin:2px 0 0;font-size:13px">« {{ sg.evidence }} »</p>
          </div>
          <div style="display:flex;gap:8px">
            <button class="btn btn-primary btn-sm" type="button" (click)="accept(sg, 'offer')">J’offre</button>
            <button class="btn btn-sm" type="button" (click)="accept(sg, 'need')">Je cherche</button>
            <button class="btn btn-sm" type="button" (click)="dismiss(sg)" aria-label="Ignorer">✕</button>
          </div>
        </div>
      }
    </section>
    <div class="grid grid-2">
      <form class="card" (ngSubmit)="add()">
        <h3>Ajouter</h3>
        <div class="field">
          <label>Compétence</label>
          <select [(ngModel)]="skillId" name="skillId" required>
            <option [ngValue]="0" disabled>Choisir</option>
            @for (s of catalog; track s.id) {
              <option [ngValue]="s.id">{{ s.categoryName }} · {{ s.name }}</option>
            }
          </select>
        </div>
        <div class="field">
          <label>Type</label>
          <select [(ngModel)]="type" name="type">
            <option value="offer">J’offre / j’enseigne</option>
            <option value="need">Je cherche à apprendre</option>
          </select>
        </div>
        <div class="field">
          <label>Niveau</label>
          <select [(ngModel)]="level" name="level">
            <option value="beginner">Débutant</option>
            <option value="intermediate">Intermédiaire</option>
            <option value="expert">Expert</option>
          </select>
        </div>
        <div class="field"><label>Description</label><textarea [(ngModel)]="description" name="description"></textarea></div>
        <button class="btn btn-primary" type="submit">Enregistrer</button>
      </form>
      <div>
        @for (s of skills; track s.id) {
          <article class="card" style="margin-bottom:12px">
            <div style="display:flex;justify-content:space-between;gap:12px">
              <div>
                <span class="badge">{{ s.type === 'offer' ? 'Offre' : 'Besoin' }}</span>
                <h3>{{ s.skillName }}</h3>
                <p style="color:var(--muted);margin:0">{{ s.categoryName }} · {{ s.level }}</p>
                <p>{{ s.description }}</p>
              </div>
              <button class="btn btn-danger btn-sm" (click)="remove(s.id)">Retirer</button>
            </div>
          </article>
        }
      </div>
    </div>
  `
})
export class SkillsComponent implements OnInit {
  skills: UserSkill[] = [];
  catalog: Skill[] = [];
  skillId = 0;
  type = 'offer';
  level = 'intermediate';
  description = '';
  suggestions: SkillSuggestion[] = [];
  suggestNote = '';
  loadingSuggest = false;

  constructor(private api: ApiService, private confirm: ConfirmService, private toast: ToastService) {}

  ngOnInit() {
    this.reload();
    this.api.catalog().subscribe((r) => (this.catalog = r.skills));
  }

  suggest() {
    this.loadingSuggest = true;
    this.suggestNote = '';
    this.api.skillSuggestions().subscribe({
      next: (r) => {
        this.loadingSuggest = false;
        this.suggestions = r.suggestions;
        if (r.suggestions.length) return;
        this.suggestNote =
          r.reason === 'no_text'
            ? 'Ajoutez une bio ou un CV dans votre profil pour recevoir des suggestions.'
            : !r.available
              ? 'Les suggestions IA ne sont pas disponibles pour le moment.'
              : 'Aucune nouvelle compétence détectée dans votre profil.';
      },
      error: () => {
        this.loadingSuggest = false;
        this.suggestNote = 'Les suggestions IA ne sont pas disponibles pour le moment.';
      }
    });
  }

  accept(sg: SkillSuggestion, type: 'offer' | 'need') {
    this.api.addSkill({ skillId: sg.skillId, type, level: 'intermediate' }).subscribe({
      next: () => {
        this.toast.success(`${sg.name} ajoutée.`);
        this.suggestions = this.suggestions.filter((x) => x.skillId !== sg.skillId);
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible d'ajouter cette compétence.")
    });
  }

  dismiss(sg: SkillSuggestion) {
    this.suggestions = this.suggestions.filter((x) => x.skillId !== sg.skillId);
  }

  reload() {
    this.api.mySkills().subscribe((r) => (this.skills = r.skills));
  }

  add() {
    if (!this.skillId) return;
    this.api.addSkill({ skillId: this.skillId, type: this.type, level: this.level, description: this.description }).subscribe({
      next: () => {
        this.description = '';
        this.toast.success('Compétence ajoutée.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || "Impossible d'ajouter cette compétence.")
    });
  }

  async remove(id: number) {
    const ok = await this.confirm.ask('Voulez-vous retirer cette compétence de votre profil ?', { danger: true });
    if (!ok) return;
    this.api.removeSkill(id).subscribe({
      next: () => {
        this.toast.success('Compétence retirée.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || 'Impossible de retirer cette compétence.')
    });
  }
}
