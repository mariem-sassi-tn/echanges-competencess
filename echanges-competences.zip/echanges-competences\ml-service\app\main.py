from __future__ import annotations

from contextlib import asynccontextmanager
from typing import Literal

from fastapi import FastAPI
from pydantic import BaseModel, Field

from .embedder import FastEmbedder
from .scoring import Profile, Recommender, Skill


class SkillIn(BaseModel):
    skillId: int | None = None
    name: str = Field(min_length=1, max_length=120)
    level: Literal["beginner", "intermediate", "expert"] | None = None


class ProfileIn(BaseModel):
    id: int
    city: str | None = Field(default=None, max_length=120)
    rating: float | None = Field(default=None, ge=0, le=5)
    offers: list[SkillIn] = Field(default_factory=list, max_length=50)
    needs: list[SkillIn] = Field(default_factory=list, max_length=50)


class RecommendRequest(BaseModel):
    user: ProfileIn
    candidates: list[ProfileIn] = Field(max_length=500)


class SearchRequest(BaseModel):
    query: str = Field(min_length=1, max_length=200)
    skills: list[SkillIn] = Field(max_length=2000)
    topK: int = Field(default=5, ge=1, le=20)


class SuggestRequest(BaseModel):
    texts: list[str] = Field(max_length=60)
    skills: list[SkillIn] = Field(max_length=2000)
    excludeIds: list[int] = Field(default_factory=list, max_length=500)
    topK: int = Field(default=8, ge=1, le=20)


class DuplicatesRequest(BaseModel):
    skills: list[SkillIn] = Field(max_length=2000)
    minCosine: float = Field(default=0.80, ge=0.5, le=0.99)


def _profile(p: ProfileIn) -> Profile:
    to_skill = lambda s: Skill(name=s.name, skill_id=s.skillId, level=s.level)  # noqa: E731
    return Profile(id=p.id, city=p.city, rating=p.rating, offers=[to_skill(s) for s in p.offers], needs=[to_skill(s) for s in p.needs])


state: dict = {}


@asynccontextmanager
async def lifespan(_app: FastAPI):
    embedder = FastEmbedder()
    embedder.embed(["warm-up"])  # charge le modèle en mémoire avant la première requête
    state["embedder"] = embedder
    state["recommender"] = Recommender(embedder)
    yield
    state.clear()


app = FastAPI(title="ml-service", version="1.0.0", lifespan=lifespan)


@app.get("/health")
def health():
    ready = "recommender" in state
    return {"ok": ready, "model": state["embedder"].model_name if ready else None}


@app.post("/v1/recommend")
def recommend(req: RecommendRequest):
    results = state["recommender"].rank(_profile(req.user), [_profile(c) for c in req.candidates])
    return {"model": state["embedder"].model_name, "results": results}


@app.post("/v1/search-skills")
def search_skills(req: SearchRequest):
    skills = [Skill(name=s.name, skill_id=s.skillId) for s in req.skills]
    results = state["recommender"].search_skills(req.query, skills, top_k=req.topK)
    return {"model": state["embedder"].model_name, "results": results}


@app.post("/v1/suggest-skills")
def suggest_skills(req: SuggestRequest):
    skills = [Skill(name=s.name, skill_id=s.skillId) for s in req.skills]
    texts = [t[:300] for t in req.texts]
    results = state["recommender"].suggest_skills(texts, skills, exclude_ids=set(req.excludeIds), top_k=req.topK)
    return {"model": state["embedder"].model_name, "results": results}


@app.post("/v1/find-duplicates")
def find_duplicates(req: DuplicatesRequest):
    skills = [Skill(name=s.name, skill_id=s.skillId) for s in req.skills]
    clusters = state["recommender"].find_duplicates(skills, min_cosine=req.minCosine)
    return {"model": state["embedder"].model_name, "clusters": clusters}
