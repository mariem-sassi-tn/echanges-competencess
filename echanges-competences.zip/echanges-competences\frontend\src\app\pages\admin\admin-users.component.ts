import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { User } from '../../core/models';
import { ConfirmService } from '../../core/confirm.service';
import { ToastService } from '../../core/toast.service';

@Component({
  selector: 'app-admin-users',
  template: `
    <h1 class="page-title">Utilisateurs</h1>
    <p class="page-sub">Activation des comptes et rôles.</p>
    <table class="table">
      <thead><tr><th>Nom</th><th>Email</th><th>Rôle</th><th>Statut</th><th></th></tr></thead>
      <tbody>
        @for (u of paginatedUsers; track u.id) {
          <tr>
            <td>{{ u.firstName }} {{ u.lastName }}</td>
            <td>{{ u.email }}</td>
            <td>{{ u.role }}</td>
            <td><span class="badge" [class.warn]="!u.isActive">{{ u.isActive ? 'actif' : 'désactivé' }}</span></td>
            <td>
              <button class="btn btn-ghost btn-sm" (click)="toggle(u)">{{ u.isActive ? 'Désactiver' : 'Activer' }}</button>
              @if (u.role === 'user') {
                <button class="btn btn-primary btn-sm" (click)="makeAdmin(u)">Promouvoir admin</button>
              }
            </td>
          </tr>
        }
      </tbody>
    </table>

    <!-- Pagination Controls -->
    @if (totalPages > 1) {
      <div style="display: flex; justify-content: center; align-items: center; gap: 12px; margin-top: 20px;">
        <button 
          class="btn btn-ghost btn-sm" 
          [disabled]="currentPage === 1" 
          (click)="goToPage(currentPage - 1)">
          ◀ Précédent
        </button>
        
        <span style="font-size: 14px; color: var(--muted);">
          Page {{ currentPage }} sur {{ totalPages }}
        </span>

        <button 
          class="btn btn-ghost btn-sm" 
          [disabled]="currentPage === totalPages" 
          (click)="goToPage(currentPage + 1)">
          Suivant ▶
        </button>
      </div>
    }
  `
})
export class AdminUsersComponent implements OnInit {
  users: User[] = [];

  // Variables de pagination
  currentPage: number = 1;
  itemsPerPage: number = 10;

  constructor(private api: ApiService, private confirm: ConfirmService, private toast: ToastService) {}

  ngOnInit() { this.reload(); }

  reload() {
    this.api.adminUsers().subscribe((r) => (this.users = r.users));
  }

  // Getters pour calculer la pagination
  get totalPages(): number {
    return Math.ceil(this.users.length / this.itemsPerPage) || 1;
  }

  get paginatedUsers(): User[] {
    const startIndex = (this.currentPage - 1) * this.itemsPerPage;
    return this.users.slice(startIndex, startIndex + this.itemsPerPage);
  }

  goToPage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  async toggle(u: User) {
    const question = u.isActive
      ? `Voulez-vous désactiver le compte de ${u.firstName} ${u.lastName} ?`
      : `Voulez-vous réactiver le compte de ${u.firstName} ${u.lastName} ?`;
    const ok = await this.confirm.ask(question, { danger: !!u.isActive });
    if (!ok) return;
    this.api.patchUser(u.id, { isActive: !u.isActive }).subscribe({
      next: () => {
        this.toast.success('Statut du compte mis à jour.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || 'Impossible de modifier ce compte.')
    });
  }

  async makeAdmin(u: User) {
    const ok = await this.confirm.ask(
      `Voulez-vous promouvoir ${u.firstName} ${u.lastName} au rôle Admin ?`,
      { title: 'Promotion administrateur' }
    );
    if (!ok) return;
    this.api.patchUser(u.id, { role: 'admin' }).subscribe({
      next: () => {
        this.toast.success(`${u.firstName} ${u.lastName} est désormais administrateur·rice.`);
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || 'Impossible de promouvoir cet utilisateur.')
    });
  }
}