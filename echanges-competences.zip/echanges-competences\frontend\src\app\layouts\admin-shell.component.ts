import { Component } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../core/auth.service';

@Component({
  selector: 'app-admin-shell',
  standalone: true,
  imports: [RouterOutlet, RouterLink, RouterLinkActive],
  template: `
    <div class="shell">
      <aside class="sidebar">
        <!-- Logo & Titre -->
        <div class="brand" style="display:flex;align-items:center;gap:10px;font-weight:700;font-size:1.1rem;color:#38bdf8;">
          <span style="width:10px;height:10px;background:#38bdf8;border-radius:50%;display:inline-block;"></span>
          TalentXchange
        </div>

        <!-- Liens de navigation avec Emojis Pro -->
        <a routerLink="/admin" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" class="nav-link">📈 Pilotage</a>
        <a routerLink="/admin/utilisateurs" routerLinkActive="active" class="nav-link">👥 Utilisateurs</a>
        <a routerLink="/admin/catalogue" routerLinkActive="active" class="nav-link">📚 Catalogue</a>
        <a routerLink="/admin/echanges" routerLinkActive="active" class="nav-link">🔄 Échanges</a>
        <a routerLink="/admin/matching" routerLinkActive="active" class="nav-link">🎯 Matching IA</a>
        <a routerLink="/admin/support" routerLinkActive="active" class="nav-link">💬 Support</a>
        
        <!-- Bouton Déconnexion Pro -->
        <button class="btn btn-ghost" style="margin-top:18px;width:100%" (click)="auth.logout()"> Déconnexion</button>
      </aside>

      <section class="main">
        <div class="topbar">
          <div>
            <div style="color:var(--muted);font-size:13px">Espace administrateur</div>
            <strong>{{ auth.user()?.firstName }} {{ auth.user()?.lastName }}</strong>
          </div>
        </div>
        <router-outlet />
      </section>
    </div>
  `
})
export class AdminShellComponent {
  constructor(public auth: AuthService) {}
}