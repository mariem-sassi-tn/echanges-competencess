import { Component, OnInit } from '@angular/core';
import { ApiService } from '../../core/api.service';
import { StatusLabelPipe } from '../../core/status-label.pipe';

const PAGE_SIZE = 10;

@Component({
  selector: 'app-admin-dashboard',
  imports: [StatusLabelPipe],
  template: `
    <h1 class="page-title">Pilotage</h1>
    <p class="page-sub">Vue d’ensemble de la plateforme.</p>
    <div class="grid grid-4">
      <article class="card"><div style="color:var(--muted)">Utilisateurs</div><h2>{{ stats.totalUsers || 0 }}</h2></article>
      <article class="card"><div style="color:var(--muted)">Actifs</div><h2>{{ stats.activeUsers || 0 }}</h2></article>
      <article class="card"><div style="color:var(--muted)">Échanges</div><h2>{{ stats.totalExchanges || 0 }}</h2></article>
      <article class="card"><div style="color:var(--muted)">Terminés</div><h2>{{ stats.completedExchanges || 0 }}</h2></article>
    </div>
    <h3 style="margin-top:28px">Demandes de la dernière semaine</h3>
    <p style="color:var(--muted);margin-top:-10px">{{ recent.length }} élément(s) sur les 7 derniers jours.</p>
    <table class="table">
      <thead><tr><th>#</th><th>De</th><th>Vers</th><th>Statut</th></tr></thead>
      <tbody>
        @for (r of pageItems; track r.id) {
          <tr>
            <td>{{ r.id }}</td>
            <td>{{ r.rfirst }} {{ r.rlast }}</td>
            <td>{{ r.pfirst }} {{ r.plast }}</td>
            <td><span class="badge">{{ r.status | statusLabel }}</span></td>
          </tr>
        } @empty {
          <tr><td colspan="4" style="color:var(--muted)">Aucun élément durant la dernière semaine.</td></tr>
        }
      </tbody>
    </table>

    @if (totalPages > 1) {
      <div style="display:flex;gap:8px;margin-top:16px;flex-wrap:wrap">
        @for (p of pageNumbers; track p) {
          <button
            class="btn btn-sm"
            [class.btn-primary]="p === page"
            [class.btn-ghost]="p !== page"
            type="button"
            (click)="goToPage(p)"
          >Page {{ p }}</button>
        }
      </div>
    }
  `
})
export class AdminDashboardComponent implements OnInit {
  stats: {
    totalUsers?: number;
    activeUsers?: number;
    totalExchanges?: number;
    completedExchanges?: number;
  } = {};
  recent: any[] = [];
  page = 1;

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.api.adminDashboard().subscribe((r) => {
      this.stats = r.stats || {};
      this.recent = r.recent || [];
      this.page = 1;
    });
  }

  get totalPages() {
    return Math.max(1, Math.ceil(this.recent.length / PAGE_SIZE));
  }

  get pageNumbers() {
    return Array.from({ length: this.totalPages }, (_, i) => i + 1);
  }

  get pageItems() {
    const start = (this.page - 1) * PAGE_SIZE;
    return this.recent.slice(start, start + PAGE_SIZE);
  }

  goToPage(p: number) {
    this.page = p;
  }
}
