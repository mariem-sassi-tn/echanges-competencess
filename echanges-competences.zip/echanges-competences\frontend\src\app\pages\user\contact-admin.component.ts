import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ApiService } from '../../core/api.service';
import { SupportMessage } from '../../core/models';
import { SupportService } from '../../core/support.service';
import { ToastService } from '../../core/toast.service';

/** Conversation réelle avec l'administration (enregistrée ; l'admin répond depuis son espace « Support »). */
@Component({
  selector: 'app-contact-admin',
  imports: [FormsModule, DatePipe],
  template: `
    <h1 class="page-title">Contacter l’administration</h1>
    <p class="page-sub">Écrivez à l’équipe : sa réponse apparaît ici. Pour une question rapide, utilisez la bulle <strong>✦ Assistant IA</strong> en bas à droite.</p>

    <article class="card chat-card">
      <header class="chat-header">
        <div class="bot-avatar">👤</div>
        <div>
          <strong>Équipe TalentXchange</strong>
          <div class="online-status">Un administrateur vous répond dès que possible</div>
        </div>
      </header>

      <section id="admin-thread" class="chat-messages" aria-live="polite" aria-label="Conversation avec l'administration">
        @for (m of thread; track m.id) {
          <div class="message-row" [class.mine]="m.senderRole === 'user'">
            <div class="bubble">
              <div class="sender">{{ m.senderRole === 'user' ? 'Vous' : 'Administration' }}</div>
              <div class="message-content">{{ m.content }}</div>
              <time>{{ m.created_at | date:'short' }}</time>
            </div>
          </div>
        } @empty {
          <p class="empty-thread">Aucun message pour le moment. Décrivez votre problème ci-dessous, l’équipe vous répondra ici.</p>
        }
      </section>

      <form class="chat-compose" (ngSubmit)="send()">
        <textarea
          [(ngModel)]="draft"
          name="draft"
          rows="2"
          maxlength="2000"
          [disabled]="sending"
          placeholder="Écrivez à l’administration…"
          (keydown.enter)="onEnter($event)"
        ></textarea>
        <button class="btn btn-primary" type="submit" [disabled]="sending || !draft.trim()">
          {{ sending ? 'Envoi…' : 'Envoyer' }} <span aria-hidden="true">➤</span>
        </button>
      </form>
      <p class="chat-note">Ne partagez jamais votre mot de passe ni vos codes de vérification.</p>
    </article>
  `,
  styles: [`
    .chat-card { max-width: 760px; padding: 0; overflow: hidden; }
    .chat-header { display:flex; align-items:center; gap:12px; padding:18px 20px; border-bottom:1px solid var(--line); }
    .bot-avatar { width:42px; height:42px; display:grid; place-items:center; border-radius:50%; background:rgba(142,224,106,.16); color:var(--accent); font-size:22px; }
    .online-status { color:var(--muted); font-size:12px; margin-top:4px; }
    .chat-messages { height: min(52vh, 460px); min-height:300px; overflow-y:auto; padding:20px; display:flex; flex-direction:column; gap:14px; }
    .message-row { display:flex; justify-content:flex-start; }
    .message-row.mine { justify-content:flex-end; }
    .bubble { max-width:min(82%, 540px); padding:11px 14px; border-radius:15px 15px 15px 4px; background:rgba(255,255,255,.07); overflow-wrap:anywhere; }
    .mine .bubble { background:rgba(142,224,106,.16); border-radius:15px 15px 4px 15px; }
    .sender { font-size:11px; font-weight:700; color:var(--muted); margin-bottom:5px; }
    .message-content { white-space:pre-wrap; line-height:1.5; }
    .bubble time { display:block; text-align:right; color:var(--muted); font-size:10px; margin-top:6px; }
    .empty-thread { color:var(--muted); text-align:center; margin:auto; max-width:360px; }
    .chat-compose { display:flex; align-items:flex-end; gap:10px; padding:14px 18px; border-top:1px solid var(--line); }
    .chat-compose textarea { flex:1; min-width:0; resize:vertical; border:1px solid var(--line); border-radius:12px; padding:12px; color:inherit; background:rgba(255,255,255,.04); font:inherit; }
    .chat-compose button { white-space:nowrap; }
    .chat-compose button:disabled { opacity:.55; cursor:not-allowed; }
    .chat-note { color:var(--muted); font-size:11px; padding:0 18px 14px; margin:0; }
    @media(max-width:600px) { .chat-compose { flex-direction:column; align-items:stretch; } .chat-compose button { align-self:flex-end; } .bubble { max-width:92%; } }
  `]
})
export class ContactAdminComponent implements OnInit, OnDestroy {
  thread: SupportMessage[] = [];
  draft = '';
  sending = false;
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor(private api: ApiService, private toast: ToastService, private support: SupportService) {}

  ngOnInit() {
    this.load();
    // Les réponses de l'administration arrivent sans recharger la page.
    this.timer = setInterval(() => this.load(), 15000);
  }

  ngOnDestroy() {
    if (this.timer) clearInterval(this.timer);
  }

  private load() {
    this.api.supportThread().subscribe({
      next: (r) => {
        const grew = r.messages.length !== this.thread.length;
        this.thread = r.messages;
        // La page est ouverte : tout ce qui est affiché est lu (la pastille du menu disparaît).
        this.support.markSeen(SupportService.latestAdminId(r.messages));
        if (grew) this.scrollToEnd();
      },
      error: () => {
        /* silencieux : la prochaine relève réessaiera */
      }
    });
  }

  private scrollToEnd() {
    setTimeout(() => {
      const el = document.getElementById('admin-thread');
      if (el) el.scrollTop = el.scrollHeight;
    }, 0);
  }

  onEnter(event: Event) {
    const keyboardEvent = event as KeyboardEvent;
    if (!keyboardEvent.shiftKey) {
      keyboardEvent.preventDefault();
      this.send();
    }
  }

  send() {
    const content = this.draft.trim();
    if (!content || this.sending) return;
    this.sending = true;
    this.api.sendSupportMessage(content).subscribe({
      next: () => {
        this.draft = '';
        this.sending = false;
        this.load();
      },
      error: (err) => {
        this.sending = false;
        this.toast.error(err.error?.message || 'Impossible d’envoyer le message.');
      }
    });
  }
}
