import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { Injector, inject } from '@angular/core';
import { catchError, throwError } from 'rxjs';
import { AuthService } from './auth.service';
import { ToastService } from './toast.service';

const AUTH_URLS = ['/auth/login', '/auth/register', '/auth/forgot-password', '/auth/reset-password'];

/**
 * Gestion globale des erreurs réseau/session :
 *  - 401 hors connexion : session expirée ou compte désactivé → déconnexion automatique
 *  - 0   : serveur injoignable
 *  - 429 : trop de requêtes
 * Les autres erreurs (400, 403, 404, 409, 422…) restent gérées par chaque composant.
 */
export const errorInterceptor: HttpInterceptorFn = (req, next) => {
  const injector = inject(Injector); // injection différée : évite la dépendance circulaire avec AuthService/HttpClient

  return next(req).pipe(
    catchError((err: HttpErrorResponse) => {
      const toast = injector.get(ToastService);
      const isAuthCall = AUTH_URLS.some((u) => req.url.includes(u));

      if (err.status === 401 && !isAuthCall) {
        const auth = injector.get(AuthService);
        if (auth.isLoggedIn()) {
          toast.error('Votre session a expiré. Veuillez vous reconnecter.');
          auth.logout();
        }
      } else if (err.status === 0) {
        toast.error('Serveur injoignable. Vérifiez votre connexion.');
      } else if (err.status === 429) {
        toast.error(err.error?.message || 'Trop de requêtes, réessayez dans quelques instants.');
      }
      return throwError(() => err);
    })
  );
};
