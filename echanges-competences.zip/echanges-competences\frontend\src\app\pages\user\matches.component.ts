import { Component, OnInit } from '@angular/core';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { matchInitial, matchName, proposeParams, reasonText } from '../../core/matching';
import { Recommendation } from '../../core/models';

@Component({
  selector: 'app-matches',
  imports: [RouterLink],
  template: `
    <h1 class="page-title">Mes matches</h1>
    <p class="page-sub">Les membres avec qui un échange de compétences a le plus de sens, calculés par l’IA à partir de ce que vous proposez et de ce que vous cherchez.</p>

    @if (loading) {
      <p class="page-sub">Calcul de vos matches…</p>
    } @else if (noSkills) {
      <article class="card">
        <h3>Complétez vos compétences</h3>
        <p style="color:var(--muted)">Ajoutez ce que vous savez faire (offres) et ce que vous voulez apprendre (besoins) : c’est avec cela que l’IA trouve vos partenaires.</p>
        <a class="btn btn-primary" routerLink="/espace/competences">Gérer mes compétences</a>
      </article>
    } @else if (!available) {
      <article class="card">
        <h3>Matching indisponible pour le moment</h3>
        <p style="color:var(--muted)">Le service d’IA ne répond pas. Vous pouvez toujours parcourir la <a routerLink="/espace/membres">communauté</a>.</p>
      </article>
    } @else if (!matches.length) {
      <article class="card">
        <h3>Pas encore de match</h3>
        <p style="color:var(--muted)">Aucun membre ne correspond assez à votre profil pour l’instant. Ajoutez d’autres compétences ou revenez bientôt.</p>
        <a class="btn btn-ghost" routerLink="/espace/membres">Parcourir la communauté</a>
      </article>
    } @else {
      <div style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:18px">
        <button type="button" class="btn btn-sm" [class.btn-primary]="filter === 'all'" [class.btn-ghost]="filter !== 'all'" (click)="filter = 'all'">
          Tous ({{ matches.length }})
        </button>
        <button type="button" class="btn btn-sm" [class.btn-primary]="filter === 'mutual'" [class.btn-ghost]="filter !== 'mutual'" (click)="filter = 'mutual'">
          Échanges réciproques ({{ mutualCount }})
        </button>
      </div>

      <div class="grid grid-2">
        @for (m of visible; track m.userId) {
          <article class="card">
            <div style="display:flex;align-items:center;gap:12px;margin-bottom:10px">
              @if (m.member?.avatarUrl) {
                <img [src]="m.member?.avatarUrl" alt="" style="width:48px;height:48px;border-radius:50%;object-fit:cover;border:1px solid var(--line)">
              } @else {
                <div style="width:48px;height:48px;border-radius:50%;background:var(--accent);display:grid;place-items:center;font-weight:700;color:#0a0618">
                  {{ initial(m) }}
                </div>
              }
              <div style="flex:1;min-width:0">
                <h3 style="margin:0">{{ name(m) }}</h3>
                <div style="color:var(--muted);font-size:13px">{{ m.member?.city || 'Ville non renseignée' }}</div>
              </div>
              <span class="badge" [class.warn]="m.score < 40" style="font-weight:700;white-space:nowrap" [title]="'Compatibilité calculée par l’IA : ' + m.score + ' %'">
                {{ m.score }} %
              </span>
            </div>

            @if (m.mutual) {
              <span class="badge" style="margin-bottom:10px;display:inline-block">🔄 Échange réciproque</span>
            }

            <div style="margin:8px 0 12px">
              <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--muted)">
                <span>Ce qu’il/elle vous apporte</span><strong style="color:var(--text)">{{ m.forward ?? 0 }} %</strong>
              </div>
              <div style="height:6px;border-radius:99px;background:rgba(255,255,255,.08);margin:4px 0 10px;overflow:hidden">
                <div style="height:100%;background:var(--accent)" [style.width.%]="m.forward ?? 0"></div>
              </div>
              <div style="display:flex;justify-content:space-between;font-size:13px;color:var(--muted)">
                <span>Ce que vous lui apportez</span><strong style="color:var(--text)">{{ m.backward ?? 0 }} %</strong>
              </div>
              <div style="height:6px;border-radius:99px;background:rgba(255,255,255,.08);margin:4px 0 0;overflow:hidden">
                <div style="height:100%;background:var(--accent-2)" [style.width.%]="m.backward ?? 0"></div>
              </div>
            </div>

            @if (m.reasons.length) {
              <ul style="margin:0 0 14px;padding-left:18px;font-size:13px;color:var(--accent)">
                @for (r of m.reasons; track $index) {
                  <li>{{ reasonText(r) }}</li>
                }
              </ul>
            }

            <div style="display:flex;gap:8px;flex-wrap:wrap">
              <a class="btn btn-primary btn-sm" [routerLink]="['/espace/membres', m.userId]" [queryParams]="params(m)" (click)="track(m.userId)">
                {{ canPrefill(m) ? 'Proposer cet échange' : 'Voir le profil' }}
              </a>
              @if (canPrefill(m)) {
                <a class="btn btn-ghost btn-sm" [routerLink]="['/espace/membres', m.userId]" (click)="track(m.userId)">Voir le profil</a>
              }
            </div>
          </article>
        } @empty {
          <p class="page-sub">Aucun échange réciproque pour l’instant.</p>
        }
      </div>
    }
  `
})
export class MatchesComponent implements OnInit {
  loading = true;
  available = false;
  noSkills = false;
  matches: Recommendation[] = [];
  filter: 'all' | 'mutual' = 'all';

  readonly reasonText = reasonText;
  readonly name = matchName;
  readonly initial = matchInitial;

  constructor(private api: ApiService) {}

  ngOnInit() {
    this.api.recommendations().subscribe({
      next: (r) => {
        this.available = r.available;
        this.noSkills = r.reason === 'no_skills';
        this.matches = r.recommendations;
        this.loading = false;
      },
      error: () => {
        this.available = false;
        this.loading = false;
      }
    });
  }

  get mutualCount(): number {
    return this.matches.filter((m) => m.mutual).length;
  }

  get visible(): Recommendation[] {
    return this.filter === 'mutual' ? this.matches.filter((m) => m.mutual) : this.matches;
  }

  params(m: Recommendation) {
    return proposeParams(m);
  }

  canPrefill(m: Recommendation): boolean {
    return Boolean(m.proposal?.offeredUserSkillId || m.proposal?.requestedUserSkillId);
  }

  track(id: number) {
    this.api.recommendationClick(id).subscribe({ error: () => {} });
  }
}
