"""Embeddings via fastembed (ONNX, sans PyTorch → image Docker beaucoup plus légère)."""
from __future__ import annotations

import os
import threading

import numpy as np

MODEL_NAME = os.getenv("MODEL_NAME", "sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2")
CACHE_DIR = os.getenv("FASTEMBED_CACHE_PATH", "/opt/models")
_CACHE_MAX = 5000


class FastEmbedder:
    def __init__(self, model_name: str = MODEL_NAME, cache_dir: str = CACHE_DIR):
        from fastembed import TextEmbedding

        self.model_name = model_name
        self._model = TextEmbedding(model_name, cache_dir=cache_dir)
        self._cache: dict[str, np.ndarray] = {}
        self._lock = threading.Lock()

    def embed(self, texts: list[str]) -> np.ndarray:
        # Les compétences forment un petit vocabulaire : on ne calcule chaque texte qu'une fois.
        with self._lock:
            missing = [t for t in dict.fromkeys(texts) if t not in self._cache]
            if missing:
                if len(self._cache) + len(missing) > _CACHE_MAX:
                    self._cache.clear()
                for text, vector in zip(missing, self._model.embed(missing)):
                    self._cache[text] = np.asarray(vector, dtype=float)
            return np.stack([self._cache[t] for t in texts])
