import { Component, HostListener } from '@angular/core';
import { AiChatComponent } from '../pages/user/ai-chat.component';

/**
 * Bulle flottante de l'assistant IA (comme le widget WhatsApp), visible sur toutes les pages de l'espace membre.
 * La conversation avec l'administration, elle, est sur la page « Contacter l'admin ».
 */
@Component({
  selector: 'app-support-widget',
  imports: [AiChatComponent],
  template: `
    <div class="panel" [class.open]="open" role="dialog" aria-label="Assistant IA" [attr.aria-hidden]="!open">
      <header class="panel-head">
        <strong>Assistant IA</strong>
        <button type="button" class="close" aria-label="Fermer" (click)="open = false">✕</button>
      </header>
      <app-ai-chat (leave)="open = false" />
    </div>

    <button type="button" class="launcher" [attr.aria-expanded]="open" (click)="open = !open">
      {{ open ? '✕ Fermer' : '✦ Assistant IA' }}
    </button>
  `,
  styles: [`
    .launcher { position:fixed; right:22px; bottom:22px; z-index:1000; padding:12px 18px; border-radius:99px;
      border:1px solid rgba(142,224,106,.55); background:rgba(26,18,56,.94); color:var(--text); font:inherit; font-weight:700; cursor:pointer;
      box-shadow:var(--shadow); transition:background .15s, transform .15s; }
    .launcher:hover { background:rgba(53,36,100,.96); transform:translateY(-1px); }
    .panel { position:fixed; right:22px; bottom:84px; z-index:1000; display:none; flex-direction:column;
      width:min(400px, calc(100vw - 32px)); height:min(620px, calc(100vh - 120px));
      border-radius:18px; border:1px solid var(--line); background:var(--bg-soft); box-shadow:0 24px 60px rgba(0,0,0,.5); overflow:hidden; }
    .panel.open { display:flex; }
    .panel-head { display:flex; justify-content:space-between; align-items:center; padding:12px 16px; background:var(--panel); border-bottom:1px solid var(--line); }
    .close { background:none; border:none; color:var(--muted); font-size:16px; cursor:pointer; }
    app-ai-chat { flex:1; min-height:0; }
    @media(max-width:600px) { .panel { right:16px; bottom:80px; } .launcher { right:16px; bottom:16px; } }
  `]
})
export class SupportWidgetComponent {
  open = false;

  @HostListener('document:keydown.escape')
  close() {
    this.open = false;
  }
}
