import { Component, OnInit } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterLink } from '@angular/router';
import { ApiService } from '../../core/api.service';
import { Skill } from '../../core/models';
import { ToastService } from '../../core/toast.service';
import { ConfirmService } from '../../core/confirm.service';

@Component({
  selector: 'app-admin-catalog',
  standalone: true,
  imports: [FormsModule, RouterLink],
  template: `
    <div class="catalog-container">
      
      <!-- En-tête compact -->
      <div class="page-header">
        <div>
          <h1 class="title">Catalogue des compétences</h1>
          <p class="subtitle">Gérez la liste globale des compétences disponibles sur la plateforme.</p>
        </div>
        <div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap">
          <a routerLink="/admin/catalogue/doublons" class="count-badge" style="text-decoration:none">🔍 Détecter les doublons (IA)</a>
          <div class="count-badge">
            <strong>{{ skills.length }}</strong> compétences
          </div>
        </div>
      </div>

      <!-- Barre d'action principale (Ajout rapide + Recherche) -->
      <div class="toolbar-card">
        <form (ngSubmit)="addSkill()" class="add-form">
          <input 
            type="text" 
            [(ngModel)]="skillName" 
            name="skillName" 
            placeholder="Ex. Marketing, UI Design, Angular..." 
            required
            class="input-field">
          <button type="submit" class="btn-add" [disabled]="!skillName.trim()">
            + Ajouter
          </button>
        </form>

        <div class="divider"></div>

        <div class="search-box">
          <input 
            type="text" 
            [(ngModel)]="searchTerm" 
            (ngModelChange)="onSearchChange()" 
            placeholder="🔍 Rechercher dans la liste..."
            class="input-field">
        </div>
      </div>

      <!-- Liste épurée -->
      <div class="list-card">
        <div class="skills-wrapper">
          @for (s of pagedSkills; track s.id) {
            <div class="skill-item">
              <span class="skill-name">{{ s.name }}</span>
              <button type="button" class="btn-delete" (click)="remove(s)">
                Supprimer
              </button>
            </div>
          } @empty {
            <div class="empty-state">
              Aucune compétence trouvée.
            </div>
          }
        </div>

        <!-- Pagination discrete -->
        @if (filteredSkills.length > pageSize) {
          <div class="pagination">
            <button 
              class="page-btn" 
              [disabled]="currentPage === 1" 
              (click)="changePage(currentPage - 1)">
              Précédent
            </button>
            
            <span class="page-text">Page {{ currentPage }} sur {{ totalPages }}</span>

            <button 
              class="page-btn" 
              [disabled]="currentPage === totalPages" 
              (click)="changePage(currentPage + 1)">
              Suivant
            </button>
          </div>
        }
      </div>

    </div>
  `,
  styles: [`
    .catalog-container {
      max-width: 900px;
      margin: 0 auto;
      display: flex;
      flex-direction: column;
      gap: 18px;
    }

    /* En-tête */
    .page-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .title {
      font-size: 1.5rem;
      font-weight: 700;
      color: #ffffff;
      margin: 0 0 4px 0;
    }

    .subtitle {
      font-size: 0.875rem;
      color: #94a3b8;
      margin: 0;
    }

    .count-badge {
      background: rgba(255, 255, 255, 0.06);
      border: 1px solid rgba(255, 255, 255, 0.08);
      padding: 6px 14px;
      border-radius: 20px;
      font-size: 0.85rem;
      color: #cbd5e1;
    }

    .count-badge strong {
      color: #38bdf8;
    }

    /* Toolbar unique */
    .toolbar-card {
      background: rgba(30, 41, 59, 0.5);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 12px;
      padding: 12px 16px;
      display: flex;
      align-items: center;
      gap: 16px;
      backdrop-filter: blur(8px);
    }

    .add-form {
      display: flex;
      gap: 10px;
      flex: 1;
    }

    .search-box {
      flex: 1;
    }

    .divider {
      width: 1px;
      height: 28px;
      background: rgba(255, 255, 255, 0.1);
    }

    .input-field {
      width: 100%;
      padding: 9px 14px;
      border-radius: 8px;
      background: rgba(15, 23, 42, 0.6);
      border: 1px solid rgba(255, 255, 255, 0.1);
      color: #ffffff;
      font-size: 0.875rem;
      outline: none;
      box-sizing: border-box;
      transition: border-color 0.2s;
    }

    .input-field:focus {
      border-color: #38bdf8;
    }

    .btn-add {
      padding: 9px 18px;
      border-radius: 8px;
      background: #0284c7;
      color: #ffffff;
      font-weight: 600;
      font-size: 0.875rem;
      border: none;
      cursor: pointer;
      white-space: nowrap;
      transition: background 0.2s;
    }

    .btn-add:hover:not(:disabled) {
      background: #0369a1;
    }

    .btn-add:disabled {
      opacity: 0.5;
      cursor: not-allowed;
    }

    /* Carte de Liste */
    .list-card {
      background: rgba(30, 41, 59, 0.4);
      border: 1px solid rgba(255, 255, 255, 0.08);
      border-radius: 12px;
      padding: 16px;
      backdrop-filter: blur(8px);
    }

    .skills-wrapper {
      display: flex;
      flex-direction: column;
      gap: 6px;
      min-height: 280px;
    }

    .skill-item {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 10px 14px;
      border-radius: 8px;
      background: rgba(15, 23, 42, 0.3);
      border: 1px solid rgba(255, 255, 255, 0.02);
      transition: background 0.15s;
    }

    .skill-item:hover {
      background: rgba(15, 23, 42, 0.6);
    }

    .skill-name {
      font-size: 0.9rem;
      color: #f1f5f9;
      font-weight: 500;
    }

    .btn-delete {
      padding: 5px 12px;
      border-radius: 6px;
      background: rgba(239, 68, 68, 0.1);
      border: 1px solid rgba(239, 68, 68, 0.2);
      color: #f87171;
      font-size: 0.8rem;
      cursor: pointer;
      transition: all 0.15s;
    }

    .btn-delete:hover {
      background: rgba(239, 68, 68, 0.25);
      color: #ffffff;
    }

    .empty-state {
      text-align: center;
      padding: 40px;
      color: #64748b;
      font-size: 0.9rem;
    }

    /* Pagination */
    .pagination {
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 16px;
      margin-top: 16px;
      padding-top: 12px;
      border-top: 1px solid rgba(255, 255, 255, 0.06);
    }

    .page-btn {
      padding: 6px 16px;
      border-radius: 20px;
      border: none;
      background: rgba(255, 255, 255, 0.9);
      color: #0f172a;
      font-weight: 600;
      font-size: 0.8rem;
      cursor: pointer;
      transition: background 0.2s;
    }

    .page-btn:disabled {
      background: rgba(255, 255, 255, 0.12);
      color: rgba(255, 255, 255, 0.3);
      cursor: not-allowed;
    }

    .page-text {
      color: #94a3b8;
      font-size: 0.85rem;
    }
  `]
})
export class AdminCatalogComponent implements OnInit {
  skills: Skill[] = [];
  skillName = '';
  searchTerm = '';

  currentPage = 1;
  pageSize = 7;

  constructor(
    private api: ApiService, 
    private toast: ToastService, 
    private confirm: ConfirmService
  ) {}

  ngOnInit() { 
    this.reload(); 
  }

  reload() {
    this.api.catalog().subscribe((r) => {
      this.skills = r.skills;
    });
  }

  get filteredSkills(): Skill[] {
    if (!this.searchTerm.trim()) return this.skills;
    return this.skills.filter(s => 
      s.name.toLowerCase().includes(this.searchTerm.toLowerCase())
    );
  }

  get pagedSkills(): Skill[] {
    const startIndex = (this.currentPage - 1) * this.pageSize;
    return this.filteredSkills.slice(startIndex, startIndex + this.pageSize);
  }

  get totalPages(): number {
    return Math.ceil(this.filteredSkills.length / this.pageSize) || 1;
  }

  onSearchChange() {
    this.currentPage = 1;
  }

  changePage(page: number) {
    if (page >= 1 && page <= this.totalPages) {
      this.currentPage = page;
    }
  }

  addSkill() {
    if (!this.skillName.trim()) return;
    this.api.createSkill({ name: this.skillName }).subscribe({
      next: () => {
        this.skillName = '';
        this.toast.success('Compétence ajoutée.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || "Erreur lors de l'ajout.")
    });
  }

  async remove(s: Skill) {
    const ok = await this.confirm.ask(`Supprimer « ${s.name} » ?`, { danger: true });
    if (!ok) return;
    this.api.deleteSkill(s.id).subscribe({
      next: () => {
        this.toast.success('Compétence supprimée.');
        this.reload();
      },
      error: (err) => this.toast.error(err.error?.message || 'Erreur lors de la suppression.')
    });
  }
}