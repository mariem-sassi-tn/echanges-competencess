import { Injectable, signal } from '@angular/core';

export interface ConfirmRequest {
  title: string;
  message: string;
  confirmLabel: string;
  cancelLabel: string;
  danger: boolean;
}

/**
 * Service global de confirmation.
 * Utilisation : const ok = await this.confirm.ask('Voulez-vous vraiment supprimer ceci ?');
 * Affiche une boîte de dialogue « Oui » / « Non » et résout une Promise<boolean>.
 */
@Injectable({ providedIn: 'root' })
export class ConfirmService {
  request = signal<ConfirmRequest | null>(null);
  private pending: ((value: boolean) => void) | null = null;

  ask(
    message: string,
    options: { title?: string; confirmLabel?: string; cancelLabel?: string; danger?: boolean } = {}
  ): Promise<boolean> {
    this.respond(false); // annule toute demande précédente non résolue
    return new Promise((resolve) => {
      this.pending = resolve;
      this.request.set({
        title: options.title || 'Confirmation',
        message,
        confirmLabel: options.confirmLabel || 'Oui',
        cancelLabel: options.cancelLabel || 'Non',
        danger: options.danger ?? false
      });
    });
  }

  respond(value: boolean) {
    const resolve = this.pending;
    this.pending = null;
    this.request.set(null);
    if (resolve) resolve(value);
  }
}
