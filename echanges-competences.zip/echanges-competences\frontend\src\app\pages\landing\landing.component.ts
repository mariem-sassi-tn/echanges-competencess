import { Component } from '@angular/core';
import { RouterLink } from '@angular/router';

@Component({
  selector: 'app-landing',
  imports: [RouterLink],
  styles: [`
    .hero { max-width: 1100px; margin: 0 auto; padding: 36px 24px 80px; }
    header { display:flex; justify-content:space-between; align-items:center; margin-bottom: 70px; }
    h1 { font-size: clamp(36px, 6vw, 64px); line-height: 1.05; margin: 0 0 16px; }
    p.lead { max-width: 640px; color: var(--muted); font-size: 18px; line-height: 1.6; }
    .actions { display:flex; gap:12px; margin-top: 28px; flex-wrap: wrap; }
    .features { display:grid; grid-template-columns: repeat(3, 1fr); gap:16px; margin-top:64px; }
    @media (max-width: 860px) { .features { grid-template-columns: 1fr; } }
  `],
  template: `
    <div class="hero">
      <header>
        <div class="brand"><span></span> TalentXchange :</div>
        <div>
          <a routerLink="/connexion" class="btn btn-ghost">Connexion</a>
          <a routerLink="/inscription" class="btn btn-primary" style="margin-left:8px">Créer un compte</a>
        </div>
      </header>
      <span class="badge">Talentia · Réseau d’échange de compétences</span>
      <h1>Une plateforme permettant l’échange de compétences entre utilisateurs sans paiement.</h1>
      <p class="lead">
        Par exemple, une personne enseigne l’anglais en échange de cours de design donnés par une autre personne.
        Proposez ce que vous maîtrisez, cherchez ce que vous voulez apprendre, et construisez des échanges équitables.
      </p>
      <div class="actions">
        <a routerLink="/inscription" class="btn btn-primary">Rejoindre la communauté</a>
        <a routerLink="/connexion" class="btn btn-ghost">J’ai déjà un compte</a>
      </div>
      <div class="features">
        <article class="card"><h3>Offrir</h3><p style="color:var(--muted)">Publiez vos compétences (langues, design, code, musique…) et votre niveau.</p></article>
        <article class="card"><h3>Demander</h3><p style="color:var(--muted)">Trouvez un membre qui peut vous enseigner, puis proposez un échange.</p></article>
        <article class="card"><h3>Suivre</h3><p style="color:var(--muted)">Acceptez, discutez, marquez comme terminé et laissez un avis.</p></article>
      </div>
    </div>
  `
})
export class LandingComponent {}
