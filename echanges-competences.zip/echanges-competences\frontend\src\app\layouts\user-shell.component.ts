import { Component, OnDestroy, OnInit } from '@angular/core';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';
import { AuthService } from '../core/auth.service';
import { SupportService } from '../core/support.service';
import { SupportWidgetComponent } from './support-widget.component';

@Component({
  selector: 'app-user-shell',
  imports: [RouterOutlet, RouterLink, RouterLinkActive, SupportWidgetComponent],
  template: `
    <div class="shell">
      <aside class="sidebar">
        <div class="brand"><span></span> TalentXchange</div>
        <a routerLink="/espace" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" class="nav-link"> 📊Tableau de bord</a>
        <a routerLink="/espace/profil" routerLinkActive="active" class="nav-link">👤Profil</a>
        <a routerLink="/espace/competences" routerLinkActive="active" class="nav-link">⚡Mes compétences</a>

        <a routerLink="/espace/matches" routerLinkActive="active" class="nav-link">✨Mes matches</a>
        <a routerLink="/espace/membres" routerLinkActive="active" class="nav-link">👥Membres</a>
        <a routerLink="/espace/echanges" routerLinkActive="active" class="nav-link">🔄Mes échanges</a>
        <a routerLink="/espace/contact" routerLinkActive="active" class="nav-link">💬Contacter l’admin @if (support.hasNew()) { <span class="dot" title="Nouvelle réponse de l’administration"></span> }</a>
        <button class="btn btn-ghost" style="margin-top:18px;width:100%" (click)="auth.logout()">Déconnexion</button>
      </aside>
      <section class="main">
        <div class="topbar">
          <div style="display:flex;align-items:center;gap:12px">
            @if (auth.user()?.avatarUrl) {
              <img [src]="auth.user()?.avatarUrl" alt="" style="width:38px;height:38px;border-radius:50%;object-fit:cover;border:1px solid var(--line)">
            } @else {
              <div style="width:38px;height:38px;border-radius:50%;background:var(--accent);display:grid;place-items:center;font-weight:700;color:#0a0618">
                {{ (auth.user()?.firstName || '?').charAt(0) }}
              </div>
            }
            <div>
              <div style="color:var(--muted);font-size:13px">Espace utilisateur</div>
              <strong>{{ auth.user()?.firstName }} {{ auth.user()?.lastName }}</strong>
            </div>
          </div>
        </div>
        <router-outlet />
      </section>
    </div>
    <app-support-widget />
  `,
  styles: [`
    .dot { display:inline-block; width:9px; height:9px; border-radius:50%; background:#ff6b6b; margin-left:6px; }
  `]
})
export class UserShellComponent implements OnInit, OnDestroy {
  constructor(public auth: AuthService, public support: SupportService) {}

  ngOnInit() {
    this.support.start(); // pastille rouge quand l'administration a répondu
  }

  ngOnDestroy() {
    this.support.stop();
  }
}
