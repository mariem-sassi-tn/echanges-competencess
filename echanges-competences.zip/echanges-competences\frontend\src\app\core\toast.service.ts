import { Injectable, signal } from '@angular/core';

export interface ToastMessage {
  type: 'success' | 'error';
  text: string;
}

/**
 * Service global de messages de confirmation / erreur, affichés après chaque action.
 */
@Injectable({ providedIn: 'root' })
export class ToastService {
  toast = signal<ToastMessage | null>(null);
  private timer: ReturnType<typeof setTimeout> | null = null;

  success(text: string) {
    this.show({ type: 'success', text });
  }

  error(text: string) {
    this.show({ type: 'error', text });
  }

  private show(message: ToastMessage) {
    if (this.timer) clearTimeout(this.timer);
    this.toast.set(message);
    this.timer = setTimeout(() => this.toast.set(null), 4500);
  }

  dismiss() {
    if (this.timer) clearTimeout(this.timer);
    this.toast.set(null);
  }
}
