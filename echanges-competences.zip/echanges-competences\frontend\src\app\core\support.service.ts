import { Injectable, signal } from '@angular/core';
import { ApiService } from './api.service';
import { AuthService } from './auth.service';
import { SupportMessage } from './models';

/**
 * Suivi des réponses de l'administration : alimente la pastille rouge du menu « Contacter l'admin ».
 * Démarré par l'espace membre ; la page Support appelle markSeen() quand le membre lit la conversation.
 */
@Injectable({ providedIn: 'root' })
export class SupportService {
  readonly hasNew = signal(false);
  private seenId = 0;
  private timer: ReturnType<typeof setInterval> | null = null;

  constructor(private api: ApiService, private auth: AuthService) {}

  private get key(): string {
    return `support-seen-admin-id:${this.auth.user()?.id ?? 0}`;
  }

  start() {
    if (this.timer) return;
    try {
      this.seenId = Number(localStorage.getItem(this.key)) || 0;
    } catch {
      this.seenId = 0; // stockage indisponible : on ignore
    }
    this.refresh();
    this.timer = setInterval(() => this.refresh(), 20000);
  }

  stop() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    this.hasNew.set(false);
  }

  private refresh() {
    this.api.supportThread().subscribe({
      next: (r) => this.hasNew.set(SupportService.latestAdminId(r.messages) > this.seenId),
      error: () => {
        /* silencieux : la prochaine relève réessaiera */
      }
    });
  }

  static latestAdminId(messages: SupportMessage[]): number {
    return messages.reduce((max, m) => (m.senderRole === 'admin' && m.id > max ? m.id : max), 0);
  }

  /** Le membre a lu la conversation jusqu'à ce message de l'administration. */
  markSeen(latestAdminId: number) {
    this.seenId = Math.max(this.seenId, latestAdminId);
    this.hasNew.set(false);
    try {
      localStorage.setItem(this.key, String(this.seenId));
    } catch {
      /* stockage indisponible : on ignore */
    }
  }
}
